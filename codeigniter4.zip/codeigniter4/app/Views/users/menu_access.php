<?php
/**
 * Menu & Tab Access Management View
 * Allows Company Admin to show or hide sidebar items and tabs per role or per employee.
 */
?>
<div class="space-y-6" x-data="menuAccessManager()">

    <!-- Top Security Navigation -->
    <?= view('partials/security_nav', ['activeTab' => 'menu-access']) ?>

    <!-- Flash Notifications / Feedback -->
    <?php if (session()->getFlashdata('success')): ?>
        <div class="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-2">
                <i data-lucide="check-circle" class="w-4 h-4 text-emerald-600 dark:text-emerald-400"></i>
                <span><?= esc(session()->getFlashdata('success')) ?></span>
            </div>
            <button @click="$el.parentElement.remove()" class="text-emerald-600 hover:text-emerald-800"><i data-lucide="x" class="w-4 h-4"></i></button>
        </div>
    <?php endif; ?>

    <!-- Header & Controls Card -->
    <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-6 shadow-sm">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                        Access Control
                    </span>
                    <span class="text-xs text-slate-400">&bull;</span>
                    <span class="text-xs text-slate-500 dark:text-slate-400" x-text="mode === 'role' ? 'Configuring role visibility' : 'Configuring employee overrides'"></span>
                </div>
                <h1 class="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Menu & Tab Access</h1>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Control which sidebar pages and individual tabs are visible for each role or customized for individual employees.</p>
            </div>

            <!-- Action Controls -->
            <div class="flex flex-wrap items-center gap-3">
                <!-- Segmented Switch: By Role | By Employee -->
                <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80">
                    <button type="button" 
                            @click="setMode('role')" 
                            :class="mode === 'role' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold shadow-xs' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'" 
                            class="px-4 py-1.5 rounded-xl text-xs transition cursor-pointer">
                        By role
                    </button>
                    <button type="button" 
                            @click="setMode('user')" 
                            :class="mode === 'user' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold shadow-xs' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'" 
                            class="px-4 py-1.5 rounded-xl text-xs transition cursor-pointer">
                        By employee
                    </button>
                </div>

                <!-- Dropdown: Role or Employee -->
                <template x-if="mode === 'role'">
                    <div class="min-w-[200px]">
                        <select x-model="selectedRoleId" @change="onRoleChange()" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:ring-2 focus:ring-indigo-500">
                            <template x-for="r in roles" :key="r.id">
                                <option :value="r.id" x-text="r.name"></option>
                            </template>
                        </select>
                    </div>
                </template>

                <template x-if="mode === 'user'">
                    <div class="flex items-center gap-2">
                        <div class="min-w-[240px]">
                            <select x-model="selectedUserId" @change="onUserChange()" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:ring-2 focus:ring-indigo-500">
                                <template x-for="u in users" :key="u.id">
                                    <option :value="u.id" x-text="(u.first_name ? u.first_name + ' ' + (u.last_name || '') : u.username) + ' (' + (u.role_name || 'No Role') + ')'"></option>
                                </template>
                            </select>
                        </div>

                        <!-- Reset to role button -->
                        <button type="button" 
                                @click="resetToRole()"
                                :disabled="!hasUserOverrides()"
                                :class="hasUserOverrides() ? 'bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:hover:bg-amber-900/40 dark:text-amber-300 border-amber-200 dark:border-amber-800' : 'opacity-40 cursor-not-allowed bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700'"
                                class="px-3.5 py-2 rounded-xl border text-xs font-semibold transition flex items-center gap-1.5"
                                title="Clear user overrides and inherit role settings">
                            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                            <span>Reset to role</span>
                        </button>
                    </div>
                </template>

                <!-- Save Changes Button -->
                <button type="button" 
                        @click="saveChanges()"
                        :disabled="isSaving"
                        class="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm transition inline-flex items-center gap-2 cursor-pointer disabled:opacity-50">
                    <i data-lucide="check" class="w-4 h-4" x-show="!isSaving"></i>
                    <span x-show="isSaving">Saving...</span>
                    <span x-show="!isSaving">Save changes</span>
                </button>
            </div>
        </div>

        <!-- Inline Status Toast / Confirmation -->
        <div x-show="statusToast.show" 
             x-transition 
             class="mt-4 p-3 rounded-xl border text-xs font-semibold flex items-center justify-between"
             :class="statusToast.type === 'success' ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300' : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'"
             style="display: none;">
            <div class="flex items-center gap-2">
                <i :data-lucide="statusToast.type === 'success' ? 'check-circle' : 'alert-circle'" class="w-4 h-4"></i>
                <span x-text="statusToast.message"></span>
            </div>
            <button type="button" @click="statusToast.show = false"><i data-lucide="x" class="w-3.5 h-3.5"></i></button>
        </div>
    </div>

    <!-- Main Two-Column Layout -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

        <!-- Left Column: Sidebar Pages (col-span-5) -->
        <div class="lg:col-span-5 space-y-4">
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm space-y-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-sm font-bold text-slate-900 dark:text-white">Sidebar Pages</h2>
                        <p class="text-[11px] text-slate-400">Select a page to configure its internal tabs</p>
                    </div>
                    <span class="text-[11px] font-mono font-bold text-slate-400" x-text="Object.keys(registry).length + ' pages'"></span>
                </div>

                <!-- Search Filter -->
                <div class="relative">
                    <i data-lucide="search" class="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5"></i>
                    <input type="text" 
                           x-model="pageSearch" 
                           placeholder="Search pages..." 
                           class="w-full pl-9 pr-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs focus:ring-2 focus:ring-indigo-500">
                </div>

                <!-- Pages List -->
                <div class="space-y-1.5 max-h-[640px] overflow-y-auto pr-1">
                    <template x-for="(page, pageKey) in filteredRegistry" :key="pageKey">
                        <div @click="selectPage(pageKey)"
                             :class="selectedPageKey === pageKey ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 ring-1 ring-indigo-500/20' : 'bg-slate-50/50 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-700/60 hover:bg-slate-100/70 dark:hover:bg-slate-800/70'"
                             class="p-3 rounded-2xl border transition flex items-center justify-between gap-3 cursor-pointer group">
                            
                            <div class="flex items-center gap-3 min-w-0">
                                <div :class="selectedPageKey === pageKey ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700'"
                                     class="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 transition">
                                    <i :data-lucide="page.icon || 'layers'" class="w-4 h-4"></i>
                                </div>
                                <div class="min-w-0">
                                    <div class="flex items-center gap-1.5">
                                        <span class="text-xs font-bold text-slate-800 dark:text-slate-200 truncate" x-text="page.title"></span>
                                        <!-- Orange dot if differs from role in employee mode -->
                                        <template x-if="mode === 'user' && isItemDiffersFromRole(pageKey)">
                                            <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0" title="Differs from role setting"></span>
                                        </template>
                                    </div>
                                    <div class="flex items-center gap-2 mt-0.5">
                                        <!-- No permission badge -->
                                        <template x-if="!hasPermission(pageKey)">
                                            <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900">
                                                No permission
                                            </span>
                                        </template>
                                        <!-- Protected badge -->
                                        <template x-if="isProtected(pageKey)">
                                            <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                                Protected
                                            </span>
                                        </template>
                                        <!-- Tabs count badge -->
                                        <template x-if="page.tabs && page.tabs.length > 0">
                                            <span class="text-[10px] font-mono text-slate-400" x-text="getTabCountLabel(pageKey)"></span>
                                        </template>
                                    </div>
                                </div>
                            </div>

                            <!-- On/Off Switch -->
                            <div class="flex items-center gap-2 shrink-0" @click.stop>
                                <button type="button" 
                                        @click.stop="toggleItem(pageKey)"
                                        :disabled="!hasPermission(pageKey) || isProtected(pageKey)"
                                        :class="[
                                            (!hasPermission(pageKey) || isProtected(pageKey)) ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer',
                                            isItemOn(pageKey) ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                                        ]"
                                        class="relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none">
                                    <span :class="isItemOn(pageKey) ? 'translate-x-4' : 'translate-x-0'"
                                          class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs ring-0 transition duration-200 ease-in-out"></span>
                                </button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </div>

        <!-- Right Column: Page Tabs (col-span-7) -->
        <div class="lg:col-span-7 space-y-4">
            <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 p-5 shadow-sm space-y-4 min-h-[500px]">
                
                <!-- Selected Page Banner Header -->
                <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900 flex items-center justify-center shrink-0">
                            <i :data-lucide="selectedPage.icon || 'layers'" class="w-5 h-5"></i>
                        </div>
                        <div>
                            <div class="flex items-center gap-2">
                                <h2 class="text-base font-bold text-slate-900 dark:text-white" x-text="selectedPage.title"></h2>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold" 
                                      :class="isItemOn(selectedPageKey) ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400' : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400'"
                                      x-text="isItemOn(selectedPageKey) ? 'Page Visible' : 'Page Hidden'"></span>
                            </div>
                            <p class="text-xs text-slate-400" x-text="selectedPage.tabs && selectedPage.tabs.length > 0 ? selectedPage.tabs.length + ' internal tabs configured' : 'This page does not contain sub-tabs'"></p>
                        </div>
                    </div>

                    <!-- Show all / Hide all quick actions & Selected Page Toggle -->
                    <div class="flex flex-wrap items-center gap-3">
                        <div class="flex items-center gap-2 pr-3 border-r border-slate-200 dark:border-slate-800">
                            <span class="text-xs font-semibold text-slate-500 dark:text-slate-400">Sidebar Menu:</span>
                            <button type="button" 
                                    @click.stop="toggleItem(selectedPageKey)"
                                    :disabled="!hasPermission(selectedPageKey) || isProtected(selectedPageKey)"
                                    :class="[
                                        (!hasPermission(selectedPageKey) || isProtected(selectedPageKey)) ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer',
                                        isItemOn(selectedPageKey) ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                                    ]"
                                    class="relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none">
                                <span :class="isItemOn(selectedPageKey) ? 'translate-x-4' : 'translate-x-0'"
                                      class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs ring-0 transition duration-200 ease-in-out"></span>
                            </button>
                        </div>
                        <template x-if="selectedPage.tabs && selectedPage.tabs.length > 0">
                            <div class="flex items-center gap-2">
                                <button type="button" 
                                        @click="showAllTabs()"
                                        class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                                    Show all
                                </button>
                                <button type="button" 
                                        @click="hideAllTabs()"
                                        class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                                    Hide all
                                </button>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Note when page is hidden in sidebar -->
                <div x-show="!isItemOn(selectedPageKey)" 
                     class="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
                    <i data-lucide="info" class="w-4 h-4 text-amber-600 shrink-0 mt-0.5"></i>
                    <div>
                        <span class="font-bold">Page is hidden in the sidebar.</span>
                        <span class="text-[11px] block mt-0.5 text-amber-700 dark:text-amber-400">Tabs below are shown for reference, but users will not be able to navigate to this page from the sidebar menu.</span>
                    </div>
                </div>

                <!-- Case A: Page has NO tabs -->
                <template x-if="!selectedPage.tabs || selectedPage.tabs.length === 0">
                    <div class="py-12 text-center text-slate-400 space-y-3">
                        <div class="w-12 h-12 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
                            <i data-lucide="folder-check" class="w-6 h-6"></i>
                        </div>
                        <h3 class="text-sm font-semibold text-slate-700 dark:text-slate-300">No secondary tabs</h3>
                        <p class="text-xs max-w-sm mx-auto text-slate-400">This page renders directly without internal tabs. Toggle its visibility in the main sidebar using the switch on the left column.</p>
                    </div>
                </template>

                <!-- Case B: Page HAS tabs -->
                <template x-if="selectedPage.tabs && selectedPage.tabs.length > 0">
                    <div :class="!isItemOn(selectedPageKey) ? 'opacity-60 pointer-events-auto' : ''" 
                         class="space-y-2 transition-opacity">
                        <template x-for="tab in selectedPage.tabs" :key="tab.key">
                            <div class="p-3.5 rounded-2xl border border-slate-200/70 dark:border-slate-700/70 bg-white dark:bg-slate-800/60 flex items-center justify-between gap-4">
                                <div class="flex items-center gap-3 min-w-0">
                                    <div class="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
                                        <i :data-lucide="tab.icon || 'tag'" class="w-3.5 h-3.5"></i>
                                    </div>
                                    <div class="min-w-0">
                                        <div class="flex items-center gap-2">
                                            <span class="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate" x-text="tab.title"></span>
                                            <!-- Orange dot if differs from role in employee mode -->
                                            <template x-if="mode === 'user' && isItemDiffersFromRole(tab.key)">
                                                <span class="w-2 h-2 rounded-full bg-amber-500 shrink-0" title="Differs from role setting"></span>
                                            </template>
                                        </div>
                                        <div class="flex items-center gap-2 mt-0.5">
                                            <span class="text-[10px] font-mono text-slate-400" x-text="tab.key"></span>
                                            <!-- No permission tag -->
                                            <template x-if="!hasPermission(tab.key)">
                                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900">
                                                    No permission
                                                </span>
                                            </template>
                                            <!-- Protected badge -->
                                            <template x-if="isProtected(tab.key)">
                                                <span class="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                                                    Protected
                                                </span>
                                            </template>
                                        </div>
                                    </div>
                                </div>

                                <!-- Tab Switch -->
                                <div class="flex items-center gap-2 shrink-0">
                                    <button type="button" 
                                            @click.stop="toggleItem(tab.key)"
                                            :disabled="!hasPermission(tab.key) || isProtected(tab.key)"
                                            :class="[
                                                (!hasPermission(tab.key) || isProtected(tab.key)) ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer',
                                                isItemOn(tab.key) ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                                            ]"
                                            class="relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none">
                                        <span :class="isItemOn(tab.key) ? 'translate-x-4' : 'translate-x-0'"
                                              class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs ring-0 transition duration-200 ease-in-out"></span>
                                    </button>
                                </div>
                            </div>
                        </template>
                    </div>
                </template>

            </div>
        </div>

    </div>

</div>

<script>
function menuAccessManager() {
    return {
        mode: 'role', // 'role' | 'user'
        roles: <?= json_encode($roles) ?>,
        users: <?= json_encode($users) ?>,
        registry: <?= json_encode($registry) ?>,
        roleExceptions: <?= json_encode($roleExceptions) ?>,
        userExceptions: <?= json_encode($userExceptions) ?>,
        rolePermissions: <?= json_encode($rolePermissionsMap) ?>,
        
        selectedRoleId: '<?= !empty($roles[0]['id']) ? esc($roles[0]['id'], 'js') : '' ?>',
        selectedUserId: '<?= !empty($users[0]['id']) ? esc($users[0]['id'], 'js') : '' ?>',
        selectedPageKey: 'attendance',
        pageSearch: '',
        isSaving: false,
        statusToast: { show: false, message: '', type: 'success' },

        // In-memory working copy of visibility states: [itemKey: boolean]
        workingState: {},

        init() {
            this.rebuildWorkingState();
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        get selectedPage() {
            return this.registry[this.selectedPageKey] || { title: 'Page', icon: 'layers', tabs: [] };
        },

        get filteredRegistry() {
            if (!this.pageSearch.trim()) {
                return this.registry;
            }
            const q = this.pageSearch.toLowerCase().trim();
            const res = {};
            for (const [key, page] of Object.entries(this.registry)) {
                if (page.title.toLowerCase().includes(q) || key.toLowerCase().includes(q)) {
                    res[key] = page;
                }
            }
            return res;
        },

        setMode(newMode) {
            this.mode = newMode;
            this.rebuildWorkingState();
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        onRoleChange() {
            this.rebuildWorkingState();
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        onUserChange() {
            this.rebuildWorkingState();
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        selectPage(key) {
            this.selectedPageKey = key;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        getActiveRoleId() {
            if (this.mode === 'role') {
                return this.selectedRoleId;
            }
            const user = this.users.find(u => u.id === this.selectedUserId);
            return user ? user.role_id : '';
        },

        isCompanyAdminRole(roleId) {
            const role = this.roles.find(r => r.id === roleId);
            if (!role) return false;
            const code = (role.code || role.name || '').toLowerCase();
            return code === 'company_admin' || code === 'company admin' || code === 'super_admin' || code === 'super admin';
        },

        isProtected(key) {
            const roleId = this.getActiveRoleId();
            if (this.isCompanyAdminRole(roleId)) {
                return (key === 'security' || key === 'security.menu_access');
            }
            return false;
        },

        hasPermission(key) {
            const roleId = this.getActiveRoleId();
            if (!roleId || !this.rolePermissions[roleId]) {
                return true;
            }
            return this.rolePermissions[roleId][key] !== false;
        },

        rebuildWorkingState() {
            const state = {};
            if (this.mode === 'role') {
                const roleId = this.selectedRoleId;
                const roleExceptions = this.roleExceptions[roleId] || {};

                for (const [pageKey, page] of Object.entries(this.registry)) {
                    // Default is true (visible) unless an exception exists
                    state[pageKey] = (roleExceptions[pageKey] !== undefined) ? roleExceptions[pageKey] : true;
                    if (this.isProtected(pageKey)) state[pageKey] = true;

                    if (page.tabs && page.tabs.length > 0) {
                        for (const tab of page.tabs) {
                            state[tab.key] = (roleExceptions[tab.key] !== undefined) ? roleExceptions[tab.key] : true;
                            if (this.isProtected(tab.key)) state[tab.key] = true;
                        }
                    }
                }
            } else {
                // User mode
                const user = this.users.find(u => u.id === this.selectedUserId);
                const roleId = user ? user.role_id : '';
                const roleExceptions = this.roleExceptions[roleId] || {};
                const userExceptions = this.userExceptions[this.selectedUserId] || {};

                for (const [pageKey, page] of Object.entries(this.registry)) {
                    const roleDefault = (roleExceptions[pageKey] !== undefined) ? roleExceptions[pageKey] : true;
                    state[pageKey] = (userExceptions[pageKey] !== undefined) ? userExceptions[pageKey] : roleDefault;
                    if (this.isProtected(pageKey)) state[pageKey] = true;

                    if (page.tabs && page.tabs.length > 0) {
                        for (const tab of page.tabs) {
                            const tabRoleDefault = (roleExceptions[tab.key] !== undefined) ? roleExceptions[tab.key] : true;
                            state[tab.key] = (userExceptions[tab.key] !== undefined) ? userExceptions[tab.key] : tabRoleDefault;
                            if (this.isProtected(tab.key)) state[tab.key] = true;
                        }
                    }
                }
            }
            this.workingState = state;
        },

        isItemOn(key) {
            if (!this.hasPermission(key)) return false;
            if (this.isProtected(key)) return true;
            return this.workingState[key] !== false;
        },

        toggleItem(key) {
            if (!this.hasPermission(key) || this.isProtected(key)) return;
            const nextVal = !this.isItemOn(key);
            this.workingState = { ...this.workingState, [key]: nextVal };
        },

        showAllTabs() {
            if (!this.selectedPage.tabs) return;
            const next = { ...this.workingState };
            for (const tab of this.selectedPage.tabs) {
                if (this.hasPermission(tab.key) && !this.isProtected(tab.key)) {
                    next[tab.key] = true;
                }
            }
            this.workingState = next;
        },

        hideAllTabs() {
            if (!this.selectedPage.tabs) return;
            const next = { ...this.workingState };
            for (const tab of this.selectedPage.tabs) {
                if (this.hasPermission(tab.key) && !this.isProtected(tab.key)) {
                    next[tab.key] = false;
                }
            }
            this.workingState = next;
        },

        isItemDiffersFromRole(key) {
            if (this.mode !== 'user') return false;
            const user = this.users.find(u => u.id === this.selectedUserId);
            const roleId = user ? user.role_id : '';
            const roleExceptions = this.roleExceptions[roleId] || {};
            const roleVal = (roleExceptions[key] !== undefined) ? roleExceptions[key] : true;
            const userVal = this.workingState[key] !== false;
            return userVal !== roleVal;
        },

        hasUserOverrides() {
            if (this.mode !== 'user') return false;
            const overrides = this.userExceptions[this.selectedUserId];
            return !!(overrides && Object.keys(overrides).length > 0);
        },

        getTabCountLabel(pageKey) {
            const page = this.registry[pageKey];
            if (!page || !page.tabs || page.tabs.length === 0) return '';
            let vis = 0;
            const total = page.tabs.length;
            for (const tab of page.tabs) {
                if (this.isItemOn(tab.key)) vis++;
            }
            return `${vis}/${total}`;
        },

        saveChanges() {
            this.isSaving = true;
            const scopeId = (this.mode === 'role') ? this.selectedRoleId : this.selectedUserId;

            fetch('<?= base_url('users/menu-access/save') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
                },
                body: JSON.stringify({
                    scope_type: this.mode,
                    scope_id: scopeId,
                    items: this.workingState
                })
            })
            .then(res => res.json())
            .then(data => {
                this.isSaving = false;
                if (data.success) {
                    this.showToast(data.message || 'Preferences saved successfully.', 'success');
                    // Update local stored exceptions
                    if (this.mode === 'role') {
                        this.roleExceptions[scopeId] = {};
                        for (const [k, v] of Object.entries(this.workingState)) {
                            if (!v) {
                                this.roleExceptions[scopeId][k] = false;
                            }
                        }
                    } else {
                        const user = this.users.find(u => u.id === scopeId);
                        const roleId = user ? user.role_id : '';
                        const roleEx = this.roleExceptions[roleId] || {};
                        this.userExceptions[scopeId] = {};
                        for (const [k, v] of Object.entries(this.workingState)) {
                            const roleDefault = (roleEx[k] !== undefined) ? roleEx[k] : true;
                            if (v !== roleDefault) {
                                this.userExceptions[scopeId][k] = v;
                            }
                        }
                    }
                } else {
                    this.showToast(data.message || 'Failed to save preferences.', 'error');
                }
            })
            .catch(() => {
                this.isSaving = false;
                this.showToast('Network error while saving preferences.', 'error');
            });
        },

        resetToRole() {
            if (!confirm('Reset all menu and tab access overrides to match the role defaults?')) return;
            this.isSaving = true;

            fetch('<?= base_url('users/menu-access/reset-user') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest',
                    '<?= csrf_token() ?>': '<?= csrf_hash() ?>'
                },
                body: JSON.stringify({
                    user_id: this.selectedUserId
                })
            })
            .then(res => res.json())
            .then(data => {
                this.isSaving = false;
                if (data.success) {
                    delete this.userExceptions[this.selectedUserId];
                    this.rebuildWorkingState();
                    this.showToast(data.message || 'Overrides cleared. User now inherits role defaults.', 'success');
                    this.$nextTick(() => {
                        if (window.lucide) window.lucide.createIcons();
                    });
                } else {
                    this.showToast(data.message || 'Failed to reset overrides.', 'error');
                }
            })
            .catch(() => {
                this.isSaving = false;
                this.showToast('Network error while resetting user overrides.', 'error');
            });
        },

        showToast(message, type = 'success') {
            this.statusToast = { show: true, message: message, type: type };
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
            setTimeout(() => {
                this.statusToast.show = false;
            }, 5000);
        }
    };
}
</script>
