<?php
/**
 * Canonical System Administration & Maintenance Hub Navigation Bar
 * Shared across:
 * 1. Unified Console (/system or /system?tab=...)
 * 2. Database Backups (/system?tab=backups)
 * 3. Restore Core (/system?tab=restore)
 * 4. SMTP Gateway (/system?tab=smtp)
 * 5. Email Templates (/system?tab=templates)
 * 6. Audit Trail & Logs (/system?tab=logs)
 * 7. General Settings (/system?tab=settings)
 * 8. Security Policies (/system?tab=security)
 * 9. Theme & Styling (/system?tab=theme)
 */
$currentUrl = current_url();
$isSystemAdminRoute = (strpos($currentUrl, 'system-administration') !== false);
$baseUrl = $isSystemAdminRoute ? base_url('system-administration') : base_url('system');
$paramKey = $isSystemAdminRoute ? 'section' : 'tab';

$activeTabKey = $activeTab ?? 'backups';
if ($activeTabKey === 'general') $activeTabKey = 'settings';
if ($activeTabKey === 'styling') $activeTabKey = 'theme';
if ($activeTabKey === 'audit' || $activeTabKey === 'audit-logs') $activeTabKey = 'logs';

if (empty($activeTab)) {
    $reqTab = service('request')->getGet('tab') ?: service('request')->getGet('section');
    if (!empty($reqTab)) {
        $activeTabKey = $reqTab;
        if ($activeTabKey === 'general') $activeTabKey = 'settings';
        if ($activeTabKey === 'styling') $activeTabKey = 'theme';
        if ($activeTabKey === 'audit' || $activeTabKey === 'audit-logs') $activeTabKey = 'logs';
    } elseif (strpos($currentUrl, '/system/backups') !== false) {
        $activeTabKey = 'backups';
    } elseif (strpos($currentUrl, '/system/smtp') !== false) {
        $activeTabKey = 'smtp';
    } elseif (strpos($currentUrl, '/system/templates') !== false) {
        $activeTabKey = 'templates';
    } elseif (strpos($currentUrl, '/system/audit') !== false) {
        $activeTabKey = 'logs';
    } elseif (strpos($currentUrl, '/system/settings') !== false) {
        $activeTabKey = 'settings';
    } elseif (strpos($currentUrl, '/system/security') !== false) {
        $activeTabKey = 'security';
    } elseif (strpos($currentUrl, '/system/theme') !== false) {
        $activeTabKey = 'theme';
    }
}

$systemNavItems = [
    [
        'key'   => 'backups',
        'title' => 'Backup Manager',
        'url'   => $baseUrl . '?' . $paramKey . '=backups',
        'icon'  => 'hard-drive',
        'badge' => isset($totalCount) ? $totalCount : null
    ],
    [
        'key'   => 'restore',
        'title' => 'Restore Core',
        'url'   => $baseUrl . '?' . $paramKey . '=restore',
        'icon'  => 'archive-restore',
        'badge' => null
    ],
    [
        'key'   => 'smtp',
        'title' => 'SMTP Gateway',
        'url'   => $baseUrl . '?' . $paramKey . '=smtp',
        'icon'  => 'mail',
        'badge' => 'TLS/SSL'
    ],
    [
        'key'   => 'templates',
        'title' => 'Email Templates',
        'url'   => $baseUrl . '?' . $paramKey . '=templates',
        'icon'  => 'layout-template',
        'badge' => isset($templates) ? count($templates) : null
    ],
    [
        'key'   => 'logs',
        'title' => 'Security Audit Logs',
        'url'   => $baseUrl . '?' . $paramKey . '=logs',
        'icon'  => 'scroll',
        'badge' => isset($logs) ? count($logs) : null
    ],
    [
        'key'   => 'settings',
        'title' => 'General Settings',
        'url'   => $baseUrl . '?' . $paramKey . ($isSystemAdminRoute ? '=general' : '=settings'),
        'icon'  => 'settings',
        'badge' => null
    ],
    [
        'key'   => 'security',
        'title' => 'Security Policies',
        'url'   => $baseUrl . '?' . $paramKey . '=security',
        'icon'  => 'shield-check',
        'badge' => null
    ],
    [
        'key'   => 'theme',
        'title' => 'Theme & Styling',
        'url'   => $baseUrl . '?' . $paramKey . ($isSystemAdminRoute ? '=theme' : '=theme'),
        'icon'  => 'palette',
        'badge' => null
    ]
];

$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');
?>

<div class="flex items-center gap-1.5 p-1.5 bg-slate-100/80 dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-x-auto no-scrollbar scrollbar-none">
    <?php foreach ($systemNavItems as $nav): ?>
        <?php 
        if (!$menuVis->isVisible($currentUserId, 'system.' . $nav['key'])) continue;
        $isActive = ($activeTabKey === $nav['key']); 
        ?>
        <a href="<?= esc($nav['url']) ?>" 
           class="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap shrink-0 <?= $isActive 
            ? 'bg-indigo-600 text-white font-bold shadow-xs' 
            : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white/60 dark:hover:bg-slate-800/60' ?>">
            <i data-lucide="<?= esc($nav['icon']) ?>" class="w-3.5 h-3.5 <?= $isActive ? 'text-white' : 'text-slate-400 dark:text-slate-400' ?>"></i>
            <span><?= esc($nav['title']) ?></span>
            <?php if (!empty($nav['badge'])): ?>
                <span class="ml-0.5 px-1.5 py-0.2 rounded-md text-[10px] font-mono font-bold <?= $isActive ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300' ?>">
                    <?= esc($nav['badge']) ?>
                </span>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
