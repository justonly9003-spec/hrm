<?php
/**
 * Shared Modal Wrapper Component
 * 
 * Provides an authoritative, stacking-context-free modal wrapper that renders via Alpine's
 * x-teleport into document.body / #modal-root.
 * 
 * Specs:
 * 1. Portal: Teleported to document.body / #modal-root
 * 2. Backdrop: fixed inset-0 z-[1000] (covers sidebar z-30/50 and header z-60)
 * 3. Modal Panel: min(1100px, calc(100vw - 2rem)) desktop, inset 0.5rem (calc(100vw - 1rem)) mobile (<768px)
 * 4. Flex Layout: header & footer fixed (shrink-0), scrollable body (overflow-y: auto, min-height: 0)
 * 5. Centered: flex on backdrop, no manual margins
 * 6. Accessibility: role="dialog", aria-modal="true", autofocus on open
 * 7. Dismiss: Esc key and backdrop click (guarded by preventClose condition)
 * 8. Scroll lock: body scroll locked while open, unlocked on close and unmount
 * 
 * Parameters:
 * - $show (string, required): Alpine state variable name (e.g. 'bulkUploadModalOpen')
 * - $id (string, optional): Unique ID for accessibility
 * - $title (string, optional): Modal header title
 * - $subtitle (string, optional): Modal header subtitle
 * - $icon (string, optional): Lucide icon identifier
 * - $iconColor (string, optional): Tailwind color classes
 * - $iconBg (string, optional): Tailwind background classes
 * - $maxWidth (string, optional): Max width override (e.g. 'max-w-4xl', defaults to 'md:w-[min(1100px,calc(100vw-2rem))]')
 * - $preventClose (string, optional): Expression that prevents closing (e.g. 'isSubmitting')
 * - $headerExtra (string, optional): HTML for additional header buttons
 * - $footer (string, optional): HTML for footer actions
 * - $slot (string, optional): HTML body content
 */
$show = $show ?? 'modalOpen';
$id = $id ?? 'modal-' . bin2hex(random_bytes(4));
$title = $title ?? '';
$subtitle = $subtitle ?? '';
$icon = $icon ?? '';
$iconColor = $iconColor ?? 'text-indigo-600 dark:text-indigo-400';
$iconBg = $iconBg ?? 'bg-indigo-50 dark:bg-indigo-950/60';
$maxWidth = $maxWidth ?? 'md:w-[min(1100px,calc(100vw-2rem))]';
$preventClose = $preventClose ?? 'false';
$headerExtra = $headerExtra ?? '';
$footer = $footer ?? null;
$onClose = $onClose ?? "{$show} = false";
?>
<template x-teleport="body">
    <div x-show="<?= $show ?>"
         x-cloak
         id="<?= esc($id) ?>"
         role="dialog"
         aria-modal="true"
         aria-labelledby="<?= esc($id) ?>-title"
         @keydown.escape.window="if (!(<?= $preventClose ?>)) { <?= $onClose ?>; }"
         class="fixed inset-0 z-[1000] flex items-center justify-center p-2 md:p-4 bg-slate-900/70 backdrop-blur-xs transition-opacity"
         @click.self="if (!(<?= $preventClose ?>)) { <?= $onClose ?>; }"
         x-init="$watch('<?= $show ?>', val => {
             if (val) {
                 if (window.ModalManager) window.ModalManager.lock();
                 $nextTick(() => {
                     $el.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex=\'-1\'])')?.focus();
                 });
             } else {
                 if (window.ModalManager) window.ModalManager.unlock();
             }
         })"
         @destroy="if (window.ModalManager) window.ModalManager.unlock()"
    >
        <div class="bg-white dark:bg-slate-850 rounded-2xl md:rounded-3xl border border-slate-200/90 dark:border-slate-700/80 shadow-2xl flex flex-col overflow-hidden transition-all w-[calc(100vw-1rem)] max-h-[calc(100vh-1rem)] <?= esc($maxWidth) ?> md:max-h-[calc(100vh-2rem)]"
             @click.stop>
            
            <!-- Header (Fixed / Shrink-0) -->
            <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between bg-slate-50/80 dark:bg-slate-900/70 shrink-0">
                <div class="flex items-center gap-3 min-w-0">
                    <?php if ($icon): ?>
                    <div class="w-10 h-10 rounded-2xl <?= esc($iconBg) ?> <?= esc($iconColor) ?> flex items-center justify-center shrink-0 font-bold shadow-xs">
                        <i data-lucide="<?= esc($icon) ?>" class="w-5 h-5"></i>
                    </div>
                    <?php endif; ?>
                    <div class="truncate">
                        <h3 id="<?= esc($id) ?>-title" class="text-base font-extrabold text-slate-900 dark:text-white tracking-tight truncate"><?= esc($title) ?></h3>
                        <?php if ($subtitle): ?>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate"><?= esc($subtitle) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                    <?= $headerExtra ?>
                    <button type="button" 
                            @click="if (!(<?= $preventClose ?>)) { <?= $onClose ?>; }" 
                            class="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                            aria-label="Close dialog">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>

            <!-- Body (Scrollable, min-height: 0) -->
            <div class="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 min-h-0 custom-scrollbar">
                <?= $slot ?? $body ?? '' ?>
            </div>

            <!-- Footer (Fixed / Shrink-0) -->
            <?php if (!empty($footer)): ?>
            <div class="px-4 sm:px-6 py-3.5 sm:py-4 border-t border-slate-200/80 dark:border-slate-700/80 bg-slate-50/80 dark:bg-slate-900/70 flex items-center justify-between shrink-0">
                <?= $footer ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</template>
