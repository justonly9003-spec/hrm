<?php
    $perm = (!empty($permissionService) && is_object($permissionService)) ? $permissionService : new \App\Services\PermissionService();

    $sessionRole    = session()->get('role') ?? session()->get('role_code') ?? 'employee';
    $canonicalRole  = $perm->canonicalizeRole($sessionRole);
    $isSuperAdmin   = $perm->isSoftwareAppAdmin($sessionRole);

    // Persona-driven navbar visibility strictly verified against 6-tier hierarchy & backend authorization
    $canDashboard     = $isSuperAdmin || $perm->isNavigationVisibleForRole($canonicalRole, 'dashboard') || $perm->hasAccess(null, 'dashboard', 'view');
    $canAttendance    = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'daily-attendance') && $perm->hasAccess(null, 'attendance', 'view'));
    $canEarlyClosures = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'early-closures') && $perm->hasAccess(null, 'attendance', 'early_closures'));
    $canRoster        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'roster') && $perm->hasAccess(null, 'rostering', 'view'));
    $canSync          = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'biometric-sync') && $perm->hasAccess(null, 'attendance', 'sync'));
    $canLeave         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'leave-applications') && $perm->hasAccess(null, 'leaves', 'view'));
    $canNotice        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'bulletin-board') && $perm->hasAccess(null, 'notices', 'view'));
    $canPayroll       = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'payroll-run') && $perm->hasAccess(null, 'payroll', 'view'));
    $canPfSummary     = $isSuperAdmin || in_array($canonicalRole, ['company_admin', 'hr_admin', 'finance', 'auditor'], true) || ($perm->isNavigationVisibleForRole($canonicalRole, 'pf-summary') && ($perm->hasAccess(null, 'pf', 'view') || $perm->hasAccess(null, 'payroll', 'view')));
    $canBonus         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'bonus-runs') && $perm->hasAccess(null, 'bonus', 'view'));
    $canLoans         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'loans-advances') && $perm->hasAccess(null, 'loans', 'view'));
    $canInsurance     = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'insurance-dashboard') && $perm->hasAccess(null, 'medical_insurance', 'view')) || in_array($canonicalRole, ['software_app_admin', 'company_admin', 'hr_admin', 'hr_officer', 'finance', 'auditor', 'employee'], true);
    $canAssets        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'asset-inventory') && $perm->hasAccess(null, 'assets', 'view'));
    $canTraining      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'training-programs') && $perm->hasAccess(null, 'training', 'view'));
    $canRecruitment   = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'job-openings') && $perm->hasAccess(null, 'recruitment', 'view'));
    $canPerformance   = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'appraisal-cycles') && $perm->hasAccess(null, 'performance', 'view'));
    $canReports       = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'attendance-reports') && $perm->hasAccess(null, 'reports', 'view'));
    $canEmployees     = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'directory') && $perm->hasAccess(null, 'employees', 'view'));
    $canOrganogram    = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'organogram') && $perm->hasAccess(null, 'employees', 'view'));
    $canBranding      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-branding') && $perm->hasAccess(null, 'master', 'view'));
    $canCompanyProfile= $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-profile') && $perm->hasAccess(null, 'master', 'view'));
    $canMaster        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-branches') && $perm->hasAccess(null, 'master', 'view'));
    $canSecurity      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'roles-permissions') && $perm->hasAccess(null, 'security', 'view'));
    $canSystem        = $perm->isSoftwareAppAdmin($sessionRole);
    $canTheme         = $isSuperAdmin || $perm->hasAccess(null, 'theme', 'view');
    $currentUserId    = (string)(session()->get('user_id') ?? '');
    $canRuleEngine    = \App\Services\Rules\RuleAccessPolicy::canView($perm, $currentUserId);

    $menuVis = new \App\Services\MenuVisibilityService();

    // Menu Visibility checks per role & user override
    $visDashboard     = $canDashboard && $menuVis->isVisible($currentUserId, 'dashboard');
    $visEss           = $canDashboard && $menuVis->isVisible($currentUserId, 'ess');
    $visWidgets       = in_array($perm->canonicalizeRole(session()->get('role') ?? session()->get('role_code') ?? 'employee'), ['software_app_admin', 'company_admin'], true) && $menuVis->isVisible($currentUserId, 'dashboard_widgets');

    $visAttendance    = $canAttendance && $menuVis->isVisible($currentUserId, 'attendance');
    $visEarlyClosures = $canEarlyClosures && $menuVis->isVisible($currentUserId, 'attendance_early_closures');
    $visRoster        = $canRoster && $menuVis->isVisible($currentUserId, 'roster');
    $visSync          = $canSync && $menuVis->isVisible($currentUserId, 'biometric_sync');

    $visLeave         = $canLeave && $menuVis->isVisible($currentUserId, 'leave');
    $visNotice        = $canNotice && $menuVis->isVisible($currentUserId, 'notices');

    $visPayroll       = $canPayroll && $menuVis->isVisible($currentUserId, 'payroll');
    $visPfSummary     = $canPfSummary && $menuVis->isVisible($currentUserId, 'pf_summary');
    $visBonus         = $canBonus && $menuVis->isVisible($currentUserId, 'bonuses');
    $visLoans         = $canLoans && $menuVis->isVisible($currentUserId, 'loans');
    $visInsurance     = $canInsurance && $menuVis->isVisible($currentUserId, 'insurance');

    $visRules         = $canRuleEngine && $menuVis->isVisible($currentUserId, 'rules');

    $visTraining      = $canTraining && $menuVis->isVisible($currentUserId, 'training');
    $visRecruitment   = $canRecruitment && $menuVis->isVisible($currentUserId, 'recruitment');
    $visPerformance   = $canPerformance && $menuVis->isVisible($currentUserId, 'performance');
    $visAssets        = $canAssets && $menuVis->isVisible($currentUserId, 'assets');

    $visReports       = $canReports && $menuVis->isVisible($currentUserId, 'reports');
    $visReportsUpload = $canReports && $menuVis->isVisible($currentUserId, 'reports_upload');

    $visBranding      = $canBranding && $menuVis->isVisible($currentUserId, 'branding');
    $visCompanyProfile= $canCompanyProfile && $menuVis->isVisible($currentUserId, 'company_profile');
    $visEmployees     = $canEmployees && $menuVis->isVisible($currentUserId, 'employees');
    $visOrganogram    = $canOrganogram && $menuVis->isVisible($currentUserId, 'organogram');
    $visMaster        = $canMaster && $menuVis->isVisible($currentUserId, 'master');
    $visSecurity      = $canSecurity && $menuVis->isVisible($currentUserId, 'security');
    $visSystem        = $canSystem && $menuVis->isVisible($currentUserId, 'system');

    $sidebarCompanyName = !empty($activeCompany['name']) ? $activeCompany['name'] : (session()->get('company_name') ?: 'Mercury Medical');
    $rawSidebarLogo     = $activeCompany['logo'] ?? session()->get('company_logo') ?? null;
    $sidebarCompanyLogo = null;
    if (!empty($rawSidebarLogo)) {
        if (str_starts_with($rawSidebarLogo, 'http://') || str_starts_with($rawSidebarLogo, 'https://') || str_starts_with($rawSidebarLogo, 'data:')) {
            $sidebarCompanyLogo = $rawSidebarLogo;
        } else {
            $sidebarCompanyLogo = base_url(ltrim($rawSidebarLogo, '/'));
        }
    }
?>
<aside id="main-sidebar" class="w-64 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 flex-shrink-0 hidden md:flex flex-col border-r border-slate-200/80 dark:border-slate-800 transition-colors duration-200 z-30 select-none h-full max-h-full md:sticky md:top-0 overflow-hidden">
    <!-- Brand Header (Desktop & Mobile) -->
    <div class="h-16 flex items-center justify-between px-4 border-b border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-950 shrink-0">
        <a href="<?= base_url('dashboard') ?>" class="flex items-center gap-2.5 overflow-hidden group">
            <div class="w-8 h-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-md shrink-0 overflow-hidden ring-1 ring-indigo-500/30">
                <?php if (!empty($sidebarCompanyLogo)): ?>
                    <img src="<?= esc($sidebarCompanyLogo) ?>" alt="Logo" class="w-full h-full object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                    <span style="display:none;" class="w-full h-full flex items-center justify-center font-bold text-white"><?= strtoupper(substr($sidebarCompanyName, 0, 1)) ?></span>
                <?php else: ?>
                    <i data-lucide="sparkles" class="w-4 h-4 text-white"></i>
                <?php endif; ?>
            </div>
            <div class="flex flex-col truncate">
                <span class="font-bold text-sm tracking-tight text-slate-900 dark:text-white truncate">
                    <?= esc($sidebarCompanyName) ?>
                </span>
                <span class="text-[10px] text-slate-400 font-mono uppercase tracking-wider">
                    <?php
                        if ($isSuperAdmin) {
                            echo 'Software Owner';
                        } elseif ($canonicalRole === 'employee') {
                            echo 'Self-Service (ESS)';
                        } elseif ($canonicalRole === 'manager') {
                            echo 'Manager Workspace';
                        } elseif ($canonicalRole === 'finance') {
                            echo 'Finance Hub';
                        } elseif ($canonicalRole === 'auditor') {
                            echo 'Auditor Suite';
                        } else {
                            echo 'Company Admin';
                        }
                    ?>
                </span>
            </div>
        </a>
        <button type="button" onclick="toggleMobileSidebar()" class="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer" title="Close menu">
            <i data-lucide="x" class="w-4 h-4"></i>
        </button>
    </div>
    
    <!-- Navigation Menu -->
    <nav class="flex-1 px-3 py-4 space-y-5 overflow-y-auto text-xs font-medium custom-scrollbar">
        <!-- Section: Overview -->
        <?php if ($visDashboard || $visEss || $visWidgets): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Overview & ESS</div>
            <div class="space-y-1">
                <?php 
                    $isEssActive = (strpos(current_url(), '/ess') !== false);
                    $isDashboardActive = !$isEssActive && (strpos(current_url(), '/dashboard') !== false || current_url() == base_url() || current_url() == base_url('/'));
                ?>
                <?php 
                    $sessionRoleCode = $perm->canonicalizeRole(session()->get('role') ?? session()->get('role_code') ?? 'employee');
                    $isAdminRole = in_array($sessionRoleCode, ['software_app_admin', 'company_admin'], true);
                    $isWidgetsActive = (strpos(current_url(), '/dashboard/widgets') !== false || strpos(current_url(), '/dashboard/manage') !== false);
                ?>
                <?php if ($visDashboard): ?>
                <a href="<?= base_url('dashboard') ?>" title="Dashboard" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isDashboardActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="layout-grid" class="w-4 h-4 shrink-0 <?= $isDashboardActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Dashboard</span>
                </a>
                <?php endif; ?>
                <?php if ($visEss): ?>
                <a href="<?= base_url('ess') ?>" title="Self-Service (ESS)" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isEssActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="user-check" class="w-4 h-4 shrink-0 <?= $isEssActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Self-Service (ESS)</span>
                    </div>
                    <span class="text-[9px] font-bold px-1.5 py-0.5 rounded-md font-mono shrink-0 ml-1.5 <?= $isEssActive ? 'bg-indigo-700 text-indigo-100' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' ?>">
                        PORTAL
                    </span>
                </a>
                <?php endif; ?>
                <?php if ($visWidgets): ?>
                <a href="<?= base_url('dashboard/widgets') ?>" title="Dashboard Widgets" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isWidgetsActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="sliders" class="w-4 h-4 shrink-0 <?= $isWidgetsActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Dashboard Widgets</span>
                    </div>
                    <span class="text-[9px] font-bold px-1.5 py-0.5 rounded-md font-mono shrink-0 ml-1.5 <?= $isWidgetsActive ? 'bg-indigo-700 text-indigo-100' : 'bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300 border border-purple-200 dark:border-purple-800' ?>">
                        RBAC
                    </span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Section: Time & Attendance -->
        <?php if ($visAttendance || $visEarlyClosures || $visRoster || $visSync): ?>
        <?php 
            $isRosterActive = (strpos(current_url(), '/attendance/roster') !== false || strpos(current_url(), '/roster') !== false);
            $isDutyActive = (strpos(current_url(), '/duty-assignments') !== false || strpos(current_url(), '/duty_assignments') !== false || strpos(current_url(), '/attendance/duty-assignments') !== false || strpos(current_url(), '/attendance/duty_assignments') !== false);
            $isSyncActive = (strpos(current_url(), '/attendance/sync') !== false || strpos(current_url(), '/sync') !== false);
            $isEarlyClosuresActive = (strpos(current_url(), '/attendance/early-closures') !== false || (isset($_GET['tab']) && $_GET['tab'] === 'early-closures'));
            $isAttendanceActive = (strpos(current_url(), '/attendance') !== false && !$isRosterActive && !$isDutyActive && !$isSyncActive && !$isEarlyClosuresActive);
        ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Time & Attendance</div>
            <div class="space-y-1">
                <?php if ($visAttendance): ?>
                <a href="<?= base_url('attendance') ?>" title="Attendance Tracker" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isAttendanceActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="clock" class="w-4 h-4 shrink-0 <?= $isAttendanceActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Attendance Tracker</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isAttendanceActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">LIVE</span>
                </a>
                <?php endif; ?>

                <?php if ($visEarlyClosures): ?>
                <a href="<?= base_url('attendance?tab=early-closures') ?>" title="Company Early Closures" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isEarlyClosuresActive ? 'bg-emerald-600 text-white font-bold shadow-sm shadow-emerald-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="building-2" class="w-4 h-4 shrink-0 <?= $isEarlyClosuresActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Company Early Closures</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isEarlyClosuresActive ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' ?>">Credit</span>
                </a>
                <?php endif; ?>

                <?php if ($visRoster): ?>
                <a href="<?= base_url('attendance/roster') ?>" title="Shift & Roster" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isRosterActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="calendar-range" class="w-4 h-4 shrink-0 <?= $isRosterActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Shift & Roster</span>
                </a>
                <?php endif; ?>

                <?php if ($visRoster || $visAttendance): ?>
                <a href="<?= base_url('duty-assignments') ?>" title="Duty Assignments" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isDutyActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="shield-check" class="w-4 h-4 shrink-0 <?= $isDutyActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Duty Assignments</span>
                </a>
                <?php endif; ?>

                <?php if ($visSync): ?>
                <a href="<?= base_url('attendance/sync') ?>" title="Biometric Device" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isSyncActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="refresh-cw" class="w-4 h-4 shrink-0 <?= $isSyncActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Biometric Device</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isSyncActive ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' ?>">Device</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Section: Leaves & Notices -->
        <?php if ($visLeave || $visNotice): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Leaves & Notices</div>
            <div class="space-y-1">
                <?php 
                    $isLeaveActive = (strpos(current_url(), '/leave') !== false);
                    $isNoticeActive = (strpos(current_url(), '/notices') !== false);
                ?>
                <?php if ($visLeave): ?>
                <a href="<?= base_url('leave') ?>" title="Leave Management" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isLeaveActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="calendar-off" class="w-4 h-4 shrink-0 <?= $isLeaveActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Leave Management</span>
                </a>
                <?php endif; ?>

                <?php if ($visNotice): ?>
                <a href="<?= base_url('notices') ?>" title="Notice Board" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isNoticeActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="megaphone" class="w-4 h-4 shrink-0 <?= $isNoticeActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Notice Board</span>
                    </div>
                    <?php if (!empty($activeNoticesCount) && $activeNoticesCount > 0): ?>
                        <span class="px-1.5 py-0.5 text-[10px] font-bold rounded-md shrink-0 ml-1.5 <?= $isNoticeActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800' ?> font-mono">
                            <?= $activeNoticesCount ?>
                        </span>
                    <?php endif; ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Section: Payroll & Compensation -->
        <?php if ($visPayroll || $visPfSummary || $visBonus || $visLoans || $visInsurance): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Payroll & Compensation</div>
            <div class="space-y-1">
                <?php 
                    $isBonusActive = (strpos(current_url(), '/payroll/bonuses') !== false || strpos(current_url(), '/bonuses') !== false);
                    $isLoanActive = (strpos(current_url(), '/payroll/loans') !== false || strpos(current_url(), '/loans') !== false);
                    $isPfActive = (strpos(current_url(), '/pf/reports') !== false || strpos(current_url(), '/pf') !== false);
                    $isPayrollActive = (strpos(current_url(), '/payroll') !== false && !$isBonusActive && !$isLoanActive && !$isPfActive);
                ?>
                <?php if ($visPayroll): ?>
                <a href="<?= base_url('payroll') ?>" title="Payroll & Salary" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isPayrollActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="banknote" class="w-4 h-4 shrink-0 <?= $isPayrollActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Payroll & Salary</span>
                </a>
                <?php endif; ?>

                <?php if ($visPfSummary): ?>
                <a href="<?= base_url('pf/reports/summary') ?>" title="Provident Fund Summary" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isPfActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="piggy-bank" class="w-4 h-4 shrink-0 <?= $isPfActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Provident Fund Summary</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isPfActive ? 'bg-white/20 text-white' : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200/60 dark:border-amber-800/60' ?>">PF</span>
                </a>
                <?php endif; ?>

                <?php if ($visBonus): ?>
                <a href="<?= base_url('payroll/bonuses') ?>" title="Bonuses & Incentives" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isBonusActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="gift" class="w-4 h-4 shrink-0 <?= $isBonusActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Bonuses & Incentives</span>
                </a>
                <?php endif; ?>

                <?php if ($visLoans): ?>
                <a href="<?= base_url('payroll/loans') ?>" title="Employee Loans" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isLoanActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="wallet" class="w-4 h-4 shrink-0 <?= $isLoanActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Employee Loans</span>
                </a>
                <?php endif; ?>

                <?php if ($visInsurance): ?>
                <?php 
                    $isInsuranceActive = (strpos(current_url(), '/insurance') !== false);
                ?>
                <a href="<?= base_url('insurance') ?>" title="Medical Insurance" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isInsuranceActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="shield-plus" class="w-4 h-4 shrink-0 <?= $isInsuranceActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Medical Insurance</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isInsuranceActive ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' ?>">Health</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Section: Rules & Business Policies (Single Source of Truth) -->
        <?php if ($visRules): ?>
        <?php 
            $isRuleEngineActive = (strpos(current_url(), '/rules') !== false);
        ?>
        <div>
            <div class="px-3 mb-1.5 flex items-center justify-between text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">
                <span class="truncate">Rules & Policies</span>
                <span class="px-1.5 py-0.2 rounded-md font-mono text-[9px] font-bold shrink-0 bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">SSOT</span>
            </div>
            <div class="space-y-1">
                <a href="<?= base_url('rules') ?>" title="Rule Engine (SSOT)" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isRuleEngineActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="scale" class="w-4 h-4 shrink-0 <?= $isRuleEngineActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Rule Engine</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isRuleEngineActive ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' ?>">SSOT</span>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- Section: Talent, Growth & Operations -->
        <?php if ($visTraining || $visRecruitment || $visPerformance || $visAssets): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Talent & Growth</div>
            <div class="space-y-1">
                <?php 
                    $isTrainingActive = (strpos(current_url(), '/training') !== false);
                    $isRecruitmentActive = (strpos(current_url(), '/recruitment') !== false);
                    $isPerformanceActive = (strpos(current_url(), '/performance') !== false);
                    $isAssetActive = (strpos(current_url(), '/assets') !== false || strpos(current_url(), '/company-assets') !== false);
                ?>
                <?php if ($visTraining): ?>
                <a href="<?= base_url('training') ?>" title="Training Sessions" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isTrainingActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="graduation-cap" class="w-4 h-4 shrink-0 <?= $isTrainingActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Training Sessions</span>
                </a>
                <?php endif; ?>

                <?php if ($visRecruitment): ?>
                <a href="<?= base_url('recruitment') ?>" title="Recruitment Portal" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isRecruitmentActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="user-plus" class="w-4 h-4 shrink-0 <?= $isRecruitmentActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Recruitment Portal</span>
                </a>
                <?php endif; ?>

                <?php if ($visPerformance): ?>
                <a href="<?= base_url('performance') ?>" title="Performance Management" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isPerformanceActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="target" class="w-4 h-4 shrink-0 <?= $isPerformanceActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Performance Management</span>
                </a>
                <?php endif; ?>

                <?php if ($visAssets): ?>
                <a href="<?= base_url('assets') ?>" title="Assets & Inventory" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isAssetActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="laptop" class="w-4 h-4 shrink-0 <?= $isAssetActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Assets & Inventory</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Section: Analytics & Reports -->
        <?php if ($visReports || $visReportsUpload): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Analytics & Reports</div>
            <div class="space-y-1">
                <?php 
                    $isReportUploadActive = (strpos(current_url(), '/reports/upload') !== false);
                    $isReportActive = (strpos(current_url(), '/reports') !== false && !$isReportUploadActive); 
                ?>
                <?php if ($visReports): ?>
                <a href="<?= base_url('reports') ?>" title="Analytics & Export Hub" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isReportActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="bar-chart-3" class="w-4 h-4 shrink-0 <?= $isReportActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Analytics & Export Hub</span>
                </a>
                <?php endif; ?>
                <?php if ($visReportsUpload): ?>
                <a href="<?= base_url('reports/upload') ?>" title="Report Upload Hub" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isReportUploadActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="upload-cloud" class="w-4 h-4 shrink-0 <?= $isReportUploadActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Report Upload Hub</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isReportUploadActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">Docs</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Section: Workforce & Governance -->
        <?php if ($visBranding || $visCompanyProfile || $visEmployees || $visOrganogram || $visMaster || $visSecurity || $visSystem): ?>
        <div>
            <div class="px-3 mb-1.5 text-[10px] font-extrabold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">Workforce & Governance</div>
            <div class="space-y-1">
                <?php 
                    $isEmployeeActive = (strpos(current_url(), '/employees') !== false);
                    $isCompanyBrandingActive = (strpos(current_url(), '/company/branding') !== false);
                    $isCompanyProfileActive = (strpos(current_url(), '/company/profile') !== false && !$isCompanyBrandingActive);
                    $isMasterActive = (strpos(current_url(), '/master') !== false && !$isCompanyProfileActive && !$isCompanyBrandingActive);
                    $isUserActive = (strpos(current_url(), '/users') !== false);
                    $isSystemActive = (strpos(current_url(), '/system') !== false);
                ?>
                <?php if ($visBranding): ?>
                <a href="<?= base_url('company/branding') ?>" title="Company Logo & Branding" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isCompanyBrandingActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="image" class="w-4 h-4 shrink-0 <?= $isCompanyBrandingActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Company Logo & Branding</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isCompanyBrandingActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">Logo</span>
                </a>
                <?php endif; ?>

                <?php if ($visCompanyProfile): ?>
                <a href="<?= base_url('company/profile') ?>" title="Company Profile" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isCompanyProfileActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="building-2" class="w-4 h-4 shrink-0 <?= $isCompanyProfileActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Company Profile</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isCompanyProfileActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">Org</span>
                </a>
                <?php endif; ?>

                <?php if ($visEmployees): ?>
                <a href="<?= base_url('employees') ?>" title="Employees Directory" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isEmployeeActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="users" class="w-4 h-4 shrink-0 <?= $isEmployeeActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">Employees Directory</span>
                </a>
                <?php endif; ?>

                <?php if ($visOrganogram): ?>
                <?php $isOrganogramActive = (strpos(current_url(), '/organogram') !== false); ?>
                <a href="<?= base_url('organogram') ?>" title="Employee Organogram" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isOrganogramActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="git-branch" class="w-4 h-4 shrink-0 <?= $isOrganogramActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Employee Organogram</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isOrganogramActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">Tree</span>
                </a>
                <?php endif; ?>

                <?php if ($visMaster): ?>
                <a href="<?= base_url('master') ?>" title="Master Console" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isMasterActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="layers" class="w-4 h-4 shrink-0 <?= $isMasterActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Master Console</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isMasterActive ? 'bg-white/20 text-white' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60' ?>">Core</span>
                </a>
                <?php endif; ?>

                <?php if ($visSecurity): ?>
                <?php 
                    $isGovActive = $isUserActive;
                ?>
                <a href="<?= base_url('users') ?>" title="Security & RBAC" class="flex items-center justify-between px-3 py-2 rounded-xl transition min-w-0 <?= $isGovActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <div class="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                        <i data-lucide="shield-check" class="w-4 h-4 shrink-0 <?= $isGovActive ? 'text-white' : 'text-slate-400' ?>"></i>
                        <span class="truncate whitespace-nowrap">Security & RBAC</span>
                    </div>
                    <span class="px-1.5 py-0.5 text-[9px] font-bold rounded-md shrink-0 ml-1.5 <?= $isGovActive ? 'bg-white/20 text-white' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60' ?>">RBAC</span>
                </a>
                <?php endif; ?>

                <?php if ($visSystem): ?>
                <a href="<?= base_url('system') ?>" title="System Administration" class="flex items-center gap-2.5 px-3 py-2 rounded-xl transition min-w-0 <?= $isSystemActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-500/20' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
                    <i data-lucide="sliders" class="w-4 h-4 shrink-0 <?= $isSystemActive ? 'text-white' : 'text-slate-400' ?>"></i>
                    <span class="truncate whitespace-nowrap">System Administration</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </nav>

    <!-- Bottom Active Persona Indicator -->
    <div class="p-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
        <div class="flex items-center gap-3 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 shadow-2xs">
            <div class="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60 flex items-center justify-center shrink-0">
                <i data-lucide="shield" class="w-4 h-4"></i>
            </div>
            <div class="min-w-0 flex-1">
                <div class="text-[9px] font-extrabold uppercase tracking-wider text-slate-400 dark:text-slate-500">Active Persona</div>
                <div class="text-xs font-bold text-slate-900 dark:text-white truncate"><?= esc(session()->get('role') ?? 'Super Admin') ?></div>
            </div>
        </div>
    </div>
</aside>
