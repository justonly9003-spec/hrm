<?php
/**
 * Canonical Time & Attendance Suite Top Navigation Bar
 * Shared across:
 * 1. Attendance Tracker (/attendance)
 * 2. Shift & Roster (/attendance/roster or /roster)
 * 3. Biometric Device Sync (/attendance/sync or /sync)
 */
$permService = new \App\Services\PermissionService();
$sessionRole = session()->get('role') ?? 'software_app_admin';
$canonicalRole = $permService->canonicalizeRole($sessionRole);
$isSuperAdmin = $permService->isSoftwareAppAdmin($sessionRole);

// Determine Active Tab from Route or explicit parameter
$currentUrl = current_url();
$activeKey = $activeTab ?? 'attendance';

if (empty($activeTab)) {
    if (strpos($currentUrl, '/attendance/early-closures') !== false || (isset($_GET['tab']) && $_GET['tab'] === 'early-closures')) {
        $activeKey = 'early-closures';
    } elseif (strpos($currentUrl, '/duty-assignments') !== false || strpos($currentUrl, '/attendance/duty-assignments') !== false) {
        $activeKey = 'duty-assignments';
    } elseif (strpos($currentUrl, '/attendance/roster') !== false || strpos($currentUrl, '/roster') !== false) {
        $activeKey = 'roster';
    } elseif (strpos($currentUrl, '/attendance/sync') !== false || strpos($currentUrl, '/sync') !== false) {
        $activeKey = 'sync';
    } elseif (strpos($currentUrl, '/attendance/unmatched') !== false || strpos($currentUrl, '/unmatched') !== false) {
        $activeKey = 'unmatched';
    } elseif (strpos($currentUrl, '/attendance') !== false) {
        $activeKey = 'attendance';
    }
}

// Canonical Nav Definition tied to 6-tier RBAC definition
$navItems = [
    [
        'key'      => 'attendance',
        'itemKey'  => 'attendance',
        'navbarId' => 'daily-attendance',
        'title'    => 'Attendance Tracker',
        'url'      => base_url('attendance'),
        'icon'     => 'clock',
        'badge'    => isset($logsCount) ? $logsCount : null
    ],
    [
        'key'      => 'unmatched',
        'itemKey'  => 'attendance.unmatched',
        'navbarId' => 'biometric-sync',
        'title'    => 'Unmatched Biometric Staff',
        'url'      => base_url('attendance?tab=unmatched'),
        'icon'     => 'fingerprint',
        'badge'    => isset($unmatchedCount) && $unmatchedCount > 0 ? $unmatchedCount : null
    ],
    [
        'key'      => 'early-closures',
        'itemKey'  => 'attendance.early_closures',
        'navbarId' => 'early-closures',
        'title'    => 'Company Early Closures',
        'url'      => base_url('attendance?tab=early-closures'),
        'icon'     => 'building-2',
        'badge'    => 'Credit'
    ],
    [
        'key'      => 'roster',
        'itemKey'  => 'roster',
        'navbarId' => 'roster',
        'title'    => 'Shift & Roster',
        'url'      => base_url('attendance/roster'),
        'icon'     => 'calendar-range',
        'badge'    => null
    ],
    [
        'key'      => 'duty-assignments',
        'itemKey'  => 'attendance',
        'navbarId' => 'daily-attendance',
        'title'    => 'Duty Assignments',
        'url'      => base_url('duty-assignments'),
        'icon'     => 'shield-check',
        'badge'    => null
    ],
    [
        'key'      => 'sync',
        'itemKey'  => 'attendance.sync',
        'navbarId' => 'biometric-sync',
        'title'    => 'Biometric Device Sync',
        'url'      => base_url('attendance/sync'),
        'icon'     => 'refresh-cw',
        'badge'    => isset($devicesCount) ? $devicesCount : null
    ],
];

$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');
?>

<div class="flex items-center gap-2 p-1.5 bg-slate-100/80 dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 overflow-x-auto scrollbar-none shadow-xs">
    <?php foreach ($navItems as $item): ?>
        <?php
            // Check visibility via 6-tier hierarchy and role override + MenuVisibilityService
            $isVisible = ($isSuperAdmin || $permService->isNavigationVisibleForRole($sessionRole, $item['navbarId']))
                         && $menuVis->isVisible($currentUserId, $item['itemKey']);
            if (!$isVisible) continue;

            $isActive = ($activeKey === $item['key']);
        ?>
        <a href="<?= $item['url'] ?>" 
           class="flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap shrink-0 <?= $isActive 
                ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-600/30' 
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-800' ?>">
            
            <i data-lucide="<?= $item['icon'] ?>" class="w-4 h-4 <?= $isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600' ?>"></i>
            <span><?= esc($item['title']) ?></span>

            <?php if (!empty($item['badge'])): ?>
                <span class="px-1.5 py-0.5 rounded-full text-[10px] font-bold leading-none <?= $isActive 
                    ? 'bg-white/20 text-white' 
                    : 'bg-slate-200/70 dark:bg-slate-700 text-slate-700 dark:text-slate-300' ?>">
                    <?= esc($item['badge']) ?>
                </span>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
