<footer id="app-window-footer" class="w-full shrink-0 py-2.5 px-4 sm:px-6 lg:px-8 border-t border-slate-200/90 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-slate-400 dark:text-slate-500 text-xs flex justify-between items-center z-20 shadow-xs">
    <div class="flex items-center gap-2 truncate">
        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
        <span class="truncate">&copy; <?= date('Y') ?> Enterprise HRMS. CodeIgniter 4 Architecture.</span>
    </div>
    <div class="flex items-center gap-4 shrink-0 font-medium text-[11px]">
        <span class="hidden md:inline text-slate-400">Single Rule Engine (SSOT)</span>
        <span class="text-slate-500 dark:text-slate-400 font-mono">v4.5.0 Enterprise</span>
    </div>
</footer>
