<?php
/**
 * Canonical Security & RBAC Administration Navigation Bar
 * Shared across:
 * 1. User Accounts (/users)
 * 2. Security & RBAC Suite (/users/roles)
 * 3. Login Audit Logs (/users/login-history)
 */
$permService = new \App\Services\PermissionService();
$sessionRole = session()->get('role') ?? 'software_app_admin';
$isSuperAdmin = $permService->isSoftwareAppAdmin($sessionRole);

// Determine Active Tab from Route or explicit parameter
$currentUrl = current_url();
$activeKey = $activeTab ?? 'users';

if (empty($activeTab)) {
    if (strpos($currentUrl, '/users/menu-access') !== false) {
        $activeKey = 'menu-access';
    } elseif (strpos($currentUrl, '/users/roles') !== false) {
        $activeKey = 'roles';
    } elseif (strpos($currentUrl, '/users/login-history') !== false) {
        $activeKey = 'login-audit';
    } elseif (strpos($currentUrl, '/users') !== false) {
        $activeKey = 'users';
    }
}

// Canonical Nav Definition tied to RBAC identity management
$navItems = [
    [
        'key'      => 'users',
        'navbarId' => 'users-management',
        'title'    => 'User Accounts',
        'url'      => base_url('users'),
        'icon'     => 'users',
        'badge'    => isset($usersCount) ? $usersCount : null
    ],
    [
        'key'      => 'roles',
        'navbarId' => 'roles-permissions',
        'title'    => 'Security & RBAC Suite',
        'url'      => base_url('users/roles'),
        'icon'     => 'shield-check',
        'badge'    => '6-Tier'
    ],
    [
        'key'      => 'login-audit',
        'navbarId' => 'login-audit',
        'title'    => 'Login Audit Logs',
        'url'      => base_url('users/login-history'),
        'icon'     => 'history',
        'badge'    => isset($loginLogsCount) ? $loginLogsCount : null
    ],
    [
        'key'      => 'menu-access',
        'navbarId' => 'roles-permissions',
        'title'    => 'Menu & Tab Access',
        'url'      => base_url('users/menu-access'),
        'icon'     => 'sliders',
        'badge'    => 'New'
    ]
];

$menuVis = new \App\Services\MenuVisibilityService();
$currentUserId = (string)(session()->get('user_id') ?? '');
?>

<!-- Canonical Security & RBAC Sub-Navigation Bar -->
<div class="flex items-center gap-1.5 p-1.5 bg-slate-100/80 dark:bg-slate-900/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 overflow-x-auto scrollbar-none">
    <?php foreach ($navItems as $item): ?>
        <?php 
        $itemKey = 'security.' . str_replace('-', '_', $item['key']);
        $isVisible = $isSuperAdmin || ($permService->isNavigationVisibleForRole($sessionRole, $item['navbarId']) && $menuVis->isVisible($currentUserId, $itemKey));
        if (!$isVisible) continue; // Respect RBAC and Menu Access filtering
        $isActive = ($activeKey === $item['key']);
        ?>
        <a href="<?= esc($item['url']) ?>" 
           class="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap shrink-0 <?= $isActive 
            ? 'bg-indigo-600 text-white font-bold shadow-xs' 
            : 'text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white' ?>">
            <i data-lucide="<?= esc($item['icon']) ?>" class="w-4 h-4 <?= $isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400' ?>"></i>
            <span><?= esc($item['title']) ?></span>
            <?php if (!empty($item['badge'])): ?>
                <span class="px-1.5 py-0.5 rounded-full text-[10px] font-bold <?= $isActive ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300' ?>">
                    <?= esc($item['badge']) ?>
                </span>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
