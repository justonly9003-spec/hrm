<?php
/**
 * Canonical Single Source Rule Engine Sub-Navigation Bar
 * Shared across Rule Engine views and embedded references.
 */
// Determine Active Domain/Tab from Request GET or explicit variable
$reqDomain = service('request')->getGet('domain') ?: '';
$reqTab = service('request')->getGet('tab') ?: '';
$activeDomainKey = !empty($reqDomain) ? strtoupper(trim((string)$reqDomain)) : (!empty($activeTab) ? strtoupper(trim((string)$activeTab)) : ($reqTab === 'overview' ? 'OVERVIEW' : 'OVERVIEW'));

$ruleNavItems = [
    [
        'key'    => 'OVERVIEW',
        'domain' => 'OVERVIEW',
        'title'  => 'Overview',
        'url'    => base_url('rules?tab=overview'),
        'icon'   => 'layers',
        'badge'  => ''
    ],
    [
        'key'    => 'ATTENDANCE',
        'domain' => 'ATTENDANCE',
        'title'  => 'Attendance',
        'url'    => base_url('rules?domain=ATTENDANCE'),
        'icon'   => 'clock',
        'badge'  => ''
    ],
    [
        'key'    => 'OVERTIME',
        'domain' => 'OVERTIME',
        'title'  => 'Overtime',
        'url'    => base_url('rules?domain=OVERTIME'),
        'icon'   => 'timer',
        'badge'  => ''
    ],
    [
        'key'    => 'LEAVE',
        'domain' => 'LEAVE',
        'title'  => 'Leave',
        'url'    => base_url('rules?domain=LEAVE'),
        'icon'   => 'calendar-days',
        'badge'  => ''
    ],
    [
        'key'    => 'BONUS',
        'domain' => 'BONUS',
        'title'  => 'Bonus',
        'url'    => base_url('rules?domain=BONUS'),
        'icon'   => 'gift',
        'badge'  => ''
    ],
    [
        'key'    => 'PF',
        'domain' => 'PF',
        'title'  => 'Provident Fund',
        'url'    => base_url('rules?domain=PF'),
        'icon'   => 'shield-check',
        'badge'  => ''
    ],
    [
        'key'    => 'GRATUITY',
        'domain' => 'GRATUITY',
        'title'  => 'Gratuity',
        'url'    => base_url('rules?domain=GRATUITY'),
        'icon'   => 'award',
        'badge'  => ''
    ],
    [
        'key'    => 'SETTLEMENT',
        'domain' => 'SETTLEMENT',
        'title'  => 'Settlement',
        'url'    => base_url('rules?domain=SETTLEMENT'),
        'icon'   => 'receipt',
        'badge'  => ''
    ],
    [
        'key'    => 'TAX',
        'domain' => 'TAX',
        'title'  => 'Tax',
        'url'    => base_url('rules?domain=TAX'),
        'icon'   => 'file-text',
        'badge'  => ''
    ],
    [
        'key'    => 'PAYROLL_BASICS',
        'domain' => 'PAYROLL_BASICS',
        'title'  => 'Payroll Basics',
        'url'    => base_url('rules?domain=PAYROLL_BASICS'),
        'icon'   => 'banknote',
        'badge'  => ''
    ],
];

?>

<!-- Canonical Rule Engine Horizontal Sub-Navigation Bar -->
<div class="flex items-center gap-1 p-1 bg-slate-100/90 dark:bg-slate-900/70 rounded-xl border border-slate-200/80 dark:border-slate-800 overflow-x-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden shadow-2xs">
    <?php foreach ($ruleNavItems as $item): ?>
        <?php 
        if (isset($allowedDomains) && is_array($allowedDomains)) {
            if ($item['domain'] !== 'OVERVIEW' && !in_array($item['domain'], $allowedDomains, true)) {
                continue;
            }
            if ($item['domain'] === 'OVERVIEW' && count($allowedDomains) === 1) {
                continue;
            }
        }
        $isServerActive = ($activeDomainKey === $item['domain']); 
        $itemTitle = $item['title'];
        if ($item['domain'] !== 'OVERVIEW' && class_exists(\App\Services\Rules\RuleSchemaRegistry::class)) {
            $dDef = \App\Services\Rules\RuleSchemaRegistry::domain($item['domain']);
            if (!empty($dDef['label'])) {
                $itemTitle = (string)$dDef['label'];
            }
        }
        ?>
        <a href="<?= esc($item['url']) ?>"
           @click.prevent="<?= $item['domain'] === 'OVERVIEW' ? 'selectOverviewTab()' : "selectDomain('" . $item['domain'] . "')" ?>"
           :class="{
               'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-600/30 ring-1 ring-indigo-500': activeDomain === '<?= $item['domain'] ?>',
               'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-white dark:hover:bg-slate-800': activeDomain !== '<?= $item['domain'] ?>'
           }"
           class="group flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer <?= $isServerActive ? 'bg-indigo-600 text-white font-bold shadow-sm shadow-indigo-600/30 ring-1 ring-indigo-500' : 'text-slate-600 dark:text-slate-300' ?>"
           title="Manage <?= esc($itemTitle) ?> business rules">
            <i data-lucide="<?= esc($item['icon']) ?>" 
               class="w-3.5 h-3.5 shrink-0 transition" 
               :class="{ 'text-white': activeDomain === '<?= $item['domain'] ?>', 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200': activeDomain !== '<?= $item['domain'] ?>' }"></i>
            <span><?= esc($itemTitle) ?></span>
            <template x-if="activeDomain === '<?= $item['domain'] ?>' && isDirty">
                <span class="w-2 h-2 rounded-full bg-amber-400 ring-2 ring-indigo-600 animate-pulse shrink-0" title="Unsaved changes"></span>
            </template>
            <?php if (!empty($item['badge'])): ?>
                <span class="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono transition"
                      :class="{ 'bg-white/20 text-white': activeDomain === '<?= $item['domain'] ?>', 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300': activeDomain !== '<?= $item['domain'] ?>' }">
                    <?= esc($item['badge']) ?>
                </span>
            <?php endif; ?>
        </a>
    <?php endforeach; ?>
</div>
