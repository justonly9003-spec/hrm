<?php 
    $perm = (!empty($permissionService) && is_object($permissionService)) ? $permissionService : new \App\Services\PermissionService();
    $sessionRole    = session()->get('role') ?? session()->get('role_code') ?? 'employee';
    $canonicalRole  = $perm->canonicalizeRole($sessionRole);
    $isSuperAdmin   = $perm->isSoftwareAppAdmin($sessionRole);

    $canDashboard     = $isSuperAdmin || $perm->isNavigationVisibleForRole($canonicalRole, 'dashboard') || $perm->hasAccess(null, 'dashboard', 'view');
    $canAttendance    = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'daily-attendance') && $perm->hasAccess(null, 'attendance', 'view'));
    $canEarlyClosures = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'early-closures') && $perm->hasAccess(null, 'attendance', 'early_closures'));
    $canRoster        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'roster') && $perm->hasAccess(null, 'rostering', 'view'));
    $canSync          = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'biometric-sync') && $perm->hasAccess(null, 'attendance', 'sync'));
    $canLeave         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'leave-applications') && $perm->hasAccess(null, 'leaves', 'view'));
    $canNotice        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'bulletin-board') && $perm->hasAccess(null, 'notices', 'view'));
    $canPayroll       = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'payroll-run') && $perm->hasAccess(null, 'payroll', 'view'));
    $canBonus         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'bonus-runs') && $perm->hasAccess(null, 'bonus', 'view'));
    $canLoans         = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'loans-advances') && $perm->hasAccess(null, 'loans', 'view'));
    $canAssets        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'asset-inventory') && $perm->hasAccess(null, 'assets', 'view'));
    $canTraining      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'training-programs') && $perm->hasAccess(null, 'training', 'view'));
    $canRecruitment   = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'job-openings') && $perm->hasAccess(null, 'recruitment', 'view'));
    $canPerformance   = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'appraisal-cycles') && $perm->hasAccess(null, 'performance', 'view'));
    $canReports       = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'attendance-reports') && $perm->hasAccess(null, 'reports', 'view'));
    $canEmployees     = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'directory') && $perm->hasAccess(null, 'employees', 'view'));
    $canOrganogram    = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'organogram') && $perm->hasAccess(null, 'employees', 'view'));
    $canBranding      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-branding') && $perm->hasAccess(null, 'master', 'view'));
    $canCompanyProfile= $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-profile') && $perm->hasAccess(null, 'master', 'view'));
    $canMaster        = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'company-branches') && $perm->hasAccess(null, 'master', 'view'));
    $canSecurity      = $isSuperAdmin || ($perm->isNavigationVisibleForRole($canonicalRole, 'roles-permissions') && $perm->hasAccess(null, 'security', 'view'));
    $canSystem        = $perm->isSoftwareAppAdmin($sessionRole);
    $currentUserId    = (string)(session()->get('user_id') ?? '');
    $canRuleEngine    = \App\Services\Rules\RuleAccessPolicy::canView($perm, $currentUserId);

    $isSoftwareAdmin = $isSuperAdmin;
    $hasSelectedTenant = !empty($selectedCompanyContext);
    $rawNavCompanyLogo = $hasSelectedTenant ? ($selectedCompanyContext['logo'] ?? null) : ($activeCompany['logo'] ?? session()->get('company_logo') ?? null);
    $navCompanyLogo = null;
    if (!empty($rawNavCompanyLogo)) {
        if (str_starts_with($rawNavCompanyLogo, 'http://') || str_starts_with($rawNavCompanyLogo, 'https://') || str_starts_with($rawNavCompanyLogo, 'data:')) {
            $navCompanyLogo = $rawNavCompanyLogo;
        } else {
            $navCompanyLogo = base_url(ltrim($rawNavCompanyLogo, '/'));
        }
    }
    $navCompanyName = $hasSelectedTenant ? ($selectedCompanyContext['name'] ?? 'Mercury Medical') : (!empty($activeCompany['name']) ? $activeCompany['name'] : (session()->get('company_name') ?: 'Mercury Medical'));
    $navCompanyCode = $hasSelectedTenant ? ($selectedCompanyContext['code'] ?? '') : ($activeCompany['code'] ?? '');
    $navCompanyTheme = $hasSelectedTenant ? ($selectedCompanyContext['theme_code'] ?? 'indigo') : ($activeCompany['theme_code'] ?? 'indigo');
?>
<header id="main-navbar" class="h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 flex items-center justify-between px-3 sm:px-4 z-50 transition-colors shrink-0 min-w-0 shadow-2xs">
    <div class="flex items-center gap-2.5 sm:gap-3.5 min-w-0">
        <!-- ☰ Sidebar toggle button -->
        <button type="button" id="navbar-sidebar-toggle-btn" onclick="toggleMobileSidebar()" class="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition border border-slate-200/60 dark:border-slate-700/60 cursor-pointer shrink-0" title="Toggle Sidebar (☰)">
            <i data-lucide="menu" class="w-5 h-5"></i>
        </button>

        <!-- [Mercury Medical Logo] Company Pill -->
        <div class="relative shrink-0" x-data="{ openCompanyMenu: false }">
            <button @click="openCompanyMenu = !openCompanyMenu" type="button" class="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700/80 transition shadow-2xs group cursor-pointer" title="Switch Corporate Tenant">
                <div class="w-6 h-6 rounded-lg bg-indigo-600/10 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0 overflow-hidden ring-1 ring-indigo-500/20">
                    <?php if (!empty($navCompanyLogo)): ?>
                        <img src="<?= esc($navCompanyLogo) ?>" alt="Logo" class="w-full h-full object-contain" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                        <span style="display:none;" class="w-full h-full flex items-center justify-center font-bold text-indigo-600"><?= strtoupper(substr($navCompanyName, 0, 1)) ?></span>
                    <?php else: ?>
                        <span><?= strtoupper(substr($navCompanyName, 0, 1)) ?></span>
                    <?php endif; ?>
                </div>
                <div class="text-left hidden md:block max-w-[130px] lg:max-w-[180px]">
                    <p class="text-xs font-bold text-slate-900 dark:text-white leading-tight truncate"><?= esc($navCompanyName) ?></p>
                </div>
                <?php if ($isSoftwareAdmin && !empty($allCompanies) && count($allCompanies) > 1): ?>
                    <i data-lucide="chevrons-up-down" class="w-3 h-3 text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-200 transition-colors"></i>
                <?php endif; ?>
            </button>

            <!-- Company Switcher Dropdown Popover -->
            <?php if ($isSoftwareAdmin && !empty($allCompanies) && count($allCompanies) > 1): ?>
            <div x-show="openCompanyMenu" @click.away="openCompanyMenu = false" x-cloak class="absolute left-0 top-full mt-2 w-72 sm:w-80 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2.5 z-[100] animate-in fade-in slide-in-from-top-2 duration-150">
                <div class="px-3.5 pb-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                        <span class="text-xs font-bold text-slate-900 dark:text-white">Corporate Entities</span>
                        <p class="text-[10px] text-slate-400">Select active tenant environment</p>
                    </div>
                    <?php if ($isSoftwareAdmin): ?>
                        <form method="POST" action="<?= base_url('company/select/all') ?>" class="inline m-0 p-0">
                            <?= csrf_field() ?>
                            <button type="submit" class="text-[10px] font-bold text-indigo-600 hover:underline bg-transparent border-0 p-0 cursor-pointer">Global View</button>
                        </form>
                    <?php endif; ?>
                </div>

                <div class="max-h-60 overflow-y-auto divide-y divide-slate-100/60 dark:divide-slate-800/60 custom-scrollbar py-1">
                    <?php foreach ($allCompanies as $comp): ?>
                        <?php 
                            $isCurrentComp = ($comp['id'] === ($activeCompany['id'] ?? null) || ($hasSelectedTenant && $comp['id'] === $selectedCompanyContext['id']));
                            $cLogo = !empty($comp['logo']) ? (str_starts_with($comp['logo'], 'http') || str_starts_with($comp['logo'], 'data:') ? $comp['logo'] : base_url(ltrim($comp['logo'], '/'))) : null;
                            $cTheme = $comp['theme_code'] ?? 'indigo';
                        ?>
                        <form method="POST" action="<?= base_url('company/select/' . $comp['id']) ?>" class="block m-0 p-0 w-full"
                              onsubmit="if (window.applyTheme) { window.applyTheme('<?= esc($cTheme) ?>'); }">
                            <?= csrf_field() ?>
                            <button type="submit"
                               class="w-full text-left flex items-center gap-3 px-3.5 py-2.5 transition cursor-pointer bg-transparent border-0 <?= $isCurrentComp ? 'bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-semibold' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300' ?>">
                                <div class="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden ring-1 ring-slate-200 dark:ring-slate-700">
                                    <?php if (!empty($cLogo)): ?>
                                        <img src="<?= esc($cLogo) ?>" alt="Logo" class="w-full h-full object-contain" onerror="this.style.display='none';" />
                                    <?php else: ?>
                                        <span><?= strtoupper(substr($comp['name'], 0, 1)) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center justify-between">
                                        <p class="text-xs font-bold truncate"><?= esc($comp['name']) ?></p>
                                        <?php if ($isCurrentComp): ?>
                                            <i data-lucide="check" class="w-4 h-4 text-indigo-600 shrink-0"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex items-center gap-2 mt-0.5 text-[10px] text-slate-400 font-mono">
                                        <span><?= esc($comp['code'] ?? $comp['id']) ?></span>
                                        <span>&bull;</span>
                                        <span class="capitalize"><?= esc($cTheme) ?> theme</span>
                                    </div>
                                </div>
                            </button>
                        </form>
                    <?php endforeach; ?>
                </div>

                <div class="border-t border-slate-100 dark:border-slate-800 pt-2 px-3">
                    <a href="<?= base_url('company/branding') ?>" class="flex items-center justify-center gap-2 py-1.5 text-[11px] font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-xl transition">
                        <i data-lucide="palette" class="w-3.5 h-3.5"></i>
                        <span>Configure Corporate Brand & Themes &rarr;</span>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Breadcrumbs Hierarchy: Workspace / Page -->
        <div class="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 dark:text-slate-500 font-medium truncate">
            <span class="text-slate-300 dark:text-slate-600">/</span>
            <span class="text-indigo-600 dark:text-indigo-400 font-semibold truncate"><?= esc($category ?? 'Workspace') ?></span>
            <span class="text-slate-300 dark:text-slate-600">/</span>
            <h2 class="text-xs sm:text-sm font-bold text-slate-800 dark:text-white tracking-tight truncate">
                <?= esc($title ?? 'Dashboard Overview') ?>
            </h2>
        </div>
    </div>
    
    <div class="flex items-center gap-2 sm:gap-2.5 shrink-0">
        <!-- Real-time Live Clock Widget -->
        <div id="navbar-realtime-clock" class="hidden xl:flex flex-col items-end px-3 py-1 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
            <div class="flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span id="live-clock-time" class="text-[11px] font-mono font-bold text-slate-800 dark:text-slate-200">
                    <?= date('h:i:s A') ?>
                </span>
            </div>
            <span id="live-clock-date" class="text-[9px] text-slate-400 font-medium">
                <?= date('D, M d, Y') ?>
            </span>
        </div>

        <!-- Theme Quick Selector Dropdown -->
        <div class="relative inline-block text-left">
            <button type="button" id="theme-dropdown-btn" onclick="toggleThemeDropdown()" class="relative p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center justify-center border border-transparent hover:border-slate-200/60 dark:hover:border-slate-700 cursor-pointer" title="Change Theme Accent">
                <i data-lucide="palette" class="w-5 h-5"></i>
                <span id="nav-theme-dot" class="absolute top-1 right-1 w-2.5 h-2.5 rounded-full border-2 border-white dark:border-slate-900 transition-colors shadow-2xs" style="background-color: var(--color-primary-600, #4338ca);"></span>
            </button>

            <!-- Dropdown Menu with 10 Company Color Archetypes -->
            <div id="theme-dropdown-menu" class="hidden absolute right-0 top-full mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-3 px-3 z-[100] animate-in fade-in slide-in-from-top-2 duration-150">
                <div class="flex items-center justify-between px-1 mb-2">
                    <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400">Company Themes</span>
                    <span class="text-[9px] font-mono px-1.5 py-0.5 rounded-sm bg-slate-100 dark:bg-slate-800 text-slate-500">10 Presets</span>
                </div>
                
                <div class="grid grid-cols-5 gap-2 pb-2">
                    <button type="button" onclick="changeTheme('indigo')" id="nav-swatch-indigo" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #4338ca;" title="Enterprise Indigo">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('emerald')" id="nav-swatch-emerald" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #059669;" title="Emerald Modern">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('sapphire')" id="nav-swatch-sapphire" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #0284c7;" title="Sapphire Executive">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('purple')" id="nav-swatch-purple" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #7c3aed;" title="Purple Majesty">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('amber')" id="nav-swatch-amber" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #d97706;" title="Sunset Amber">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('rose')" id="nav-swatch-rose" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #e11d48;" title="Rose Luxe">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('teal')" id="nav-swatch-teal" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #0d9488;" title="Corporate Teal">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('crimson')" id="nav-swatch-crimson" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #dc2626;" title="Crimson Guard">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('cyan')" id="nav-swatch-cyan" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #0891b2;" title="Cyan Tech">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                    <button type="button" onclick="changeTheme('slate')" id="nav-swatch-slate" class="nav-theme-swatch theme-swatch-static w-8 h-8 rounded-xl hover:scale-110 shadow-xs transition mx-auto cursor-pointer relative flex items-center justify-center border border-black/10" style="background-color: #334155;" title="Slate Minimal">
                        <svg class="w-3.5 h-3.5 text-white hidden swatch-check pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                    </button>
                </div>

                <div class="border-t border-slate-100 dark:border-slate-800 my-2"></div>

                <!-- Navigation Layout Quick Toggle in theme menu -->
                <div class="flex items-center justify-between px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-100 dark:border-slate-800 mb-2">
                    <div class="flex items-center gap-1.5 min-w-0">
                        <i data-lucide="layout" class="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0"></i>
                        <div class="truncate">
                            <span class="text-[10px] uppercase font-bold text-slate-400 block leading-tight">Layout</span>
                            <span id="current-layout-label" class="text-xs font-bold text-slate-800 dark:text-slate-200 capitalize">Sidebar</span>
                        </div>
                    </div>
                    <button type="button" 
                            id="switch-layout-btn"
                            onclick="window.toggleNavLayout(); toggleThemeDropdown();" 
                            class="px-2.5 py-1 text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 rounded-lg shadow-2xs border border-slate-200/80 dark:border-slate-600 transition cursor-pointer shrink-0">
                        Switch Layout
                    </button>
                </div>

                <!-- 3-Mode Theme Selector (Light, System, Dark) -->
                <div class="px-1 py-1">
                    <span class="text-[10px] uppercase font-bold text-slate-400 block px-1 mb-1 leading-tight">Theme Mode</span>
                    <div class="grid grid-cols-3 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                        <button type="button" 
                                onclick="window.setThemeMode('light', true)" 
                                id="nav-mode-btn-light"
                                class="nav-theme-mode-btn flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
                                title="Light Mode">
                            <i data-lucide="sun" class="w-3.5 h-3.5"></i>
                            <span class="text-[11px]">Light</span>
                        </button>
                        <button type="button" 
                                onclick="window.setThemeMode('system', true)" 
                                id="nav-mode-btn-system"
                                class="nav-theme-mode-btn flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
                                title="System Sync">
                            <i data-lucide="monitor" class="w-3.5 h-3.5"></i>
                            <span class="text-[11px]">Auto</span>
                        </button>
                        <button type="button" 
                                onclick="window.setThemeMode('dark', true)" 
                                id="nav-mode-btn-dark"
                                class="nav-theme-mode-btn flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer"
                                title="Dark Mode">
                            <i data-lucide="moon" class="w-3.5 h-3.5"></i>
                            <span class="text-[11px]">Dark</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notification Bell Center with Interactive Dropdown -->
        <div class="relative" id="navbar-notifications-container">
            <button type="button" 
                    id="navbar-notifications-btn"
                    onclick="toggleNavbarNotifications()"
                    class="relative p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition border border-transparent hover:border-slate-200/60 dark:hover:border-slate-700 group flex items-center justify-center cursor-pointer" 
                    title="Notifications">
                <i data-lucide="bell" class="w-5 h-5 text-slate-600 dark:text-slate-300 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-transform group-hover:rotate-6"></i>
                <span id="navbar-notif-badge" class="<?= (!empty($unreadNotificationsCount) && $unreadNotificationsCount > 0) ? 'flex' : 'hidden' ?> absolute top-1 right-1 items-center justify-center min-w-[17px] h-[17px] px-1 bg-rose-500 text-white font-extrabold text-[10px] rounded-full ring-2 ring-white dark:ring-slate-900 shadow-xs animate-pulse">
                    <?= (!empty($unreadNotificationsCount) && $unreadNotificationsCount > 99) ? '99+' : ($unreadNotificationsCount ?? 0) ?>
                </span>
            </button>

            <!-- Notifications Dropdown Panel -->
            <div id="navbar-notifications-panel" class="hidden absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl shadow-2xl py-3 z-[100] animate-in fade-in slide-in-from-top-2 duration-150">
                <!-- Dropdown Header -->
                <div class="px-4 pb-3 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                    <div class="flex items-center gap-2">
                        <span class="text-xs font-bold text-slate-800 dark:text-slate-100">
                            System Notifications
                        </span>
                        <span id="navbar-notif-header-badge" class="<?= (!empty($unreadNotificationsCount) && $unreadNotificationsCount > 0) ? 'inline-block' : 'hidden' ?> px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-600 dark:bg-rose-950/40">
                            <span id="navbar-notif-header-count"><?= $unreadNotificationsCount ?? 0 ?></span> new
                        </span>
                    </div>
                    <button type="button" 
                            id="navbar-mark-all-read-btn"
                            onclick="navbarMarkAllRead()" 
                            class="<?= (!empty($unreadNotificationsCount) && $unreadNotificationsCount > 0) ? 'inline-block' : 'hidden' ?> text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer">
                        Mark all read
                    </button>
                </div>

                <!-- Notifications List -->
                <div id="navbar-notif-list" class="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    <div class="p-8 text-center text-xs text-slate-400">
                        <i data-lucide="bell" class="w-6 h-6 mx-auto mb-2 opacity-50"></i>
                        Loading notifications...
                    </div>
                </div>

                <!-- Dropdown Footer -->
                <div class="border-t border-slate-100 dark:border-slate-800 pt-2 px-3 mt-1">
                    <a href="<?= base_url('notifications') ?>" 
                       class="block w-full text-center py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-xs font-bold text-indigo-600 dark:text-indigo-400 rounded-xl transition cursor-pointer">
                        Open Notification Center &rarr;
                    </a>
                </div>
            </div>
        </div>

        <!-- Admin Role Badge (As specified in layout hierarchy) -->
        <span class="hidden sm:inline-flex items-center px-2.5 py-1 rounded-xl text-[10px] font-extrabold uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800">
            <?= esc(session()->get('role') ?: 'Admin') ?>
        </span>

        <!-- Persona & User Switcher Card -->
        <div class="relative" x-data="{ open: false }">
            <button @click="open = !open" type="button" class="flex items-center gap-2.5 px-3 py-1.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-750 transition shadow-2xs cursor-pointer">
                <div class="w-8 h-8 rounded-xl bg-indigo-600/10 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center justify-center ring-2 ring-indigo-500/20 shrink-0 overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80" alt="Avatar" class="w-full h-full object-cover" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                    <span style="display:none;" class="w-full h-full flex items-center justify-center font-bold text-indigo-600"><?= strtoupper(substr(session()->get('user_name') ?: 'A', 0, 2)) ?></span>
                </div>
                <div class="text-left hidden md:block max-w-[120px] lg:max-w-[150px]">
                    <p class="text-xs font-bold text-slate-900 dark:text-white leading-tight truncate"><?= esc(session()->get('user_name') ?: 'Alexander Vance') ?></p>
                    <p class="text-[10px] text-slate-400 font-medium leading-tight truncate"><?= esc(session()->get('role') ?: 'Super Admin') ?></p>
                </div>
                <i data-lucide="chevron-down" class="w-3.5 h-3.5 text-slate-400 ml-0.5 transition-transform" :class="{ 'rotate-180': open }"></i>
            </button>

            <!-- Profile & Persona Switcher Dropdown Popover -->
            <div x-show="open" @click.away="open = false" x-cloak class="absolute right-0 top-full mt-2 w-72 sm:w-80 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] animate-in fade-in slide-in-from-top-2 duration-150">
                <!-- User Profile Header -->
                <div class="px-4 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                        <p class="text-xs font-bold text-slate-900 dark:text-white"><?= esc(session()->get('user_name') ?: 'Alexander Vance') ?></p>
                        <p class="text-[11px] text-slate-400 truncate"><?= esc(session()->get('email') ?: 'admin@hrms.enterprise.io') ?></p>
                    </div>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                        <?= esc(session()->get('role') ?: 'Admin') ?>
                    </span>
                </div>

                <!-- Persona Switcher List -->
                <?php if (!empty($personaUsers)): ?>
                <div class="px-4 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                    <span>Switch Active Persona</span>
                    <span class="text-[9px] text-indigo-600 dark:text-indigo-400 font-normal">Instant Demo</span>
                </div>
                <div class="max-h-56 overflow-y-auto divide-y divide-slate-100/60 dark:divide-slate-800/60 custom-scrollbar px-1">
                    <?php foreach ($personaUsers as $pu): ?>
                        <?php 
                            $isCurrent = ($pu['id'] === session()->get('user_id'));
                            $displayName = !empty(trim($pu['employee_name'] ?? '')) ? trim($pu['employee_name']) : $pu['username'];
                            $roleLabel = $pu['role_name'] ?? 'Employee';
                        ?>
                        <form method="POST" action="<?= base_url('auth/switch-persona/' . $pu['id']) ?>" class="block m-0 p-0 w-full">
                            <?= csrf_field() ?>
                            <button type="submit"
                               class="w-full text-left flex items-center gap-2.5 px-3 py-2 rounded-xl transition cursor-pointer bg-transparent border-0 <?= $isCurrent ? 'bg-indigo-50/80 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 font-semibold' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300' ?>">
                                <div class="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-xs shrink-0 text-slate-600 dark:text-slate-300 overflow-hidden">
                                    <?php if (!empty($pu['employee_avatar'])): ?>
                                        <img src="<?= esc($pu['employee_avatar']) ?>" alt="Avatar" class="w-full h-full object-cover" onerror="this.style.display='none';" />
                                    <?php else: ?>
                                        <span><?= strtoupper(substr($displayName, 0, 1)) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center justify-between">
                                        <p class="text-xs font-bold truncate"><?= esc($displayName) ?></p>
                                        <?php if ($isCurrent): ?>
                                            <i data-lucide="check" class="w-3.5 h-3.5 text-indigo-600 shrink-0"></i>
                                        <?php endif; ?>
                                    </div>
                                    <p class="text-[10px] text-slate-400 font-mono truncate"><?= esc($roleLabel) ?> &bull; <?= esc($pu['company_name'] ?? 'Apex Corp') ?></p>
                                </div>
                            </button>
                        </form>
                    <?php endforeach; ?>
                </div>
                <div class="border-t border-slate-100 dark:border-slate-800 my-1"></div>
                <?php endif; ?>

                <!-- User Navigation Links -->
                <?php
                    $navEmpId = session()->get('employee_id');
                    $empProfileUrl = !empty($navEmpId) 
                        ? base_url('employees/profile/' . $navEmpId) 
                        : (function_exists('can') && can('directory.view') ? base_url('employees') : base_url('employees/profile'));
                ?>
                <a href="<?= $empProfileUrl ?>" class="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                    <i data-lucide="user" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Employee Profile</span>
                </a>
                <a href="<?= base_url('company/branding') ?>" class="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                    <i data-lucide="palette" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Company Logo & Branding</span>
                </a>
                <a href="<?= base_url('users') ?>" class="flex items-center gap-2.5 px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                    <i data-lucide="shield-check" class="w-3.5 h-3.5 text-slate-400"></i>
                    <span>Security & RBAC Console</span>
                </a>
                <div class="border-t border-slate-100 dark:border-slate-800 my-1"></div>
                <?php if (!empty(session()->get('original_user_id'))): ?>
                <form method="POST" action="<?= base_url('auth/stop-impersonation') ?>" class="block m-0 p-0">
                    <?= csrf_field() ?>
                    <button type="submit" class="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 font-semibold transition text-left cursor-pointer bg-transparent border-0">
                        <i data-lucide="user-check" class="w-3.5 h-3.5 text-amber-600 dark:text-amber-400"></i>
                        <span>End Impersonation</span>
                    </button>
                </form>
                <?php endif; ?>
                <form method="POST" action="<?= base_url('auth/logout') ?>" class="block m-0 p-0">
                    <?= csrf_field() ?>
                    <button type="submit" class="w-full flex items-center gap-2.5 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 font-semibold transition text-left cursor-pointer bg-transparent border-0">
                        <i data-lucide="log-out" class="w-3.5 h-3.5 text-rose-600"></i>
                        <span>Sign Out</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</header>

<!-- Modern Topbar Horizontal Navigation Strip (Active when in Topbar Layout Mode) -->
<nav id="topbar-navigation-strip" class="hidden relative h-12 bg-white dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-6 items-center gap-1.5 overflow-visible transition-all shrink-0 z-50 shadow-xs">
    <!-- 1. Overview Menu -->
    <?php if ($canDashboard): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="layout-grid" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
            <span>Overview</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-56 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <a href="<?= base_url('dashboard') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="layout-dashboard" class="w-4 h-4 text-indigo-600"></i>
                <span>Main Dashboard</span>
            </a>
            <a href="<?= base_url('ess') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="user-check" class="w-4 h-4 text-emerald-600"></i>
                    <span>Self-Service (ESS)</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">PORTAL</span>
            </a>
            <?php if ($isSuperAdmin || in_array($canonicalRole, ['software_app_admin', 'company_admin'], true)): ?>
            <a href="<?= base_url('dashboard/widgets') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="sliders" class="w-4 h-4 text-purple-600"></i>
                    <span>Dashboard Widgets</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">RBAC</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 2. Attendance Menu -->
    <?php if ($canAttendance || $canEarlyClosures || $canRoster || $canSync): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="clock" class="w-4 h-4 text-emerald-600 dark:text-emerald-400"></i>
            <span>Attendance</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-60 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <?php if ($canAttendance): ?>
            <a href="<?= base_url('attendance') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="calendar-check" class="w-4 h-4 text-emerald-600"></i>
                    <span>Attendance Tracker</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">LIVE</span>
            </a>
            <?php endif; ?>
            <?php if ($canEarlyClosures): ?>
            <a href="<?= base_url('attendance?tab=early-closures') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="building-2" class="w-4 h-4 text-amber-600"></i>
                    <span>Early Closures</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">Credit</span>
            </a>
            <?php endif; ?>
            <?php if ($canRoster): ?>
            <a href="<?= base_url('attendance/roster') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="calendar-range" class="w-4 h-4 text-sky-600"></i>
                <span>Shift & Roster</span>
            </a>
            <?php endif; ?>
            <?php if ($canSync): ?>
            <a href="<?= base_url('attendance/sync') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="refresh-cw" class="w-4 h-4 text-slate-500"></i>
                <span>Biometric Sync</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 3. Leave & Notices Menu -->
    <?php if ($canLeave || $canNotice): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="calendar" class="w-4 h-4 text-rose-500"></i>
            <span>Leave & Notices</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-56 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <?php if ($canLeave): ?>
            <a href="<?= base_url('leave') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="calendar-days" class="w-4 h-4 text-rose-500"></i>
                <span>Leave Applications</span>
            </a>
            <a href="<?= base_url('leave?tab=balances') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="pie-chart" class="w-4 h-4 text-amber-500"></i>
                <span>Leave Entitlements</span>
            </a>
            <?php endif; ?>
            <?php if ($canNotice): ?>
            <a href="<?= base_url('notices') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="bell" class="w-4 h-4 text-purple-500"></i>
                <span>Bulletin Board</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 4. Payroll & Finance Menu -->
    <?php if ($canPayroll || $canBonus || $canLoans): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="banknote" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
            <span>Payroll</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-64 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <?php if ($canPayroll): ?>
            <a href="<?= base_url('payroll') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="calculator" class="w-4 h-4 text-indigo-600"></i>
                    <span>Execute Payroll</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">SINGLE SOURCE</span>
            </a>
            <a href="<?= base_url('payroll?tab=structure') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="layers" class="w-4 h-4 text-purple-600"></i>
                <span>Salary Structures</span>
            </a>
            <?php endif; ?>
            <?php if ($canBonus): ?>
            <a href="<?= base_url('bonus') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="gift" class="w-4 h-4 text-rose-600"></i>
                <span>Bonus Runs</span>
            </a>
            <?php endif; ?>
            <?php if ($canLoans): ?>
            <a href="<?= base_url('loans') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="credit-card" class="w-4 h-4 text-emerald-600"></i>
                <span>Loans & Advances</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 5. People & HR Menu -->
    <?php if ($canEmployees || $canOrganogram || $canPerformance || $canTraining || $canRecruitment): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="users" class="w-4 h-4 text-sky-600 dark:text-sky-400"></i>
            <span>Talent & HR</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-56 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <?php if ($canEmployees): ?>
            <a href="<?= base_url('employees') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="user" class="w-4 h-4 text-sky-600"></i>
                <span>Employee Directory</span>
            </a>
            <?php endif; ?>
            <?php if ($canOrganogram): ?>
            <a href="<?= base_url('organogram') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="network" class="w-4 h-4 text-indigo-600"></i>
                <span>Organogram</span>
            </a>
            <?php endif; ?>
            <?php if ($canPerformance): ?>
            <a href="<?= base_url('performance') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="target" class="w-4 h-4 text-emerald-600"></i>
                <span>Appraisals & Reviews</span>
            </a>
            <?php endif; ?>
            <?php if ($canTraining): ?>
            <a href="<?= base_url('training') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="graduation-cap" class="w-4 h-4 text-purple-600"></i>
                <span>Training Hub</span>
            </a>
            <?php endif; ?>
            <?php if ($canRecruitment): ?>
            <a href="<?= base_url('recruitment') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="briefcase" class="w-4 h-4 text-amber-600"></i>
                <span>Recruitment</span>
            </a>
            <?php endif; ?>
            <?php if ($canAssets): ?>
            <a href="<?= base_url('assets') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="monitor" class="w-4 h-4 text-slate-500"></i>
                <span>Asset Inventory</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 6. Reports Menu -->
    <?php if ($canReports): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="file-spreadsheet" class="w-4 h-4 text-teal-600 dark:text-teal-400"></i>
            <span>Reports</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute left-0 top-full mt-1.5 w-60 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <a href="<?= base_url('reports') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="bar-chart-3" class="w-4 h-4 text-indigo-600"></i>
                    <span>Analytics & Export Hub</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">HUB</span>
            </a>
            <a href="<?= base_url('reports/attendance') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="file-text" class="w-4 h-4 text-teal-600"></i>
                <span>Attendance Reports</span>
            </a>
            <a href="<?= base_url('reports/payroll') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="file-check" class="w-4 h-4 text-indigo-600"></i>
                <span>Payroll Statements</span>
            </a>
            <a href="<?= base_url('reports/upload') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="upload-cloud" class="w-4 h-4 text-purple-600"></i>
                    <span>Document Center</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">Docs</span>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- 7. Administration & Business Rules Menu -->
    <?php if ($canRuleEngine || $canBranding || $canCompanyProfile || $canMaster || $canSecurity || $canSystem): ?>
    <div class="relative" :class="{ 'z-[100]': openMenu, 'z-10': !openMenu }" x-data="{ openMenu: false }" @click.away="openMenu = false">
        <button @click="openMenu = !openMenu" type="button" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer">
            <i data-lucide="settings" class="w-4 h-4 text-indigo-600 dark:text-indigo-400"></i>
            <span>Administration</span>
            <i data-lucide="chevron-down" class="w-3 h-3 text-slate-400 transition-transform" :class="{ 'rotate-180': openMenu }"></i>
        </button>
        <div x-show="openMenu" x-cloak class="absolute right-0 top-full mt-1.5 w-64 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200/80 dark:border-slate-800 py-2 z-[100] pointer-events-auto animate-in fade-in slide-in-from-top-1 duration-150">
            <?php if ($canRuleEngine): ?>
            <a href="<?= base_url('rules') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="cpu" class="w-4 h-4 text-indigo-600"></i>
                    <span>Business Rules Engine</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">SINGLE SOURCE</span>
            </a>
            <?php endif; ?>
            <?php if ($canMaster): ?>
            <a href="<?= base_url('master') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="layers" class="w-4 h-4 text-indigo-600"></i>
                    <span>Master Console</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">CORE</span>
            </a>
            <?php endif; ?>
            <?php if ($canBranding): ?>
            <a href="<?= base_url('company/branding') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="palette" class="w-4 h-4 text-emerald-600"></i>
                    <span>Corporate Brand & Themes</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">THEMES</span>
            </a>
            <?php endif; ?>
            <?php if ($canCompanyProfile): ?>
            <a href="<?= base_url('company/profile') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="building" class="w-4 h-4 text-slate-500"></i>
                    <span>Company Profile</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">ORG</span>
            </a>
            <?php endif; ?>
            <?php if ($canSecurity): ?>
            <a href="<?= base_url('users') ?>" class="flex items-center justify-between px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <div class="flex items-center gap-2.5">
                    <i data-lucide="shield-check" class="w-4 h-4 text-purple-600"></i>
                    <span>Security & RBAC</span>
                </div>
                <span class="text-[9px] font-bold px-1 rounded-sm bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">RBAC</span>
            </a>
            <?php endif; ?>
            <?php if ($canSystem): ?>
            <a href="<?= base_url('system') ?>" class="flex items-center gap-2.5 px-3.5 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium transition cursor-pointer">
                <i data-lucide="server" class="w-4 h-4 text-rose-600"></i>
                <span>Platform Settings</span>
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</nav>

<script>
    // Live ticking clock matching React Header.tsx
    (function initNavbarClock() {
        function updateClock() {
            const timeEl = document.getElementById('live-clock-time');
            const dateEl = document.getElementById('live-clock-date');
            if (!timeEl || !dateEl) return;
            const now = new Date();
            timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
            dateEl.textContent = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
        }
        updateClock();
        setInterval(updateClock, 1000);
    })();

    function toggleThemeDropdown() {
        const menu = document.getElementById('theme-dropdown-menu');
        if (menu) {
            const isHidden = menu.classList.toggle('hidden');
            if (!isHidden) {
                updateNavbarThemeSwatchesUI();
            }
        }
    }

    // Auto-close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const btn = document.getElementById('theme-dropdown-btn');
        const menu = document.getElementById('theme-dropdown-menu');
        if (menu && !menu.classList.contains('hidden')) {
            if (btn && !btn.contains(e.target) && !menu.contains(e.target)) {
                menu.classList.add('hidden');
            }
        }
    });

    function changeTheme(themeId) {
        if (window.applyTheme) {
            window.applyTheme(themeId, null, true);
        }
        updateNavbarThemeSwatchesUI(themeId);
        const menu = document.getElementById('theme-dropdown-menu');
        if (menu) {
            menu.classList.add('hidden');
        }
    }

    function toggleThemeDark() {
        if (window.toggleThemeDark) {
            window.toggleThemeDark();
        } else {
            const isDark = document.documentElement.classList.contains('dark');
            const currentTheme = localStorage.getItem('ci4_theme') || (window.ACTIVE_COMPANY_THEME || 'indigo');
            if (window.applyTheme) {
                window.applyTheme(currentTheme, !isDark ? 'dark' : 'light', true);
            }
        }
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    function updateNavbarThemeSwatchesUI(activeThemeId) {
        activeThemeId = activeThemeId || (window.ACTIVE_COMPANY_ID ? localStorage.getItem('ci4_theme_' + window.ACTIVE_COMPANY_ID) : null) || window.USER_THEME || window.ACTIVE_COMPANY_THEME || localStorage.getItem('ci4_theme') || 'indigo';
        document.querySelectorAll('.nav-theme-swatch').forEach(btn => {
            btn.classList.remove('ring-2', 'ring-offset-2', 'ring-slate-900', 'dark:ring-white', 'ring-offset-white', 'dark:ring-offset-slate-900', 'scale-110', 'shadow-md');
            const check = btn.querySelector('.swatch-check');
            if (check) check.classList.add('hidden');
        });
        const activeBtn = document.getElementById('nav-swatch-' + activeThemeId);
        if (activeBtn) {
            activeBtn.classList.add('ring-2', 'ring-offset-2', 'ring-slate-900', 'dark:ring-white', 'ring-offset-white', 'dark:ring-offset-slate-900', 'scale-110', 'shadow-md');
            const check = activeBtn.querySelector('.swatch-check');
            if (check) check.classList.remove('hidden');
        }
        const themeDot = document.getElementById('nav-theme-dot');
        if (themeDot && window.THEME_DEFINITIONS && window.THEME_DEFINITIONS[activeThemeId]) {
            themeDot.style.backgroundColor = window.THEME_DEFINITIONS[activeThemeId].p600 || window.THEME_DEFINITIONS[activeThemeId].primaryHex;
        }
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    function updateNavbarThemeModeUI(mode) {
        mode = mode || localStorage.getItem('ci4_theme_mode') || 'system';
        ['light', 'system', 'dark'].forEach(m => {
            const btn = document.getElementById('nav-mode-btn-' + m);
            if (!btn) return;
            if (m === mode) {
                btn.className = 'nav-theme-mode-btn flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-white dark:bg-slate-700 shadow-xs transition cursor-pointer';
            } else {
                btn.className = 'nav-theme-mode-btn flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition cursor-pointer';
            }
        });
    }

    window.addEventListener('ci4-theme-changed', (e) => {
        if (e.detail) {
            if (e.detail.mode) {
                updateNavbarThemeModeUI(e.detail.mode);
            }
            if (e.detail.theme) {
                updateNavbarThemeSwatchesUI(e.detail.theme);
            }
        }
    });

    document.addEventListener('DOMContentLoaded', () => {
        updateNavbarThemeModeUI();
        updateNavbarThemeSwatchesUI();
    });

    // Notification Dropdown Handler
    function toggleNavbarNotifications() {
        const panel = document.getElementById('navbar-notifications-panel');
        if (!panel) return;
        const isHidden = panel.classList.contains('hidden');
        if (isHidden) {
            panel.classList.remove('hidden');
            loadNavbarNotifications();
        } else {
            panel.classList.add('hidden');
        }
    }

    async function loadNavbarNotifications() {
        const listEl = document.getElementById('navbar-notif-list');
        if (!listEl) return;
        try {
            const res = await fetch('<?= base_url('notifications/recent') ?>', {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();
            if (data.status === 'success') {
                updateNavbarBadge(data.unreadCount);
                renderNavbarNotifList(data.notifications || []);
            }
        } catch (e) {
            console.error('Failed to load notifications:', e);
        }
    }

    function updateNavbarBadge(count) {
        const badge = document.getElementById('navbar-notif-badge');
        const headerBadge = document.getElementById('navbar-notif-header-badge');
        const headerCount = document.getElementById('navbar-notif-header-count');
        const markAllBtn = document.getElementById('navbar-mark-all-read-btn');

        if (badge) {
            if (count > 0) {
                badge.classList.remove('hidden');
                badge.classList.add('flex');
                badge.innerText = count > 99 ? '99+' : count;
            } else {
                badge.classList.remove('flex');
                badge.classList.add('hidden');
            }
        }

        if (headerBadge && headerCount) {
            if (count > 0) {
                headerBadge.classList.remove('hidden');
                headerBadge.classList.add('inline-block');
                headerCount.innerText = count;
                if (markAllBtn) markAllBtn.classList.remove('hidden');
            } else {
                headerBadge.classList.remove('inline-block');
                headerBadge.classList.add('hidden');
                if (markAllBtn) markAllBtn.classList.add('hidden');
            }
        }
    }

    function renderNavbarNotifList(notifications) {
        const listEl = document.getElementById('navbar-notif-list');
        if (!listEl) return;

        if (notifications.length === 0) {
            listEl.innerHTML = `
                <div class="py-8 text-center text-slate-400">
                    <p class="text-xs">No notifications found.</p>
                </div>
            `;
            return;
        }

        let html = '';
        notifications.forEach(n => {
            const isUnread = !n.is_read || n.is_read == 0;
            const priorityColor = n.priority === 'Critical' ? 'bg-rose-500 text-white' : 
                                 (n.priority === 'High' ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300');
            const bgHighlight = isUnread ? 'bg-indigo-50/60 dark:bg-indigo-950/20' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60';

            html += `
                <div class="px-4 py-3 flex gap-3 cursor-pointer transition ${bgHighlight}" onclick="handleNavbarNotifClick('${n.id}', '${n.link || ''}')">
                    <div class="mt-0.5 relative shrink-0">
                        <div class="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 text-xs font-bold">
                            ${n.related_module ? n.related_module.substring(0, 2).toUpperCase() : 'SYS'}
                        </div>
                        ${isUnread ? '<span class="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-indigo-600 rounded-full ring-2 ring-white dark:ring-slate-900"></span>' : ''}
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between gap-1 mb-0.5">
                            <span class="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">${n.title}</span>
                            <span class="text-[10px] text-slate-400 shrink-0">${n.relative_time || 'Just now'}</span>
                        </div>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed mb-1">${n.message}</p>
                        <div class="flex items-center gap-1.5">
                            <span class="text-[9px] font-bold px-1.5 py-0.5 rounded-sm ${priorityColor}">${n.priority || 'Normal'}</span>
                            <span class="text-[9px] text-slate-400">${n.related_module || 'System'}</span>
                        </div>
                    </div>
                </div>
            `;
        });
        listEl.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    async function handleNavbarNotifClick(id, link) {
        try {
            await fetch('<?= base_url('notifications/mark-read/') ?>' + id, {
                method: 'POST',
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
            });
        } catch (e) {}
        if (link) {
            window.location.href = '<?= base_url() ?>/' + link;
        } else {
            window.location.href = '<?= base_url('notifications') ?>';
        }
    }

    async function navbarMarkAllRead() {
        try {
            const res = await fetch('<?= base_url('notifications/mark-all-read') ?>', {
                method: 'POST',
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
            });
            const data = await res.json();
            if (data.status === 'success') {
                updateNavbarBadge(0);
                loadNavbarNotifications();
            }
        } catch (e) {
            console.error('Failed to mark all read:', e);
        }
    }

    // Close dropdown on outside click
    document.addEventListener('click', function(e) {
        const themeBtn = document.getElementById('theme-dropdown-btn');
        const themeMenu = document.getElementById('theme-dropdown-menu');
        if (themeBtn && themeMenu && !themeBtn.contains(e.target) && !themeMenu.contains(e.target)) {
            themeMenu.classList.add('hidden');
        }

        const notifContainer = document.getElementById('navbar-notifications-container');
        const notifPanel = document.getElementById('navbar-notifications-panel');
        if (notifContainer && notifPanel && !notifContainer.contains(e.target)) {
            notifPanel.classList.add('hidden');
        }
    });

    // Background unread polling every 30 seconds when tab is active (singleton interval)
    if (window._ci4NotifPollInterval) {
        clearInterval(window._ci4NotifPollInterval);
        window._ci4NotifPollInterval = null;
    }
    window._ci4NotifPollInterval = setInterval(async () => {
        if (document.hidden) return;
        try {
            const res = await fetch('<?= base_url('notifications/unread-count') ?>', {
                headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
            });
            if (res.ok) {
                const data = await res.json();
                if (data && data.status === 'success') {
                    updateNavbarBadge(data.unreadCount);
                }
            }
        } catch (e) {}
    }, 30000);
</script>
