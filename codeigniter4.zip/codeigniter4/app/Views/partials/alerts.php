<?php
    $successMessage = session()->getFlashdata('success') ?? ($success ?? null);
    $errorMessage   = session()->getFlashdata('error') ?? ($error ?? null);
    $warningMessage = session()->getFlashdata('warning') ?? ($warning ?? null);
    $infoMessage    = session()->getFlashdata('info') ?? ($info ?? null);
    $generalMessage = session()->getFlashdata('message') ?? ($message ?? null);

    // Collect validation error(s)
    $validationErrors = session()->getFlashdata('validation') 
        ?? session()->getFlashdata('errors') 
        ?? ($errors ?? null);

    if (is_string($validationErrors)) {
        $validationErrors = [$validationErrors];
    } elseif (!is_array($validationErrors)) {
        $validationErrors = null;
    }

    $hasAnyAlert = !empty($successMessage) 
        || !empty($errorMessage) 
        || !empty($warningMessage) 
        || !empty($infoMessage) 
        || !empty($generalMessage) 
        || !empty($validationErrors);
?>

<div id="main-content-alert-container" class="alert-container w-full relative space-y-3 <?= !$hasAnyAlert ? 'hidden' : '' ?>">
    <!-- Success Alert -->
    <?php if (!empty($successMessage)): ?>
        <div class="alert-item w-full p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 flex items-center justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200" role="alert">
            <div class="flex items-center gap-3 min-w-0">
                <i data-lucide="check-circle-2" class="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0"></i>
                <span class="font-medium break-words"><?= esc($successMessage) ?></span>
            </div>
            <button type="button" onclick="this.closest('.alert-item').remove()" class="p-1 text-emerald-600 hover:text-emerald-900 dark:text-emerald-400 dark:hover:text-emerald-200 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Error Alert -->
    <?php if (!empty($errorMessage)): ?>
        <div class="alert-item w-full p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 flex items-center justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200" role="alert">
            <div class="flex items-center gap-3 min-w-0">
                <i data-lucide="alert-circle" class="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0"></i>
                <span class="font-medium break-words"><?= esc($errorMessage) ?></span>
            </div>
            <button type="button" onclick="this.closest('.alert-item').remove()" class="p-1 text-rose-600 hover:text-rose-900 dark:text-rose-400 dark:hover:text-rose-200 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Warning Alert -->
    <?php if (!empty($warningMessage)): ?>
        <div class="alert-item w-full p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 flex items-center justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200" role="alert">
            <div class="flex items-center gap-3 min-w-0">
                <i data-lucide="alert-triangle" class="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0"></i>
                <span class="font-medium break-words"><?= esc($warningMessage) ?></span>
            </div>
            <button type="button" onclick="this.closest('.alert-item').remove()" class="p-1 text-amber-600 hover:text-amber-900 dark:text-amber-400 dark:hover:text-amber-200 rounded-lg hover:bg-amber-100 dark:hover:bg-amber-900/50 transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Information / General Message Alert -->
    <?php if (!empty($infoMessage) || !empty($generalMessage)): ?>
        <div class="alert-item w-full p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-300 flex items-center justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200" role="alert">
            <div class="flex items-center gap-3 min-w-0">
                <i data-lucide="info" class="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0"></i>
                <span class="font-medium break-words"><?= esc($infoMessage ?? $generalMessage) ?></span>
            </div>
            <button type="button" onclick="this.closest('.alert-item').remove()" class="p-1 text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-200 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Validation / Form Errors Alert -->
    <?php if (!empty($validationErrors)): ?>
        <div class="alert-item w-full p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300 flex items-start justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200" role="alert">
            <div class="flex items-start gap-3 min-w-0">
                <i data-lucide="alert-circle" class="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5"></i>
                <div class="space-y-1">
                    <p class="font-semibold text-rose-900 dark:text-rose-200">Validation Errors:</p>
                    <ul class="list-disc list-inside space-y-0.5 text-xs text-rose-700 dark:text-rose-300">
                        <?php foreach ($validationErrors as $err): ?>
                            <li><?= esc($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <button type="button" onclick="this.closest('.alert-item').remove()" class="p-1 text-rose-600 hover:text-rose-900 dark:text-rose-400 dark:hover:text-rose-200 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        </div>
    <?php endif; ?>
</div>

<script>
    // Global client-side alert dispatcher for dynamic API responses & JS validation
    window.showAlert = function(message, type = 'info', timeout = 0) {
        const container = document.getElementById('main-content-alert-container');
        if (!container) return;
        container.classList.remove('hidden');

        const themes = {
            success: {
                bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300',
                icon: 'check-circle-2',
                iconColor: 'text-emerald-600 dark:text-emerald-400',
                btnColor: 'text-emerald-600 hover:text-emerald-900 dark:text-emerald-400 dark:hover:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-900/50'
            },
            error: {
                bg: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300',
                icon: 'alert-circle',
                iconColor: 'text-rose-600 dark:text-rose-400',
                btnColor: 'text-rose-600 hover:text-rose-900 dark:text-rose-400 dark:hover:text-rose-200 hover:bg-rose-100 dark:hover:bg-rose-900/50'
            },
            warning: {
                bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300',
                icon: 'alert-triangle',
                iconColor: 'text-amber-600 dark:text-amber-400',
                btnColor: 'text-amber-600 hover:text-amber-900 dark:text-amber-400 dark:hover:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/50'
            },
            info: {
                bg: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-300',
                icon: 'info',
                iconColor: 'text-indigo-600 dark:text-indigo-400',
                btnColor: 'text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-900/50'
            }
        };

        const currentTheme = themes[type] || themes.info;

        const alertItem = document.createElement('div');
        alertItem.className = `alert-item w-full p-4 rounded-2xl ${currentTheme.bg} border flex items-center justify-between gap-3 text-sm shadow-xs animate-in fade-in duration-200`;
        alertItem.setAttribute('role', 'alert');

        alertItem.innerHTML = `
            <div class="flex items-center gap-3 min-w-0">
                <i data-lucide="${currentTheme.icon}" class="w-5 h-5 ${currentTheme.iconColor} shrink-0"></i>
                <span class="font-medium break-words">${message}</span>
            </div>
            <button type="button" class="p-1 ${currentTheme.btnColor} rounded-lg transition cursor-pointer shrink-0" aria-label="Dismiss alert">
                <i data-lucide="x" class="w-4 h-4"></i>
            </button>
        `;

        alertItem.querySelector('button').addEventListener('click', () => alertItem.remove());

        container.appendChild(alertItem);
        if (typeof lucide !== 'undefined') {
            lucide.createIcons({ root: alertItem });
        }

        if (timeout > 0) {
            setTimeout(() => {
                alertItem.remove();
            }, timeout);
        }
    };
</script>
