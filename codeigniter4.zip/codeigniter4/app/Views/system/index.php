<div class="space-y-6" id="system-module">
    <!-- Header Block -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                <i data-lucide="hard-drive" class="w-7 h-7 text-indigo-600"></i>
                System Administration & Maintenance Hub
            </h1>
            <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">Super Admin Console: Database backups, system restore engine, SMTP email gateways, custom email templates, and real-time security audit logging.</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-xs font-mono bg-slate-100 dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 px-3.5 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-900/60 flex items-center gap-2 font-semibold shadow-2xs">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                System Engine Active
            </span>
        </div>
    </div>

    <!-- Canonical System Navigation Bar -->
    <?= view('partials/system_nav', ['activeTab' => $activeTab]) ?>

    <!-- TAB 1: BACKUP MANAGER -->
    <?php if ($activeTab === 'backups'): ?>
        <div class="space-y-6">
            <!-- Stat Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Snapshots</p>
                        <h3 class="text-2xl font-bold text-slate-900 dark:text-white mt-1"><?= esc($totalCount ?? 0) ?></h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center">
                        <i data-lucide="layers" class="w-5 h-5"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Storage Consumed</p>
                        <h3 class="text-2xl font-bold text-slate-900 dark:text-white mt-1"><?= esc($totalSize ?? '0 MB') ?></h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center">
                        <i data-lucide="hard-drive" class="w-5 h-5"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Latest Snapshot</p>
                        <h3 class="text-sm font-bold text-slate-900 dark:text-white mt-2 truncate max-w-[150px]"><?= esc($lastBackup ?? 'Never') ?></h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center">
                        <i data-lucide="clock" class="w-5 h-5"></i>
                    </div>
                </div>

                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-5 shadow-xs flex items-center justify-between">
                    <div>
                        <p class="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Engine Status</p>
                        <div class="flex items-center gap-1.5 mt-2">
                            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                            <span class="text-sm font-bold text-emerald-600 dark:text-emerald-400">Ready / MySQL 8</span>
                        </div>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 flex items-center justify-center">
                        <i data-lucide="shield-check" class="w-5 h-5"></i>
                    </div>
                </div>
            </div>

            <!-- Create Backup Form Card -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs">
                <h3 class="font-bold text-slate-900 dark:text-white text-base mb-1 flex items-center gap-2">
                    <i data-lucide="hard-drive-download" class="w-5 h-5 text-indigo-600"></i>
                    Create Instant Database Snapshot
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mb-5">Select snapshot scope and target tables to produce an isolated, recoverable SQL archive.</p>

                <form method="POST" action="<?= base_url('system/backups/create') ?>" class="space-y-5">
                    <?= csrf_field() ?>

                    <!-- Backup Scope Selection -->
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Backup Scope</label>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <label class="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer hover:border-indigo-500 transition">
                                <input type="radio" name="backup_type" value="Database" checked onclick="toggleTablesPanel(false)" class="mt-0.5 text-indigo-600 focus:ring-indigo-500">
                                <div>
                                    <span class="block text-xs font-bold text-slate-900 dark:text-white">Database</span>
                                    <span class="block text-[11px] text-slate-500">All tables, schema & relational entries</span>
                                </div>
                            </label>

                            <label class="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer hover:border-indigo-500 transition">
                                <input type="radio" name="backup_type" value="Full" onclick="toggleTablesPanel(false)" class="mt-0.5 text-indigo-600 focus:ring-indigo-500">
                                <div>
                                    <span class="block text-xs font-bold text-slate-900 dark:text-white">Full Archive</span>
                                    <span class="block text-[11px] text-slate-500">Database + employee vaults</span>
                                </div>
                            </label>

                            <label class="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer hover:border-indigo-500 transition">
                                <input type="radio" name="backup_type" value="Selected Tables" onclick="toggleTablesPanel(true)" class="mt-0.5 text-indigo-600 focus:ring-indigo-500">
                                <div>
                                    <span class="block text-xs font-bold text-slate-900 dark:text-white">Selected Tables</span>
                                    <span class="block text-[11px] text-slate-500">Choose custom specific tables</span>
                                </div>
                            </label>
                        </div>
                    </div>

                    <!-- Interactive Selected Tables Checkboxes -->
                    <div id="selectedTablesContainer" class="hidden p-4 rounded-xl border border-indigo-100 dark:border-indigo-950 bg-indigo-50/30 dark:bg-indigo-950/20 space-y-3">
                        <div class="flex items-center justify-between">
                            <span class="text-xs font-bold text-indigo-900 dark:text-indigo-300">Choose Tables to Include:</span>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="selectAllTables(true)" class="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold hover:underline">Select All</button>
                                <span class="text-slate-300 dark:text-slate-700">&bull;</span>
                                <button type="button" onclick="selectAllTables(false)" class="text-[11px] text-slate-500 hover:underline">Deselect All</button>
                            </div>
                        </div>

                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
                            <?php 
                                $popularTables = ['employees', 'attendance_logs', 'leave_applications', 'payrolls', 'system_settings', 'users', 'audit_logs', 'roles', 'permissions', 'assets', 'training_sessions', 'departments', 'designations'];
                                $displayTables = !empty($dbTables) ? $dbTables : $popularTables;
                                foreach ($displayTables as $tbl):
                            ?>
                                <label class="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                                    <input type="checkbox" name="selected_tables[]" value="<?= esc($tbl) ?>" checked class="table-checkbox rounded text-indigo-600 focus:ring-indigo-500">
                                    <span class="font-mono text-[11px]"><?= esc($tbl) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
                            <i data-lucide="play" class="w-4 h-4"></i>
                            Start Backup Process
                        </button>
                    </div>
                </form>
            </div>

            <!-- Backups List Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <div>
                        <h3 class="font-semibold text-slate-900 dark:text-white text-base">Archived Database Snapshots</h3>
                        <p class="text-xs text-slate-400 mt-0.5">Stored securely in local directory <code>writable/backups/</code></p>
                    </div>
                    <span class="text-xs font-mono text-slate-400"><?= count($backups ?? []) ?> Snapshots available</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-sm">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium text-xs">
                                <th class="py-3.5 px-5">Snapshot Archive Name</th>
                                <th class="py-3.5 px-5">Scope Type</th>
                                <th class="py-3.5 px-5">Created By / Date</th>
                                <th class="py-3.5 px-5">Archive Size</th>
                                <th class="py-3.5 px-5">SHA-256 Checksum</th>
                                <th class="py-3.5 px-5 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                            <?php if (empty($backups)): ?>
                                <tr>
                                    <td colspan="6" class="py-10 text-center text-slate-400">
                                        <i data-lucide="inbox" class="w-10 h-10 mx-auto text-slate-300 mb-2"></i>
                                        No snapshots created yet. Click "Start Backup Process" to generate an archive.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($backups as $b): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                        <td class="py-3.5 px-5">
                                            <div class="flex items-center gap-2.5">
                                                <i data-lucide="file-code" class="w-4 h-4 text-indigo-500"></i>
                                                <span class="font-mono font-semibold text-xs text-slate-900 dark:text-white"><?= esc($b['filename'] ?? $b['backupName']) ?></span>
                                            </div>
                                        </td>
                                        <td class="py-3.5 px-5">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold <?= ($b['backupType'] ?? 'Database') === 'Full' ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300' : (($b['backupType'] ?? '') === 'Selected Tables' ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300') ?>">
                                                <?= esc($b['backupType'] ?? 'Database') ?>
                                            </span>
                                        </td>
                                        <td class="py-3.5 px-5 text-xs text-slate-500">
                                            <div class="font-medium text-slate-800 dark:text-slate-200"><?= esc($b['createdBy'] ?? 'System Core') ?></div>
                                            <div class="text-[11px] text-slate-400"><?= esc($b['created_at'] ?? $b['createdDate']) ?></div>
                                        </td>
                                        <td class="py-3.5 px-5 font-mono text-xs text-slate-600 dark:text-slate-300">
                                            <?= esc($b['size'] ?? $b['backupSize']) ?>
                                        </td>
                                        <td class="py-3.5 px-5 font-mono text-[11px] text-slate-400">
                                            <?= esc($b['checksum']) ?>
                                        </td>
                                        <td class="py-3.5 px-5 text-right">
                                            <div class="flex items-center justify-end gap-2">
                                                <!-- Download -->
                                                <a href="<?= base_url('system/backups/download/' . ($b['filename'] ?? $b['backupName'])) ?>" class="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition" title="Download SQL File">
                                                    <i data-lucide="download" class="w-4 h-4"></i>
                                                </a>

                                                <!-- Restore Trigger -->
                                                <button type="button" onclick="openRestoreModal('<?= esc($b['filename'] ?? $b['backupName']) ?>')" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-amber-700 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-200 hover:bg-amber-100 transition" title="Restore this snapshot">
                                                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Restore
                                                </button>

                                                <!-- Delete -->
                                                <form method="POST" action="<?= base_url('system/backups/delete/' . ($b['filename'] ?? $b['backupName'])) ?>" onsubmit="return confirm('Are you sure you want to permanently delete snapshot <?= esc($b['filename'] ?? $b['backupName']) ?>?');" class="inline">
                                                    <?= csrf_field() ?>
                                                    <button type="submit" class="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition" title="Delete Archive">
                                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <!-- TAB 2: RESTORE CORE -->
    <?php elseif ($activeTab === 'restore'): ?>
        <div class="space-y-6">
            <!-- Warning Banner -->
            <div class="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 flex items-start gap-3">
                <i data-lucide="shield-alert" class="w-5 h-5 text-amber-600 shrink-0 mt-0.5"></i>
                <div class="text-xs text-amber-900 dark:text-amber-200">
                    <h4 class="font-bold text-sm">Critical Restoration Safety Warning</h4>
                    <p class="mt-1 leading-relaxed">Executing a database restoration will overwrite all matching existing table records with the contents of the chosen snapshot. Please ensure all current changes have been backed up before proceeding.</p>
                </div>
            </div>

            <!-- Restore Execution Panel -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Option A: Restore from Existing Snapshot -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
                    <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                        <i data-lucide="archive-restore" class="w-5 h-5 text-indigo-600"></i>
                        Restore From Saved Snapshot
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Select an existing backup file stored on the server to execute a system rollback.</p>

                    <form method="POST" action="<?= base_url('system/backups/restore') ?>" class="space-y-4" onsubmit="return handleRestoreSubmit(this)">
                        <?= csrf_field() ?>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Select Backup Archive</label>
                            <select name="filename" required class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono">
                                <option value="">-- Choose Backup Snapshot --</option>
                                <?php foreach ($backups as $b): ?>
                                    <option value="<?= esc($b['filename'] ?? $b['backupName']) ?>">
                                        <?= esc($b['filename'] ?? $b['backupName']) ?> (<?= esc($b['size'] ?? $b['backupSize']) ?> &bull; <?= esc($b['created_at'] ?? $b['createdDate']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Restoration Scope</label>
                            <select name="restore_type" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                                <option value="Database">Database Schema & Entries Only</option>
                                <option value="Documents">Uploaded Documents & Assets Only</option>
                                <option value="Complete System">Complete System Restoration (DB + Files)</option>
                            </select>
                        </div>

                        <div class="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 space-y-2">
                            <label class="block text-xs font-bold text-rose-700 dark:text-rose-400">
                                Type <code class="bg-rose-100 dark:bg-rose-900/50 px-1 py-0.5 rounded text-rose-900 dark:text-rose-200 font-mono">RESTORE</code> below to confirm:
                            </label>
                            <input type="text" name="confirm_text" required placeholder="Type RESTORE" class="w-full px-3.5 py-2 rounded-xl border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 text-xs font-mono font-bold uppercase tracking-wider text-rose-600 focus:ring-rose-500">
                        </div>

                        <button type="submit" class="w-full inline-flex items-center justify-center gap-2 py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition shadow-xs">
                            <i data-lucide="rotate-ccw" class="w-4 h-4"></i>
                            Execute System Restoration
                        </button>
                    </form>
                </div>

                <!-- Option B: Upload Custom SQL & Restore -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
                    <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                        <i data-lucide="upload-cloud" class="w-5 h-5 text-indigo-600"></i>
                        Upload External SQL Snapshot
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Upload a standalone <code>.sql</code> backup file from your local machine to restore.</p>

                    <form method="POST" action="<?= base_url('system/backups/upload-restore') ?>" enctype="multipart/form-data" class="space-y-4" onsubmit="return handleRestoreSubmit(this)">
                        <?= csrf_field() ?>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Select .sql Backup File</label>
                            <input type="file" name="sql_file" accept=".sql" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Restoration Scope</label>
                            <select name="restore_type" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                                <option value="Database">Database Schema & Entries Only</option>
                                <option value="Complete System">Complete System Restoration</option>
                            </select>
                        </div>

                        <div class="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 space-y-2">
                            <label class="block text-xs font-bold text-rose-700 dark:text-rose-400">
                                Type <code class="bg-rose-100 dark:bg-rose-900/50 px-1 py-0.5 rounded text-rose-900 dark:text-rose-200 font-mono">RESTORE</code> below to confirm:
                            </label>
                            <input type="text" name="confirm_text" required placeholder="Type RESTORE" class="w-full px-3.5 py-2 rounded-xl border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 text-xs font-mono font-bold uppercase tracking-wider text-rose-600 focus:ring-rose-500">
                        </div>

                        <button type="submit" class="w-full inline-flex items-center justify-center gap-2 py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition shadow-xs">
                            <i data-lucide="upload-cloud" class="w-4 h-4"></i>
                            Upload & Execute Restoration
                        </button>
                    </form>
                </div>
            </div>

            <!-- Restore Activity History -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                    <h3 class="font-semibold text-slate-900 dark:text-white text-base">Restoration Activity Logs</h3>
                    <span class="text-xs text-slate-400"><?= count($restoreHistory ?? []) ?> Events recorded</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                                <th class="py-3 px-5">Restored Archive</th>
                                <th class="py-3 px-5">Scope Type</th>
                                <th class="py-3 px-5">Authorized By</th>
                                <th class="py-3 px-5">Status</th>
                                <th class="py-3 px-5">Restoration Timestamp</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                            <?php if (empty($restoreHistory)): ?>
                                <tr>
                                    <td colspan="5" class="py-8 text-center text-slate-400">No restoration procedures executed yet.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($restoreHistory as $rh): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                        <td class="py-3 px-5 font-mono font-bold text-slate-900 dark:text-white">
                                            <?= esc($rh['backupName']) ?>
                                        </td>
                                        <td class="py-3 px-5">
                                            <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                                <?= esc($rh['restoreType'] ?? 'Database') ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-5 text-slate-700 dark:text-slate-300 font-medium">
                                            <?= esc($rh['restoredBy'] ?? 'Super Admin') ?>
                                        </td>
                                        <td class="py-3 px-5">
                                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                                                <i data-lucide="check-circle" class="w-3 h-3"></i> <?= esc($rh['status'] ?? 'Success') ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-5 font-mono text-slate-500">
                                            <?= esc($rh['restoredAt'] ?? date('Y-m-d H:i:s')) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <!-- TAB 3: SMTP GATEWAY -->
    <?php elseif ($activeTab === 'smtp'): ?>
        <?php if (!can('email.smtp.view')): ?>
            <div class="p-8 text-center text-slate-400">
                <i data-lucide="shield-alert" class="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600 mb-2"></i>
                <p class="text-sm font-semibold text-slate-500">Access Denied</p>
                <p class="text-xs text-slate-400">You do not have permission to view SMTP Gateway settings.</p>
            </div>
        <?php else: ?>
            <?php $canEditSmtp = can('email.smtp.edit'); ?>
            <div class="space-y-6">
                <?php if ($canEditSmtp): ?>
                <!-- Quick Presets -->
                <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                    <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Quick Provider Presets</p>
                    <div class="flex items-center gap-2 flex-wrap">
                        <button type="button" onclick="applyPreset('smtp.sendgrid.net', 587, 'apikey', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition cursor-pointer">
                            SendGrid
                        </button>
                        <button type="button" onclick="applyPreset('email-smtp.us-east-1.amazonaws.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition cursor-pointer">
                            Amazon SES
                        </button>
                        <button type="button" onclick="applyPreset('smtp.mailgun.org', 587, 'postmaster@domain.com', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition cursor-pointer">
                            Mailgun
                        </button>
                        <button type="button" onclick="applyPreset('smtp.gmail.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition cursor-pointer">
                            Google Workspace / Gmail
                        </button>
                        <button type="button" onclick="applyPreset('smtp.office365.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition cursor-pointer">
                            Microsoft 365
                        </button>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Scope Indicator -->
                <div class="flex items-center justify-between bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700 text-xs">
                    <div class="flex items-center gap-2">
                        <span class="font-semibold text-slate-600 dark:text-slate-400">Scoped Company:</span>
                        <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2.5 py-1 rounded-lg border border-indigo-200 dark:border-indigo-900"><?= esc($currentCompanyId ?? $companyId ?? 'Global Fallback') ?></span>
                    </div>
                    <div>
                        <?php if (!empty($smtpConfig['_is_company_override'])): ?>
                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">
                                <i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Custom Company Gateway Config
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200">
                                <i data-lucide="info" class="w-3.5 h-3.5"></i> Inherited from Global Gateway Fallback
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- SMTP Config & Diagnostic Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs">
                        <form method="POST" action="<?= base_url('system/smtp/save') ?>" class="space-y-4">
                            <?= csrf_field() ?>
                            <input type="hidden" name="company_id" value="<?= esc(!empty($currentCompanyId ?? $companyId) ? ($currentCompanyId ?? $companyId) : '') ?>">
                            
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Server Host</label>
                                    <input type="text" id="smtp_host" name="smtp_host" <?= $canEditSmtp ? 'required' : 'readonly' ?> placeholder="smtp.sendgrid.net" value="<?= esc($smtpConfig['smtp_host'] ?? 'smtp.example.com') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Port</label>
                                    <input type="number" id="smtp_port" name="smtp_port" <?= $canEditSmtp ? 'required' : 'readonly' ?> value="<?= esc($smtpConfig['smtp_port'] ?? '587') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Username / API Key</label>
                                    <input type="text" id="smtp_user" name="smtp_user" <?= !$canEditSmtp ? 'readonly' : '' ?> value="<?= esc($smtpConfig['smtp_user'] ?? 'apikey') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Password</label>
                                    <input type="password" id="smtp_pass" name="smtp_pass" <?= !$canEditSmtp ? 'readonly' : '' ?> placeholder="••••••••••••" value="<?= esc($smtpConfig['smtp_pass'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Encryption Protocol</label>
                                    <select id="smtp_crypto" name="smtp_crypto" <?= !$canEditSmtp ? 'disabled' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                        <option value="tls" <?= ($smtpConfig['smtp_crypto'] ?? '') === 'tls' ? 'selected' : '' ?>>STARTTLS / TLS (Port 587 - Recommended)</option>
                                        <option value="ssl" <?= ($smtpConfig['smtp_crypto'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL (Port 465)</option>
                                        <option value="none" <?= ($smtpConfig['smtp_crypto'] ?? '') === 'none' ? 'selected' : '' ?>>Plain / Unencrypted (Port 25)</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">From Sender Address</label>
                                    <input type="email" id="from_email" name="from_email" <?= $canEditSmtp ? 'required' : 'readonly' ?> value="<?= esc($smtpConfig['from_email'] ?? 'hrms-noreply@enterprise.internal') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">From Display Name</label>
                                    <input type="text" name="from_name" <?= !$canEditSmtp ? 'readonly' : '' ?> value="<?= esc($smtpConfig['from_name'] ?? 'Corporate Smart HRMS') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Reply-To Email Address</label>
                                    <input type="email" name="reply_to_email" <?= !$canEditSmtp ? 'readonly' : '' ?> value="<?= esc($smtpConfig['reply_to_email'] ?? 'support@corporate.com') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                            </div>

                            <div class="pt-2 flex items-center justify-between">
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="checkbox" name="smtp_is_active" value="1" <?= ($smtpConfig['smtp_is_active'] ?? '1') == '1' ? 'checked' : '' ?> <?= !$canEditSmtp ? 'disabled' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                                    <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Email Notification Gateway</span>
                                </label>

                                <?php if ($canEditSmtp): ?>
                                <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                                    <i data-lucide="save" class="w-4 h-4"></i>
                                    Save SMTP Settings
                                </button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    <!-- Test Connection Diagnostic Card -->
                    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs flex flex-col justify-between">
                        <div>
                            <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center mb-3">
                                <i data-lucide="send" class="w-5 h-5"></i>
                            </div>
                            <h3 class="text-base font-bold text-slate-900 dark:text-white">Verify Mail Handshake</h3>
                            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">Send a diagnostic probe to verify socket connection and SMTP RFC-5321 compliance.</p>
                            
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Recipient Test Address</label>
                                    <input type="email" id="test_email_input" placeholder="admin@enterprise.internal" value="admin@hrms.enterprise.io" <?= !$canEditSmtp ? 'readonly' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditSmtp ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                                </div>
                                <?php if ($canEditSmtp): ?>
                                <button type="button" id="btnRunDiagnostic" onclick="runDiagnosticTest()" class="w-full inline-flex items-center justify-center gap-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-sm cursor-pointer">
                                    <i data-lucide="activity" class="w-4 h-4"></i>
                                    Run Socket Diagnostic Test
                                </button>
                                <?php else: ?>
                                <p class="text-xs text-slate-400 italic text-center py-2">Test socket connectivity is restricted to administrators with edit permissions.</p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Terminal Output Window -->
                        <div id="diagnosticTerminal" class="mt-4 hidden bg-slate-950 rounded-xl p-3 text-[11px] font-mono text-emerald-400 border border-slate-800 max-h-48 overflow-y-auto whitespace-pre-line leading-relaxed">
                        </div>

                        <p class="text-[11px] text-slate-400 mt-4">TLS Handshake Verified &bull; SPF/DKIM Config Ready</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    <!-- TAB 4: EMAIL TEMPLATES -->
    <?php elseif ($activeTab === 'templates'): ?>
        <?php if (!can('email.template.view')): ?>
            <div class="p-8 text-center text-slate-400">
                <i data-lucide="shield-alert" class="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600 mb-2"></i>
                <p class="text-sm font-semibold text-slate-500">Access Denied</p>
                <p class="text-xs text-slate-400">You do not have permission to view Email Templates.</p>
            </div>
        <?php else: ?>
            <?php $canEditTpl = can('email.template.edit'); ?>
            <div class="space-y-6">
                <!-- Header Actions -->
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-slate-900 dark:text-white text-base">Customizable Email Templates</h3>
                        <p class="text-xs text-slate-400">Configure transactional workflow notification contents, subjects, and dynamic tokens.</p>
                    </div>
                    <?php if ($canEditTpl): ?>
                    <div class="flex items-center gap-2">
                        <form method="POST" action="<?= base_url('system/templates/reset') ?>" class="inline m-0 p-0" onsubmit="return confirm('Restore all email templates to initial system factory settings?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="inline-flex items-center gap-2 px-3 py-2 rounded-xl font-medium text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition shadow-2xs cursor-pointer">
                                <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                                Reset Defaults
                            </button>
                        </form>
                        <button onclick="document.getElementById('createTemplateModal').classList.remove('hidden')" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition">
                            <i data-lucide="plus" class="w-4 h-4"></i>
                            New Template
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Dynamic Placeholders Bar -->
                <div class="bg-indigo-50/70 dark:bg-indigo-950/30 rounded-2xl border border-indigo-100 dark:border-indigo-900/50 p-4">
                    <p class="text-xs font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wider mb-2">Available Dynamic Placeholders (Click to Insert at Cursor):</p>
                    <div class="flex flex-wrap gap-2 text-xs font-mono">
                        <?php 
                            $tokens = ['{employee_name}', '{employee_code}', '{username}', '{leave_type}', '{from_date}', '{to_date}', '{days}', '{reason}', '{manager_name}', '{approver_name}', '{remaining_balance}', '{payroll_month}', '{gross_salary}', '{total_deductions}', '{net_salary}', '{user_name}', '{reset_token}', '{company_name}', '{asset_name}', '{asset_code}', '{date}', '{hours}', '{cycle_name}', '{backup_name}'];
                            foreach ($tokens as $t): 
                        ?>
                            <button type="button" onclick="insertPlaceholder('<?= $t ?>')" class="px-2 py-1 bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 rounded-lg border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-600 hover:text-white transition cursor-pointer">
                                <?= $t ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- 2-Column Template Editor -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Left: Templates List -->
                    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs space-y-2 max-h-[600px] overflow-y-auto">
                        <p class="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 mb-2">Template Catalog</p>
                        <?php foreach ($templates as $idx => $t): ?>
                            <div onclick="selectTemplate(<?= htmlspecialchars(json_encode($t), ENT_QUOTES, 'UTF-8') ?>)" class="template-item p-3 rounded-xl border border-slate-100 dark:border-slate-700/60 hover:border-indigo-500 hover:bg-indigo-50/40 dark:hover:bg-slate-700/50 cursor-pointer transition flex items-center justify-between <?= $idx === 0 ? 'bg-indigo-50/60 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800' : '' ?>">
                                <div class="min-w-0 flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="w-2 h-2 rounded-full <?= ($t['is_active'] ?? 1) ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span>
                                        <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate"><?= esc($t['title'] ?? $t['name']) ?></h4>
                                    </div>
                                    <p class="text-[11px] text-slate-400 truncate"><?= esc($t['subject'] ?? '') ?></p>
                                    <div class="mt-1 flex items-center gap-2">
                                        <span class="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300"><?= esc($t['module'] ?? 'System') ?></span>
                                        <span class="text-[10px] font-mono text-slate-400"><?= esc($t['template_code'] ?? $t['id']) ?></span>
                                    </div>
                                </div>
                                <i data-lucide="chevron-right" class="w-4 h-4 text-slate-400 shrink-0 ml-2"></i>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Right: Active Template Editor -->
                    <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
                        <?php $initialTpl = !empty($templates[0]) ? $templates[0] : null; ?>
                        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white text-base" id="activeEditorTitle"><?= esc($initialTpl['title'] ?? 'Welcome Email') ?></h4>
                                <p class="text-xs font-mono text-indigo-600 dark:text-indigo-400" id="activeEditorCode"><?= esc($initialTpl['template_code'] ?? 'welcome_email') ?></p>
                            </div>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="previewCurrentTemplate()" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 transition cursor-pointer">
                                    <i data-lucide="eye" class="w-3.5 h-3.5 text-indigo-600"></i> Live HTML Preview
                                </button>
                            </div>
                        </div>

                        <form id="templateEditorForm" method="POST" action="<?= base_url('system/templates/save/' . ($initialTpl['id'] ?? 'welcome_email')) ?>" class="space-y-4">
                            <?= csrf_field() ?>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Template Name</label>
                                    <input type="text" id="editor_title" name="title" value="<?= esc($initialTpl['title'] ?? 'Welcome Email') ?>" <?= $canEditTpl ? 'required' : 'readonly' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditTpl ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs font-semibold">
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Module Category</label>
                                    <select id="editor_module" name="module" <?= !$canEditTpl ? 'disabled' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditTpl ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs">
                                        <?php foreach (['Employee', 'Attendance', 'Leave', 'Payroll', 'Recruitment', 'Training', 'Security', 'System'] as $mod): ?>
                                            <option value="<?= $mod ?>" <?= ($initialTpl['module'] ?? 'Employee') === $mod ? 'selected' : '' ?>><?= $mod ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject Line</label>
                                <input type="text" id="editor_subject" name="subject" value="<?= esc($initialTpl['subject'] ?? 'Welcome to the Team, {employee_name}!') ?>" <?= $canEditTpl ? 'required' : 'readonly' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditTpl ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs">
                            </div>

                            <div>
                                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Message Body (HTML / Dynamic Placeholders)</label>
                                <textarea id="editor_body" name="body" rows="8" <?= !$canEditTpl ? 'readonly' : '' ?> class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEditTpl ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs font-mono leading-relaxed"><?= esc($initialTpl['body'] ?? '') ?></textarea>
                            </div>

                            <div class="flex items-center justify-between pt-2">
                                <label class="flex items-center gap-2 cursor-pointer">
                                    <input type="checkbox" id="editor_active" name="is_active" value="1" <?= ($initialTpl['is_active'] ?? 1) ? 'checked' : '' ?> <?= !$canEditTpl ? 'disabled' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                                    <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Keep Template Active</span>
                                </label>

                                <div class="flex items-center gap-2">
                                    <?php if ($canEditTpl): ?>
                                    <button type="button" id="btnDeleteTemplate" onclick="deleteCurrentTemplate()" class="px-4 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 transition bg-transparent border-0 cursor-pointer">
                                        Delete
                                    </button>
                                    <button type="submit" class="inline-flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition shadow-sm">
                                        <i data-lucide="save" class="w-4 h-4"></i>
                                        Save Template
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    <!-- TAB 5: AUDIT LOGS -->
    <?php elseif ($activeTab === 'logs' || $activeTab === 'audit'): ?>
        <div class="space-y-6">
            <!-- Filter & Search Bar -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
                <form method="GET" action="<?= base_url('system') ?>" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <input type="hidden" name="tab" value="logs">
                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Filter by Module</label>
                        <select name="module" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                            <option value="all">All Modules</option>
                            <?php foreach (['system', 'employees', 'attendance', 'leave', 'payroll', 'security', 'notices', 'assets', 'training', 'recruitment'] as $m): ?>
                                <option value="<?= esc($m) ?>" <?= ($selectedModule ?? 'all') === $m ? 'selected' : '' ?>><?= esc(ucfirst($m)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Filter by Role</label>
                        <select name="role" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                            <option value="all">All Roles</option>
                            <?php foreach (['Super Admin', 'HR', 'Manager', 'Employee', 'Accountant', 'Line Manager'] as $r): ?>
                                <option value="<?= esc($r) ?>" <?= ($selectedRole ?? 'all') === $r ? 'selected' : '' ?>><?= esc($r) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Search Actor / IP / Details</label>
                        <input type="text" name="search" placeholder="Search keyword..." value="<?= esc($logSearch ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                    </div>

                    <div class="flex items-end gap-2">
                        <button type="submit" class="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl transition shadow-2xs">
                            Filter
                        </button>
                        <a href="<?= base_url('system?tab=logs') ?>" class="px-3 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-600 dark:text-slate-300 font-semibold text-xs rounded-xl transition">
                            Reset
                        </a>
                    </div>
                </form>
            </div>

            <!-- Action Bar -->
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <h3 class="font-semibold text-slate-900 dark:text-white text-base">Live Security Audit Trail</h3>
                    <span class="text-xs text-slate-400">(<?= count($logs ?? []) ?> Entries displayed)</span>
                </div>

                <div class="flex items-center gap-2">
                    <form method="POST" action="<?= base_url('system/audit/purge') ?>" onsubmit="return confirm('Rotate logs and remove records older than 30 days?');" class="inline">
                        <?= csrf_field() ?>
                        <input type="hidden" name="days" value="30">
                        <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/50 dark:bg-rose-950/20 text-rose-600 font-medium text-xs hover:bg-rose-100 transition">
                            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Rotate (30d)
                        </button>
                    </form>

                    <a href="<?= base_url('system/audit/export') ?>" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-medium text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-2xs transition">
                        <i data-lucide="download" class="w-3.5 h-3.5"></i> Export CSV
                    </a>
                </div>
            </div>

            <!-- Logs Table -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse text-xs">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                                <th class="py-3 px-4">Timestamp</th>
                                <th class="py-3 px-4">Module</th>
                                <th class="py-3 px-4">Action Code</th>
                                <th class="py-3 px-4">Actor</th>
                                <th class="py-3 px-4">IP Address</th>
                                <th class="py-3 px-4">Payload Details</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                            <?php if (empty($logs)): ?>
                                <tr>
                                    <td colspan="6" class="py-10 text-center text-slate-400">
                                        <i data-lucide="shield" class="w-8 h-8 mx-auto text-slate-300 mb-2"></i>
                                        No audit events matching criteria.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($logs as $l): ?>
                                    <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                        <td class="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                                            <?= esc($l['created_at'] ?? $l['timestamp'] ?? '') ?>
                                        </td>
                                        <td class="py-3 px-4 whitespace-nowrap">
                                            <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                                <?= esc(strtoupper($l['module'] ?? 'SYSTEM')) ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 whitespace-nowrap">
                                            <span class="font-semibold text-indigo-600 dark:text-indigo-400 font-mono text-[11px]">
                                                <?= esc($l['action']) ?>
                                            </span>
                                        </td>
                                        <td class="py-3 px-4 whitespace-nowrap">
                                            <div class="flex items-center gap-2">
                                                <div class="w-6 h-6 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center font-bold text-[10px]">
                                                    <?= strtoupper(substr($l['username'] ?? 'S', 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <div class="font-bold text-slate-900 dark:text-white"><?= esc($l['username'] ?? 'System Core') ?></div>
                                                    <div class="text-[10px] text-slate-400"><?= esc($l['role'] ?? 'System') ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                                            <?= esc($l['ip_address'] ?? '127.0.0.1') ?>
                                        </td>
                                        <td class="py-3 px-4 max-w-md">
                                            <div class="truncate text-slate-600 dark:text-slate-300 font-mono text-[11px]" title="<?= esc($l['details'] ?? $l['new_values'] ?? '') ?>">
                                                <?= esc($l['details'] ?? $l['new_values'] ?? 'Standard Event') ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <!-- TAB 6: GENERAL SETTINGS -->
    <?php elseif ($activeTab === 'settings' || $activeTab === 'general'): ?>
        <?= view('system/partials/general_settings', ['settings' => $settings ?? []]) ?>

    <!-- TAB 7: SECURITY POLICIES -->
    <?php elseif ($activeTab === 'security'): ?>
        <?= view('system/partials/security_policies', [
            'securitySettings' => $securitySettings ?? [],
            'roles'            => $roles ?? [],
            'users'            => $users ?? []
        ]) ?>

    <!-- TAB 8: THEME & STYLING -->
    <?php elseif ($activeTab === 'theme' || $activeTab === 'styling'): ?>
        <?= view('system/partials/theme_styling', [
            'themes'           => $themes ?? [],
            'currentTheme'     => $currentTheme ?? 'indigo',
            'currentThemeMode' => $currentThemeMode ?? 'system',
            'isDarkMode'       => $isDarkMode ?? false
        ]) ?>

    <?php endif; ?>
</div>

<!-- Modal: Quick Restore Confirmation -->
<div id="restoreModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-amber-200 dark:border-amber-900/60 space-y-4">
        <div class="flex items-center gap-3 text-amber-600">
            <div class="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/50 flex items-center justify-center">
                <i data-lucide="alert-triangle" class="w-6 h-6"></i>
            </div>
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Restore Database Snapshot</h3>
                <p class="text-xs text-amber-600 font-medium">Critical Action Confirmation</p>
            </div>
        </div>

        <p class="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            You are about to restore snapshot <strong id="restoreTargetFilename" class="text-slate-900 dark:text-white font-mono"></strong>. Current live database tables will be rolled back.
        </p>

        <form method="POST" action="<?= base_url('system/backups/restore') ?>" class="space-y-4">
            <?= csrf_field() ?>
            <input type="hidden" name="filename" id="restoreHiddenFilename">

            <div class="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 space-y-1.5">
                <label class="block text-xs font-bold text-rose-700 dark:text-rose-400">
                    Type <code class="bg-rose-100 dark:bg-rose-900/50 px-1 py-0.5 rounded text-rose-900 dark:text-rose-200 font-mono">RESTORE</code> to proceed:
                </label>
                <input type="text" name="confirm_text" required placeholder="Type RESTORE" class="w-full px-3.5 py-2 rounded-xl border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 text-xs font-mono font-bold uppercase text-rose-600">
            </div>

            <div class="flex items-center justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('restoreModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-sm">Confirm & Restore</button>
            </div>
        </form>
    </div>
</div>

<?php if (can('email.template.edit')): ?>
<!-- Modal: Create New Template -->
<div id="createTemplateModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 class="font-bold text-slate-900 dark:text-white">Create Custom Email Template</h3>
            <button onclick="document.getElementById('createTemplateModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form method="POST" action="<?= base_url('system/templates/create') ?>" class="mt-4 space-y-3">
            <?= csrf_field() ?>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Unique Identifier Code</label>
                <input type="text" name="template_code" required placeholder="e.g. quarterly_review_reminder" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-mono lowercase">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Template Title</label>
                <input type="text" name="title" required placeholder="e.g. Quarterly Performance Review Reminder" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Module Category</label>
                <select name="module" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    <?php foreach (['Employee', 'Attendance', 'Leave', 'Payroll', 'Recruitment', 'Training', 'Security', 'System'] as $mod): ?>
                        <option value="<?= $mod ?>"><?= $mod ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject Line</label>
                <input type="text" name="subject" required placeholder="Review Period Open: {employee_name}" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">HTML Body</label>
                <textarea name="body" rows="5" required placeholder="<p>Dear {employee_name},</p><p>Please submit your evaluation.</p>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono"></textarea>
            </div>
            <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('createTemplateModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700">Save Template</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Modal: Live HTML Preview -->
<div id="previewModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white" id="previewModalTitle">Preview</h3>
                <p class="text-xs text-slate-400" id="previewModalSubject"></p>
            </div>
            <button onclick="document.getElementById('previewModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mt-4 p-6 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-sm leading-relaxed" id="previewModalBody">
        </div>

        <div class="flex justify-end pt-4">
            <button type="button" onclick="document.getElementById('previewModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 dark:bg-slate-700 hover:bg-slate-900">Close</button>
        </div>
    </div>
</div>

<script>
    // Tab 1: Backup Manager Helper
    function toggleTablesPanel(show) {
        const p = document.getElementById('selectedTablesContainer');
        if (p) {
            if (show) p.classList.remove('hidden');
            else p.classList.add('hidden');
        }
    }

    function selectAllTables(val) {
        document.querySelectorAll('.table-checkbox').forEach(cb => cb.checked = val);
    }

    function openRestoreModal(filename) {
        document.getElementById('restoreTargetFilename').innerText = filename;
        document.getElementById('restoreHiddenFilename').value = filename;
        document.getElementById('restoreModal').classList.remove('hidden');
    }

    function handleRestoreSubmit(form) {
        const confirmation = form.querySelector('input[name="confirm_text"]').value.trim();
        if (confirmation !== 'RESTORE') {
            alert('Security Error: You must type RESTORE exactly to proceed.');
            return false;
        }
        return true;
    }

    // Tab 3: SMTP Gateway Presets & Diagnostic Probe
    function applyPreset(host, port, user, crypto) {
        const h = document.getElementById('smtp_host');
        const p = document.getElementById('smtp_port');
        const u = document.getElementById('smtp_user');
        const c = document.getElementById('smtp_crypto');
        if (h) h.value = host;
        if (p) p.value = port;
        if (u && user) u.value = user;
        if (c) c.value = crypto;
    }

    function runDiagnosticTest() {
        const term = document.getElementById('diagnosticTerminal');
        const btn = document.getElementById('btnRunDiagnostic');
        if (!term) return;

        term.classList.remove('hidden');
        term.innerText = '>>> Initializing SMTP diagnostic socket probe...\n';
        if (btn) btn.disabled = true;

        const testEmail = document.getElementById('test_email_input') ? document.getElementById('test_email_input').value : '';
        const host = document.getElementById('smtp_host') ? document.getElementById('smtp_host').value : '';
        const port = document.getElementById('smtp_port') ? document.getElementById('smtp_port').value : '';
        const user = document.getElementById('smtp_user') ? document.getElementById('smtp_user').value : '';
        const pass = document.getElementById('smtp_pass') ? document.getElementById('smtp_pass').value : '';
        const crypto = document.getElementById('smtp_crypto') ? document.getElementById('smtp_crypto').value : '';
        const fromEmail = document.getElementById('from_email') ? document.getElementById('from_email').value : '';
        const fromName = document.getElementById('from_name') ? document.getElementById('from_name').value : '';
        const replyTo = document.getElementById('reply_to_email') ? document.getElementById('reply_to_email').value : '';

        fetch('<?= base_url('system/smtp/test') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                '<?= csrf_token() ?>': '<?= csrf_hash() ?>',
                'test_email': testEmail,
                'smtp_host': host,
                'smtp_port': port,
                'smtp_user': user,
                'smtp_pass': pass,
                'smtp_crypto': crypto,
                'from_email': fromEmail,
                'from_name': fromName,
                'reply_to_email': replyTo,
                'company_id': '<?= esc($currentCompanyId ?? $companyId ?? '') ?>'
            })
        })
        .then(res => res.json())
        .then(data => {
            if (btn) btn.disabled = false;
            if (data.transcript) {
                term.innerText = data.transcript;
            } else if (data.status === 'error') {
                term.innerText = 'Error: ' + (data.message || 'Diagnostic failed.');
            } else {
                term.innerText += '<<< [SERVER] Handshake completed successfully.\n';
            }
        })
        .catch(err => {
            if (btn) btn.disabled = false;
            term.innerText = 'Network error during SMTP diagnostic test: ' + err.message;
        });
    }

    // Tab 4: Email Template Interactive Insertion & Switching
    function selectTemplate(t) {
        document.getElementById('activeEditorTitle').innerText = t.title || t.name;
        document.getElementById('activeEditorCode').innerText = t.template_code || t.id;
        document.getElementById('editor_title').value = t.title || t.name;
        document.getElementById('editor_subject').value = t.subject || '';
        document.getElementById('editor_body').value = t.body || '';
        if (document.getElementById('editor_module')) {
            document.getElementById('editor_module').value = t.module || 'Employee';
        }
        if (document.getElementById('editor_active')) {
            document.getElementById('editor_active').checked = (t.is_active != 0);
        }

        if (document.getElementById('templateEditorForm')) {
            document.getElementById('templateEditorForm').action = '<?= base_url('system/templates/save/') ?>/' + (t.id || t.template_code);
        }
        window.currentTemplateDeleteUrl = '<?= base_url('system/templates/delete/') ?>/' + (t.id || t.template_code);
    }

    function deleteCurrentTemplate() {
        if (!confirm('Delete this template?')) return;
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = window.currentTemplateDeleteUrl || '<?= base_url('system/templates/delete/' . ($initialTpl['id'] ?? 'welcome_email')) ?>';
        const csrf = document.createElement('input');
        csrf.type = 'hidden';
        csrf.name = '<?= csrf_token() ?>';
        csrf.value = '<?= csrf_hash() ?>';
        form.appendChild(csrf);
        document.body.appendChild(form);
        form.submit();
    }

    function insertPlaceholder(token) {
        const textarea = document.getElementById('editor_body');
        if (!textarea || textarea.readOnly) return;

        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;

        textarea.value = text.substring(0, start) + token + text.substring(end, text.length);
        textarea.focus();
        textarea.selectionStart = textarea.selectionEnd = start + token.length;
    }

    function previewCurrentTemplate() {
        const title = document.getElementById('editor_title').value;
        const subject = document.getElementById('editor_subject').value;
        let body = document.getElementById('editor_body').value;

        // Sample placeholder replacements for preview
        body = body.replace(/{employee_name}/g, 'Imran Hossain')
                   .replace(/{employee_code}/g, 'EMP-1001')
                   .replace(/{username}/g, 'imran.hossain')
                   .replace(/{leave_type}/g, 'Annual Leave')
                   .replace(/{from_date}/g, '2026-08-01')
                   .replace(/{to_date}/g, '2026-08-05')
                   .replace(/{days}/g, '5')
                   .replace(/{reason}/g, 'Family vacation')
                   .replace(/{manager_name}/g, 'Mr. Rahman')
                   .replace(/{approver_name}/g, 'Ms. Sarah')
                   .replace(/{remaining_balance}/g, '14')
                   .replace(/{payroll_month}/g, 'July 2026')
                   .replace(/{gross_salary}/g, '$4,500.00')
                   .replace(/{total_deductions}/g, '$450.00')
                   .replace(/{net_salary}/g, '$4,050.00')
                   .replace(/{user_name}/g, 'imran_admin')
                   .replace(/{reset_token}/g, '982734')
                   .replace(/{company_name}/g, 'Enterprise Global Corp')
                   .replace(/{asset_name}/g, 'MacBook Pro 16"')
                   .replace(/{asset_code}/g, 'AST-9921')
                   .replace(/{cycle_name}/g, 'Monthly Regular')
                   .replace(/{backup_name}/g, 'hrm_db_backup_2026_08_01.sql');

        document.getElementById('previewModalTitle').innerText = title;
        document.getElementById('previewModalSubject').innerText = 'Subject: ' + subject;
        document.getElementById('previewModalBody').innerHTML = body;
        document.getElementById('previewModal').classList.remove('hidden');
    }
</script>
