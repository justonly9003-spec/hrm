<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="lock" class="w-7 h-7 text-indigo-600"></i>
                Security Policy & System Keys Configuration
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Configure password complexity, lockout thresholds, 2FA requirements, IP whitelisting, and session lifetimes.</p>
        </div>
    </div>

    <!-- Canonical System Navigation Bar -->
    <?= view('partials/system_nav', ['activeTab' => 'security']) ?>

    <!-- Delegated Security Policies View Partial -->
    <?= view('system/partials/security_policies', [
        'securitySettings'   => $securitySettings ?? $settings ?? [],
        'companyId'          => $companyId ?? null,
        'companies'          => $companies ?? [],
        'isSoftwareAppAdmin' => $isSoftwareAppAdmin ?? false,
    ]) ?>
</div>
