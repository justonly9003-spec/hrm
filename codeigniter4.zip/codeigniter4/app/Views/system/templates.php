<?php
if (!can('email.template.view')) {
    return;
}
$canEdit = can('email.template.edit');
?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="layout-template" class="w-7 h-7 text-indigo-600"></i>
                Transactional Email & Notification Templates
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Customize automated notifications, subjects, HTML body markup, and dynamic placeholders across workflow events.</p>
        </div>
        <div class="flex items-center gap-2">
            <?php if ($canEdit): ?>
            <form method="POST" action="<?= base_url('system/templates/reset') ?>" class="inline m-0 p-0" onsubmit="return confirm('Restore all email templates to initial system factory settings?');">
                <?= csrf_field() ?>
                <button type="submit" class="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-medium text-xs text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition shadow-2xs cursor-pointer">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    Reset to Defaults
                </button>
            </form>
            <button onclick="document.getElementById('createTemplateModal').classList.remove('hidden')" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
                <i data-lucide="plus" class="w-4 h-4"></i>
                New Template
            </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Supported Placeholders Bar -->
    <div class="bg-indigo-50/70 dark:bg-indigo-950/30 rounded-2xl border border-indigo-100 dark:border-indigo-900/50 p-4">
        <p class="text-xs font-bold text-indigo-900 dark:text-indigo-300 uppercase tracking-wider mb-2">Available Dynamic Placeholders (Click to Copy)</p>
        <div class="flex flex-wrap gap-2 text-xs font-mono">
            <?php 
                $tokens = ['{employee_name}', '{employee_code}', '{leave_type}', '{from_date}', '{to_date}', '{days}', '{reason}', '{manager_name}', '{approver_name}', '{remaining_balance}', '{payroll_month}', '{gross_salary}', '{total_deductions}', '{net_salary}', '{user_name}', '{reset_token}', '{company_name}', '{asset_name}', '{asset_code}', '{date}', '{hours}'];
                foreach ($tokens as $t): 
            ?>
                <button type="button" onclick="navigator.clipboard.writeText('<?= $t ?>');" title="Click to copy" class="px-2 py-1 bg-white dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 rounded-lg border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-600 hover:text-white transition cursor-pointer">
                    <?= $t ?>
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Templates Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <?php foreach ($templates as $tmpl): ?>
            <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs flex flex-col justify-between space-y-4">
                <div>
                    <div class="flex items-center justify-between gap-2 mb-2 pb-3 border-b border-slate-100 dark:border-slate-700">
                        <div class="flex items-center gap-2">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400">
                                <?= esc($tmpl['template_code'] ?? 'template') ?>
                            </span>
                            <?php if (!empty($tmpl['company_id'])): ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">Company Custom</span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300">System Default</span>
                            <?php endif; ?>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-[11px] text-slate-400">Updated: <?= date('M d, Y', strtotime($tmpl['updated_at'] ?? date('Y-m-d'))) ?></span>
                            <?php if ($canEdit && !in_array($tmpl['template_code'], ['leave_application', 'leave_approval', 'payslip_generated', 'password_reset'])): ?>
                                <form method="POST" action="<?= base_url('system/templates/delete/' . $tmpl['id']) ?>" class="inline m-0 p-0" onsubmit="return confirm('Delete this custom template?');">
                                    <?= csrf_field() ?>
                                    <button type="submit" class="text-rose-500 hover:text-rose-700 p-0 bg-transparent border-0 cursor-pointer" title="Delete Template">
                                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                    <form method="POST" action="<?= base_url('system/templates/save/' . $tmpl['id']) ?>" class="space-y-3">
                        <?= csrf_field() ?>
                        
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Template Title / Purpose</label>
                            <input type="text" name="title" value="<?= esc($tmpl['title'] ?? 'Notification Template') ?>" <?= !$canEdit ? 'readonly' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm font-semibold">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Email Subject Line</label>
                            <input type="text" name="subject" value="<?= esc($tmpl['subject'] ?? '') ?>" <?= !$canEdit ? 'readonly' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Template Body (HTML / Responsive Markup)</label>
                            <textarea name="body" rows="6" <?= !$canEdit ? 'readonly' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-xs font-mono leading-relaxed"><?= esc($tmpl['body'] ?? '') ?></textarea>
                        </div>

                        <div class="flex items-center justify-between pt-2">
                            <button type="button" onclick="previewTemplateForm(this)" class="inline-flex items-center gap-1.5 text-xs text-indigo-600 font-semibold hover:underline">
                                <i data-lucide="eye" class="w-3.5 h-3.5"></i> Live HTML Preview
                            </button>
                            <?php if ($canEdit): ?>
                            <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-sm">
                                <i data-lucide="save" class="w-3.5 h-3.5"></i> Save Template
                            </button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($canEdit): ?>
<!-- Modal: Create New Template -->
<div id="createTemplateModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <h3 class="font-bold text-slate-900 dark:text-white">Create Custom Email Template</h3>
            <button onclick="document.getElementById('createTemplateModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <form method="POST" action="<?= base_url('system/templates/create') ?>" class="mt-4 space-y-3">
            <?= csrf_field() ?>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Unique Identifier Code</label>
                <input type="text" name="template_code" required placeholder="e.g. quarterly_review_reminder" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-mono lowercase">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Template Title</label>
                <input type="text" name="title" required placeholder="e.g. Quarterly Performance Review Reminder" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject Line</label>
                <input type="text" name="subject" required placeholder="Review Period Open: {employee_name}" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">HTML Body</label>
                <textarea name="body" rows="5" required placeholder="<p>Dear {employee_name},</p><p>Please submit your performance self-evaluation.</p>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs font-mono"></textarea>
            </div>
            <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('createTemplateModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700">Save Template</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Modal: Preview HTML -->
<div id="previewModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white" id="previewModalTitle">Preview</h3>
                <p class="text-xs text-slate-400" id="previewModalSubject"></p>
            </div>
            <button onclick="document.getElementById('previewModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <div class="mt-4 p-6 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-sm leading-relaxed" id="previewModalBody">
        </div>

        <div class="flex justify-end pt-4">
            <button type="button" onclick="document.getElementById('previewModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-slate-800 dark:bg-slate-700 hover:bg-slate-900">Close</button>
        </div>
    </div>
</div>

<script>
    function previewTemplateForm(btn) {
        const form = btn.closest('form');
        if (!form) return;
        const title = form.querySelector('[name="title"]')?.value || 'Preview';
        const subject = form.querySelector('[name="subject"]')?.value || '';
        const body = form.querySelector('[name="body"]')?.value || '';
        previewEmailModal(title, subject, body);
    }

    function previewEmailModal(title, subject, body) {
        // Replace sample tokens
        let rendered = body
            .replace(/{employee_name}/g, 'Alexander Vance')
            .replace(/{employee_code}/g, 'EMP-0001')
            .replace(/{leave_type}/g, 'Annual / Earned Leave')
            .replace(/{from_date}/g, '2026-09-01')
            .replace(/{to_date}/g, '2026-09-05')
            .replace(/{days}/g, '5')
            .replace(/{reason}/g, 'Family vacation')
            .replace(/{manager_name}/g, 'Sarah Jenkins')
            .replace(/{approver_name}/g, 'Sarah Jenkins')
            .replace(/{remaining_balance}/g, '15')
            .replace(/{payroll_month}/g, 'August 2026')
            .replace(/{gross_salary}/g, '$9,500.00')
            .replace(/{total_deductions}/g, '$1,200.00')
            .replace(/{net_salary}/g, '$8,300.00')
            .replace(/{user_name}/g, 'superadmin')
            .replace(/{reset_token}/g, '982-491')
            .replace(/{company_name}/g, 'Enterprise Global Corporation')
            .replace(/{asset_name}/g, 'MacBook Pro 16" M3')
            .replace(/{asset_code}/g, 'AST-0091');

        document.getElementById('previewModalTitle').innerText = title;
        document.getElementById('previewModalSubject').innerText = 'Subject: ' + subject;
        document.getElementById('previewModalBody').innerHTML = rendered;
        document.getElementById('previewModal').classList.remove('hidden');
    }
</script>
