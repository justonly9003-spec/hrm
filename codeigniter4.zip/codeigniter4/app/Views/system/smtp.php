<?php
if (!can('email.smtp.view')) {
    return;
}
$canEdit = can('email.smtp.edit');
?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="mail" class="w-7 h-7 text-indigo-600"></i>
                SMTP Gateway & Notification Dispatcher
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Configure corporate TLS/SSL outbound relay credentials, sender identity, and verify socket connectivity.</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">
                <i data-lucide="shield-check" class="w-4 h-4"></i>
                TLS 1.3 / STARTTLS Supported
            </span>
        </div>
    </div>

    <?php if ($canEdit): ?>
    <!-- Quick Presets -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
        <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Quick Provider Presets</p>
        <div class="flex items-center gap-2 flex-wrap">
            <button type="button" onclick="applyPreset('smtp.sendgrid.net', 587, 'apikey', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition">
                SendGrid
            </button>
            <button type="button" onclick="applyPreset('email-smtp.us-east-1.amazonaws.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition">
                Amazon SES
            </button>
            <button type="button" onclick="applyPreset('smtp.mailgun.org', 587, 'postmaster@domain.com', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition">
                Mailgun
            </button>
            <button type="button" onclick="applyPreset('smtp.gmail.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition">
                Google Workspace / Gmail
            </button>
            <button type="button" onclick="applyPreset('smtp.office365.com', 587, '', 'tls')" class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-slate-700 transition">
                Microsoft 365
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Scope Indicator -->
    <div class="flex items-center justify-between bg-slate-50 dark:bg-slate-800/60 rounded-xl p-3 border border-slate-200 dark:border-slate-700 text-xs">
        <div class="flex items-center gap-2">
            <span class="font-semibold text-slate-600 dark:text-slate-400">Scoped Company:</span>
            <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2.5 py-1 rounded-lg border border-indigo-200 dark:border-indigo-900"><?= esc(!empty($companyId) ? $companyId : 'Global Fallback') ?></span>
        </div>
        <div>
            <?php if (!empty($config['_is_company_override'])): ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">
                    <i data-lucide="check-circle" class="w-3.5 h-3.5"></i> Custom Company Gateway Config
                </span>
            <?php else: ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200">
                    <i data-lucide="info" class="w-3.5 h-3.5"></i> Inherited from Global Gateway Fallback
                </span>
            <?php endif; ?>
        </div>
    </div>

    <!-- SMTP Form & Test Relay -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs">
            <form method="POST" action="<?= base_url('system/smtp/save') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="company_id" value="<?= esc($companyId ?? '') ?>">
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Host / Server Endpoint</label>
                        <input type="text" id="smtp_host" name="smtp_host" <?= $canEdit ? 'required' : 'readonly' ?> placeholder="smtp.sendgrid.net" value="<?= esc($config['smtp_host'] ?? 'smtp.example.com') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Port</label>
                        <input type="number" id="smtp_port" name="smtp_port" <?= $canEdit ? 'required' : 'readonly' ?> value="<?= esc($config['smtp_port'] ?? '587') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Username</label>
                        <input type="text" id="smtp_user" name="smtp_user" <?= !$canEdit ? 'readonly' : '' ?> value="<?= esc($config['smtp_user'] ?? 'apikey') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">SMTP Password / API Key</label>
                        <input type="password" id="smtp_pass" name="smtp_pass" <?= !$canEdit ? 'readonly' : '' ?> placeholder="••••••••••••" value="<?= esc($config['smtp_pass'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Encryption Protocol</label>
                        <select id="smtp_crypto" name="smtp_crypto" <?= !$canEdit ? 'disabled' : '' ?> class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                            <option value="tls" <?= ($config['smtp_crypto'] ?? '') === 'tls' ? 'selected' : '' ?>>STARTTLS / TLS (Port 587 - Recommended)</option>
                            <option value="ssl" <?= ($config['smtp_crypto'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL (Port 465)</option>
                            <option value="none" <?= ($config['smtp_crypto'] ?? '') === 'none' ? 'selected' : '' ?>>Plain / Unencrypted (Port 25)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">From Sender Address</label>
                        <input type="email" id="from_email" name="from_email" <?= $canEdit ? 'required' : 'readonly' ?> value="<?= esc($config['from_email'] ?? 'hrms-noreply@enterprise.internal') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">From Display Name</label>
                        <input type="text" id="from_name" name="from_name" <?= !$canEdit ? 'readonly' : '' ?> value="<?= esc($config['from_name'] ?? 'Corporate HRMS System') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Reply-To Email Address</label>
                        <input type="email" id="reply_to_email" name="reply_to_email" <?= !$canEdit ? 'readonly' : '' ?> value="<?= esc($config['reply_to_email'] ?? 'support@corporate.com') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                </div>

                <div class="pt-2 flex items-center justify-between">
                    <label class="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" name="smtp_is_active" value="1" <?= ($config['smtp_is_active'] ?? '1') == '1' ? 'checked' : '' ?> <?= !$canEdit ? 'disabled' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                        <span class="text-xs font-semibold text-slate-700 dark:text-slate-300">Enable Corporate Outbound SMTP Relay</span>
                    </label>

                    <?php if ($canEdit): ?>
                    <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm">
                        <i data-lucide="save" class="w-4 h-4"></i>
                        Save SMTP Configurations
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Test Connection Card -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs flex flex-col justify-between">
            <div>
                <div class="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center mb-3">
                    <i data-lucide="send" class="w-5 h-5"></i>
                </div>
                <h3 class="text-base font-bold text-slate-900 dark:text-white">Verify Mail Handshake</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">Send a diagnostic probe to verify socket connection and SMTP RFC-5321 compliance.</p>
                
                <form method="POST" action="<?= base_url('system/smtp/test') ?>" class="space-y-3" id="testSmtpForm">
                    <?= csrf_field() ?>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Recipient Test Address</label>
                        <input type="email" name="test_email" id="test_email_input" <?= $canEdit ? 'required' : 'readonly' ?> placeholder="admin@enterprise.internal" value="admin@hrms.enterprise.io" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 <?= $canEdit ? 'bg-slate-50 dark:bg-slate-900' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 cursor-not-allowed' ?> text-sm">
                    </div>
                    <?php if ($canEdit): ?>
                    <button type="button" onclick="runDiagnosticTest()" class="w-full inline-flex items-center justify-center gap-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl transition-colors shadow-sm">
                        <i data-lucide="activity" class="w-4 h-4"></i>
                        Run Socket Diagnostic Test
                    </button>
                    <?php else: ?>
                    <p class="text-xs text-slate-400 italic text-center py-2">Test socket connectivity is restricted to administrators with edit permissions.</p>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Terminal Output Window -->
            <div id="diagnosticTerminal" class="mt-4 hidden bg-slate-950 rounded-xl p-3 text-[11px] font-mono text-emerald-400 border border-slate-800 max-h-48 overflow-y-auto whitespace-pre-line leading-relaxed">
            </div>

            <p class="text-[11px] text-slate-400 mt-4">TLS Handshake Verified &bull; SPF/DKIM Config Ready</p>
        </div>
    </div>
</div>

<script>
    function applyPreset(host, port, user, crypto) {
        document.getElementById('smtp_host').value = host;
        document.getElementById('smtp_port').value = port;
        if (user) document.getElementById('smtp_user').value = user;
        document.getElementById('smtp_crypto').value = crypto;
    }

    function runDiagnosticTest() {
        const term = document.getElementById('diagnosticTerminal');
        term.classList.remove('hidden');
        term.innerText = '>>> Initializing SMTP diagnostic socket probe...';

        const testEmail = document.getElementById('test_email_input').value;
        const host = document.getElementById('smtp_host').value;
        const port = document.getElementById('smtp_port').value;
        const user = document.getElementById('smtp_user') ? document.getElementById('smtp_user').value : '';
        const pass = document.getElementById('smtp_pass') ? document.getElementById('smtp_pass').value : '';
        const crypto = document.getElementById('smtp_crypto') ? document.getElementById('smtp_crypto').value : 'tls';
        const fromEmail = document.getElementById('from_email') ? document.getElementById('from_email').value : '';
        const fromName = document.getElementById('from_name') ? document.getElementById('from_name').value : '';
        const replyTo = document.getElementById('reply_to_email') ? document.getElementById('reply_to_email').value : '';

        fetch('<?= base_url('system/smtp/test') ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({
                '<?= csrf_token() ?>': '<?= csrf_hash() ?>',
                'test_email': testEmail,
                'smtp_host': host,
                'smtp_port': port,
                'smtp_user': user,
                'smtp_pass': pass,
                'smtp_crypto': crypto,
                'from_email': fromEmail,
                'from_name': fromName,
                'reply_to_email': replyTo,
                'company_id': '<?= esc($companyId ?? '') ?>'
            })
        })
        .then(res => res.json())
        .then(data => {
            term.innerText = data.transcript || (data.status === 'error' ? ('Error: ' + data.message) : 'Handshake completed.');
        })
        .catch(err => {
            term.innerText = 'Network error during SMTP diagnostic test: ' + err.message;
        });
    }
</script>
