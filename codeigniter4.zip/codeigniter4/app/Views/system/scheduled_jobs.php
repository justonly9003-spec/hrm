<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container-fluid py-4" id="scheduled-jobs-console">
    <!-- Header Banner -->
    <div class="card bg-dark text-white border-0 shadow-lg mb-4" style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%);">
        <div class="card-body p-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div>
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span class="badge bg-primary bg-opacity-25 text-primary border border-primary border-opacity-25 px-2 py-1">
                            P8 Automation Engine
                        </span>
                        <span class="badge bg-success bg-opacity-25 text-success border border-success border-opacity-25 px-2 py-1">
                            <i class="bi bi-circle-fill me-1 small"></i> Daemon Active
                        </span>
                    </div>
                    <h3 class="fw-bold mb-1 text-white">Scheduled Jobs & Automation Engine (P8)</h3>
                    <p class="text-white-50 mb-0 small">
                        Autonomous Daily muster processing, Weekly worked-hour/OT calculations, and 12-Stage Sequential Monthly Payroll Automation Pipeline.
                    </p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-light btn-sm" onclick="location.reload()">
                        <i class="bi bi-arrow-clockwise me-1"></i> Refresh
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="triggerDailyJobs()">
                        <i class="bi bi-play-fill me-1"></i> Run Daily Suite
                    </button>
                    <button class="btn btn-success btn-sm" onclick="triggerMonthlyPipeline()">
                        <i class="bi bi-lightning-charge-fill me-1"></i> Run Monthly Pipeline
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- 12-Step Pipeline Visualizer -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-bottom py-3">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="fw-bold mb-0 text-dark">
                    <i class="bi bi-diagram-3-fill text-success me-2"></i>
                    12-Stage Sequential Monthly Payroll Pipeline
                </h5>
                <span class="badge bg-success">Automated Sequential Flow</span>
            </div>
            <p class="text-muted small mb-0 mt-1">
                Attendance Close &rarr; OT &rarr; Leave Deduction &rarr; Bonus &rarr; Tax &rarr; PF &rarr; Loan/Advance &rarr; Payroll Calc &rarr; Review &rarr; Approval &rarr; Lock &rarr; Disbursement
            </p>
        </div>
        <div class="card-body p-4">
            <div class="row g-3">
                <?php 
                $pipelineSteps = [
                    ['id' => 'attendance_close', 'num' => 1, 'name' => 'Attendance Close', 'desc' => 'Finalize muster, seal missing punches & calculate days present.'],
                    ['id' => 'ot_calculation', 'num' => 2, 'name' => 'OT Calculation', 'desc' => 'Compute regular & holiday overtime multipliers (1.5x / 2.0x).'],
                    ['id' => 'leave_deduction', 'num' => 3, 'name' => 'Leave Deduction', 'desc' => 'Deduct unpaid absences (LWP) and unexcused leave penalties.'],
                    ['id' => 'bonus_calculation', 'num' => 4, 'name' => 'Bonus Grants', 'desc' => 'Apply festival bonuses, KPI incentives & attendance rewards.'],
                    ['id' => 'tax_deduction', 'num' => 5, 'name' => 'Tax Withholding', 'desc' => 'Compute monthly progressive TDS withholding tax brackets.'],
                    ['id' => 'pf_deduction', 'num' => 6, 'name' => 'Provident Fund', 'desc' => 'Deduct employee 8.33% and match employer PF share.'],
                    ['id' => 'loan_advance', 'num' => 7, 'name' => 'Loan Recovery', 'desc' => 'Deduct scheduled loan/advance monthly installments.'],
                    ['id' => 'payroll_calc', 'num' => 8, 'name' => 'Payroll Calc', 'desc' => 'Aggregate earnings, deductions & compute net salary payable.'],
                    ['id' => 'audit_review', 'num' => 9, 'name' => 'Auditor Review', 'desc' => 'Automated variance audit & discrepancy detection analysis.'],
                    ['id' => 'mgmt_approval', 'num' => 10, 'name' => 'Management Approval', 'desc' => 'Apply HR Director and Finance Controller digital approval.'],
                    ['id' => 'payroll_lock', 'num' => 11, 'name' => 'Cryptographic Lock', 'desc' => 'Seal payroll batch from further retroactive mutations.'],
                    ['id' => 'disbursement', 'num' => 12, 'name' => 'Disbursement', 'desc' => 'Generate BEFTN bank batch file & dispatch payslips.']
                ];
                foreach ($pipelineSteps as $step): 
                ?>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="card h-100 border rounded-3 p-3 bg-light">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="badge bg-dark rounded-circle p-2" style="width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">
                                <?= $step['num'] ?>
                            </span>
                            <span class="badge bg-success bg-opacity-10 text-success">READY</span>
                        </div>
                        <h6 class="fw-bold mb-1 text-dark"><?= esc($step['name']) ?></h6>
                        <p class="text-muted small mb-0"><?= esc($step['desc']) ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Active Jobs Table -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white border-bottom py-3">
            <h5 class="fw-bold mb-0 text-dark">
                <i class="bi bi-clock-history text-primary me-2"></i>
                Active Cron Tasks & Scheduled Sub-routines
            </h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Job Name</th>
                        <th>Frequency</th>
                        <th>Cron Expression</th>
                        <th>Handler Service</th>
                        <th>Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($jobs)): ?>
                        <?php foreach ($jobs as $job): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="fw-bold text-dark"><?= esc($job['name']) ?></div>
                                    <div class="text-muted small"><?= esc($job['description'] ?? '') ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $job['frequency'] === 'Daily' ? 'primary' : ($job['frequency'] === 'Weekly' ? 'warning' : 'success') ?>">
                                        <?= esc($job['frequency']) ?>
                                    </span>
                                </td>
                                <td><code class="text-dark bg-light px-2 py-1 rounded"><?= esc($job['schedule_expression'] ?? '') ?></code></td>
                                <td class="small text-muted font-monospace"><?= esc($job['handler_class'] ?? 'ScheduledJobsService') ?></td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success">
                                        <i class="bi bi-check-circle-fill me-1"></i> ACTIVE
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <button class="btn btn-sm btn-outline-primary" onclick="triggerSingleJob('<?= esc($job['id']) ?>')">
                                        <i class="bi bi-play-fill me-1"></i> Run
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">
                                No scheduled jobs found in registry.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Crontab Setup Helper -->
    <div class="card bg-dark text-white border-0 shadow-sm rounded-4">
        <div class="card-header bg-black bg-opacity-25 border-bottom border-secondary py-3">
            <h6 class="fw-bold mb-0 text-white">
                <i class="bi bi-terminal-fill text-success me-2"></i>
                Linux Crontab Directives
            </h6>
        </div>
        <div class="card-body p-3 font-monospace small bg-black text-success">
            # HRMS Automation Cron Directives (crontab -e)<br>
            0 23 * * * cd <?= FCPATH ?>.. && php spark cron:daily &gt;&gt; /var/log/hrms_daily.log 2&gt;&amp;1<br>
            0 2 * * 0 cd <?= FCPATH ?>.. && php spark cron:weekly &gt;&gt; /var/log/hrms_weekly.log 2&gt;&amp;1<br>
            0 1 28 * * cd <?= FCPATH ?>.. && php spark cron:monthly --company=COMP-01 &gt;&gt; /var/log/hrms_monthly.log 2&gt;&amp;1<br>
            */5 * * * * cd <?= FCPATH ?>.. && php spark cron:scheduler &gt;&gt; /var/log/hrms_heartbeat.log 2&gt;&amp;1
        </div>
    </div>
</div>

<script>
function triggerDailyJobs() {
    if (!confirm('Run Daily automated jobs batch now?')) return;
    fetch('<?= base_url('api/v1/scheduled-jobs/run-daily') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            '<?= csrf_header() ?>': '<?= csrf_hash() ?>'
        },
        body: JSON.stringify({ user_id: 'WEB_ADMIN' })
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message || 'Daily jobs executed successfully!');
        location.reload();
    })
    .catch(err => alert('Error running daily jobs: ' + err));
}

function triggerMonthlyPipeline() {
    if (!confirm('Execute the full 12-stage Monthly Payroll Pipeline now?')) return;
    fetch('<?= base_url('api/v1/scheduled-jobs/run-monthly') ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            '<?= csrf_header() ?>': '<?= csrf_hash() ?>'
        },
        body: JSON.stringify({ month: '<?= date('Y-m') ?>', company_id: 'COMP-01', user_id: 'WEB_ADMIN' })
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message || 'Monthly pipeline executed successfully!');
        location.reload();
    })
    .catch(err => alert('Error running pipeline: ' + err));
}

function triggerSingleJob(jobId) {
    alert('Triggering job: ' + jobId);
}
</script>
<?= $this->endSection() ?>
