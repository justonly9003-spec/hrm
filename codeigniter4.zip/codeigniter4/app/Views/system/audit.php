<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="shield-alert" class="w-7 h-7 text-indigo-600"></i>
                Real-Time Security Audit Trail & Forensics
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Immutable forensic tracking of system mutations, access control events, database operations, and authentication sequences.</p>
        </div>
        <div class="flex items-center gap-3">
            <button onclick="document.getElementById('purgeLogsModal').classList.remove('hidden')" class="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-medium text-xs text-rose-600 bg-white dark:bg-slate-800 border border-rose-200 dark:border-rose-900 hover:bg-rose-50 transition shadow-2xs">
                <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                Retention & Purge
            </button>
            <a href="<?= base_url('system/audit/export') ?>" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
                <i data-lucide="download" class="w-4 h-4"></i>
                Export CSV Trail
            </a>
        </div>
    </div>

    <!-- Canonical System Navigation Bar -->
    <?= view('partials/system_nav', ['activeTab' => 'logs']) ?>

    <!-- Filter & Search Bar -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-4 shadow-xs">
        <form method="GET" action="<?= base_url('system/audit') ?>" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            <div>
                <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Filter by Module</label>
                <select name="module" onchange="this.form.submit()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
                    <option value="">All Functional Modules</option>
                    <?php foreach ($modules as $m): ?>
                        <option value="<?= esc($m) ?>" <?= ($selectedModule ?? '') === $m ? 'selected' : '' ?>><?= esc(ucfirst(str_replace('_', ' ', $m))) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Action Keyword</label>
                <input type="text" name="action" placeholder="e.g. created, updated, login" value="<?= esc($selectedAction ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
            </div>

            <div>
                <label class="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Search Actor / IP / Payload</label>
                <input type="text" name="search" placeholder="Search keyword..." value="<?= esc($search ?? '') ?>" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs">
            </div>

            <div class="flex items-end gap-2">
                <button type="submit" class="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl transition shadow-2xs">
                    Apply Filter
                </button>
                <a href="<?= base_url('system/audit') ?>" class="px-3 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-600 dark:text-slate-300 font-semibold text-xs rounded-xl transition">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- Logs Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <h3 class="font-semibold text-slate-900 dark:text-white text-base">Live Telemetry Audit Stream</h3>
            </div>
            <span class="text-xs text-slate-400"><?= count($logs ?? []) ?> Entries displayed</span>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-xs">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                        <th class="py-3 px-4">Timestamp</th>
                        <th class="py-3 px-4">Actor</th>
                        <th class="py-3 px-4">Module</th>
                        <th class="py-3 px-4">Action Code</th>
                        <th class="py-3 px-4">IP Address</th>
                        <th class="py-3 px-4">Forensic Payload Details</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="6" class="py-10 text-center text-slate-400">
                                <i data-lucide="shield" class="w-8 h-8 mx-auto text-slate-300 mb-2"></i>
                                No audit events matching search criteria.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($logs as $l): ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                <td class="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                                    <?= esc($l['created_at']) ?>
                                </td>
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <div class="flex items-center gap-2">
                                        <div class="w-6 h-6 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 flex items-center justify-center font-bold text-[10px]">
                                            <?= strtoupper(substr($l['username'] ?? 'S', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div class="font-bold text-slate-900 dark:text-white"><?= esc($l['username'] ?? 'System Core') ?></div>
                                            <div class="text-[10px] text-slate-400"><?= esc($l['role'] ?? 'System') ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                        <?= esc($l['module']) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 whitespace-nowrap">
                                    <span class="font-semibold text-indigo-600 dark:text-indigo-400 font-mono text-[11px]">
                                        <?= esc($l['action']) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                                    <?= esc($l['ip_address'] ?? '127.0.0.1') ?>
                                </td>
                                <td class="py-3 px-4 max-w-md">
                                    <div class="truncate text-slate-600 dark:text-slate-300 font-mono text-[11px]" title="<?= esc($l['details'] ?? $l['new_values'] ?? '') ?>">
                                        <?= esc($l['details'] ?? $l['new_values'] ?? 'Standard Event') ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal: Purge Logs -->
<div id="purgeLogsModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-rose-200 dark:border-rose-900/50">
        <div class="flex items-center gap-3 text-rose-600 mb-3">
            <div class="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/50 flex items-center justify-center">
                <i data-lucide="trash-2" class="w-6 h-6"></i>
            </div>
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base">Rotate & Purge Audit Trail</h3>
                <p class="text-xs text-rose-600 font-medium">Compliance Log Maintenance</p>
            </div>
        </div>

        <p class="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
            Select the retention lifecycle window. Records older than the specified threshold will be permanently deleted from the database.
        </p>

        <form method="POST" action="<?= base_url('system/audit/purge') ?>" class="mt-4 space-y-4">
            <?= csrf_field() ?>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Retention Horizon</label>
                <select name="days" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    <option value="30">Purge logs older than 30 days</option>
                    <option value="60">Purge logs older than 60 days</option>
                    <option value="90" selected>Purge logs older than 90 days (Standard)</option>
                    <option value="180">Purge logs older than 180 days</option>
                    <option value="365">Purge logs older than 1 year</option>
                </select>
            </div>

            <div class="flex justify-end gap-2 pt-2">
                <button type="button" onclick="document.getElementById('purgeLogsModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-md">Confirm Purge</button>
            </div>
        </form>
    </div>
</div>
