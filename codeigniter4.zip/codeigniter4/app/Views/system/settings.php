<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="settings" class="w-7 h-7 text-indigo-600"></i>
                System Settings & Organizational Master Parameters
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Configure company legal entity metadata, base currency, corporate tax identifier, and core security guard toggles.</p>
        </div>
    </div>

    <!-- Canonical System Navigation Bar -->
    <?= view('partials/system_nav', ['activeTab' => 'settings']) ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-4">
            <h3 class="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-700/60 pb-3">Corporate Entity Information</h3>
            <div class="space-y-3 text-xs">
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Company Legal Name</label>
                    <input type="text" value="Enterprise Corp International" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200" readonly>
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Corporate Tax Number</label>
                    <input type="text" value="TAX-998822-US" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200" readonly>
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Base Currency</label>
                    <input type="text" value="USD ($)" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-xs text-slate-800 dark:text-slate-200" readonly>
                </div>
            </div>
        </div>

        <div class="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-4">
            <h3 class="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-700/60 pb-3">Security & Compliance Policies</h3>
            <div class="space-y-3 text-xs">
                <div class="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-700/50">
                    <div>
                        <p class="font-bold text-slate-800 dark:text-slate-200">CSRF Token Guard</p>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400">Enforces CSRF token validation on all POST requests</p>
                    </div>
                    <span class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">Enabled</span>
                </div>
                <div class="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-700/50">
                    <div>
                        <p class="font-bold text-slate-800 dark:text-slate-200">Audit Trail Tracking</p>
                        <p class="text-[11px] text-slate-500 dark:text-slate-400">Logs every mutate action, IP address & user agent</p>
                    </div>
                    <span class="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">Active</span>
                </div>
            </div>
        </div>
    </div>
</div>
