<div class="space-y-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4 mb-6">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="sliders-horizontal" class="w-5 h-5 text-indigo-600"></i>
                    Enterprise Master System Parameters & Organization Configuration
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Configure company legal entity metadata, base currency, corporate tax identifier, regional localization, and core security guard toggles.</p>
            </div>
            <span class="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                Live Configuration
            </span>
        </div>

        <form method="POST" action="<?= base_url('system/settings/save') ?>" class="space-y-6">
            <?= csrf_field() ?>

            <!-- Corporate Entity Info -->
            <div class="space-y-4">
                <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Corporate Legal Entity Metadata
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Company Legal Name</label>
                        <input type="text" name="company_name" value="<?= esc($settings['company_name'] ?? 'Enterprise Corp International') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Corporate Tax Number (EIN/VAT)</label>
                        <input type="text" name="company_tax_id" value="<?= esc($settings['company_tax_id'] ?? 'TAX-998822-US') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-mono">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Operating Base Currency</label>
                        <select name="base_currency" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <?php 
                                $currencies = ['USD ($)' => 'USD ($) - US Dollar', 'EUR (€)' => 'EUR (€) - Euro', 'GBP (£)' => 'GBP (£) - British Pound', 'BDT' => 'BDT - Bangladeshi Taka', 'CAD ($)' => 'CAD ($) - Canadian Dollar', 'AUD ($)' => 'AUD ($) - Australian Dollar', 'JPY (¥)' => 'JPY (¥) - Japanese Yen'];
                                $currentCur = $settings['base_currency'] ?? 'USD ($)';
                                foreach ($currencies as $k => $label):
                            ?>
                                <option value="<?= esc($k) ?>" <?= (strpos($currentCur, substr($k, 0, 3)) !== false) ? 'selected' : '' ?>><?= esc($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Regional & Localization Parameters -->
            <div class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Regional Localization & Formatting
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">System Timezone</label>
                        <select name="timezone" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-mono">
                            <?php 
                                $tzs = ['UTC' => 'UTC (Universal Coordinated Time)', 'America/New_York' => 'America/New_York (EST/EDT)', 'America/Chicago' => 'America/Chicago (CST/CDT)', 'America/Los_Angeles' => 'America/Los_Angeles (PST/PDT)', 'Europe/London' => 'Europe/London (GMT/BST)', 'Europe/Berlin' => 'Europe/Berlin (CET)', 'Asia/Dhaka' => 'Asia/Dhaka (BST, UTC+6)', 'Asia/Singapore' => 'Asia/Singapore (SGT, UTC+8)', 'Asia/Tokyo' => 'Asia/Tokyo (JST, UTC+9)'];
                                $currentTz = $settings['timezone'] ?? 'America/New_York';
                                foreach ($tzs as $tzKey => $tzLabel):
                            ?>
                                <option value="<?= esc($tzKey) ?>" <?= ($currentTz === $tzKey) ? 'selected' : '' ?>><?= esc($tzLabel) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Date Display Format</label>
                        <select name="date_format" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <?php 
                                $dateFormats = ['Y-m-d' => 'YYYY-MM-DD (2026-08-26)', 'd/m/Y' => 'DD/MM/YYYY (26/08/2026)', 'm/d/Y' => 'MM/DD/YYYY (08/26/2026)', 'M d, Y' => 'Mon DD, YYYY (Aug 26, 2026)'];
                                $currentDf = $settings['date_format'] ?? 'Y-m-d';
                                foreach ($dateFormats as $dfKey => $dfLabel):
                            ?>
                                <option value="<?= esc($dfKey) ?>" <?= ($currentDf === $dfKey) ? 'selected' : '' ?>><?= esc($dfLabel) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Fiscal Year Start Month</label>
                        <select name="fiscal_year_start" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                            <?php 
                                $months = ['1' => 'January', '4' => 'April', '7' => 'July', '10' => 'October'];
                                $currentFy = $settings['fiscal_year_start'] ?? '1';
                                foreach ($months as $mNum => $mName):
                            ?>
                                <option value="<?= esc($mNum) ?>" <?= ($currentFy == $mNum) ? 'selected' : '' ?>><?= esc($mName) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Core System Security & Governance Policies -->
            <div class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    System Protection & Governance Policies
                </h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
                        <div class="space-y-0.5">
                            <span class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600"></i>
                                CSRF Token Guard
                            </span>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400">Enforces cryptographic CSRF token validation on all mutating POST requests.</p>
                        </div>
                        <span class="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 shrink-0">
                            Active / Enforced
                        </span>
                    </div>

                    <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
                        <div class="space-y-0.5">
                            <span class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                <i data-lucide="scroll" class="w-4 h-4 text-emerald-600"></i>
                                Audit Trail Tracking
                            </span>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400">Logs every mutate action, user ID, IP address, timestamp and payload diffs.</p>
                        </div>
                        <span class="px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 shrink-0">
                            Active / Logging
                        </span>
                    </div>
                </div>
            </div>

            <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700">
                <p class="text-xs text-slate-400">
                    <i data-lucide="info" class="w-3.5 h-3.5 inline mr-1 text-indigo-500"></i>
                    Parameters apply globally across all HRMS subsystems and reporting engines.
                </p>
                <button type="submit" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
                    <i data-lucide="save" class="w-4 h-4"></i>
                    Save General Settings
                </button>
            </div>
        </form>
    </div>
</div>
