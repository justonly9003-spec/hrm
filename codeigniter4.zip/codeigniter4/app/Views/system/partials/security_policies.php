<div class="space-y-6">
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-4 mb-6 gap-3">
            <div>
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="shield-check" class="w-5 h-5 text-indigo-600"></i>
                    Enterprise Security Policies & Access Controls
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Configure authentication password complexity, brute force lockout thresholds, 2FA requirements, IP whitelisting, and session timeout governance.</p>
            </div>
            <div class="flex items-center gap-2">
                <?php if (!empty($companyId)): ?>
                    <span class="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                        Company Override Active
                    </span>
                <?php else: ?>
                    <span class="px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                        Global Policy Active
                    </span>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($isSoftwareAppAdmin) && !empty($companies)): ?>
            <!-- Tenant Scope Selector for Software App Admin -->
            <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2">
                    <i data-lucide="layers" class="w-4 h-4 text-indigo-600"></i>
                    <span class="text-xs font-bold text-slate-700 dark:text-slate-300">Policy Scope:</span>
                    <span class="text-xs text-slate-500 dark:text-slate-400">Select target scope to configure global defaults or specific company overrides.</span>
                </div>
                <div class="w-full sm:w-72">
                    <select onchange="window.location.href = '<?= base_url('system?tab=security') ?>&company_id=' + encodeURIComponent(this.value)" class="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200">
                        <option value="global" <?= empty($companyId) ? 'selected' : '' ?>>🌐 Global / All Companies (Default)</option>
                        <?php foreach ($companies as $comp): ?>
                            <option value="<?= esc($comp['id']) ?>" <?= (!empty($companyId) && $companyId === $comp['id']) ? 'selected' : '' ?>>
                                🏢 <?= esc($comp['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?= base_url('system/security/save') ?>" class="space-y-6">
            <?= csrf_field() ?>
            <input type="hidden" name="security_form_submitted" value="1">
            <input type="hidden" name="company_id" value="<?= esc($companyId ?? '') ?>">
            
            <!-- Password Policy & Complexity -->
            <div class="space-y-4">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Password Policy & Complexity Rules
                </h4>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Minimum Password Length</label>
                        <input type="number" name="min_password_length" min="6" max="32" value="<?= esc($securitySettings['min_password_length'] ?? '8') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                        <span class="text-[11px] text-slate-400">Between 6 and 32 characters (Standard: 8).</span>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Password Expiry (Days)</label>
                        <input type="number" name="password_expiry_days" min="0" max="365" value="<?= esc($securitySettings['password_expiry_days'] ?? '90') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                        <span class="text-[11px] text-slate-400">Set to 0 to disable periodic expiration requirement.</span>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    <label class="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-indigo-500 transition">
                        <input type="hidden" name="require_numbers" value="0">
                        <input type="checkbox" name="require_numbers" value="1" <?= (!empty($securitySettings['require_numbers']) && $securitySettings['require_numbers'] !== '0') ? 'checked' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                        <div>
                            <span class="block text-xs font-bold text-slate-900 dark:text-white">Require Digits</span>
                            <span class="block text-[11px] text-slate-500">Must include 0-9</span>
                        </div>
                    </label>
                    <label class="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-indigo-500 transition">
                        <input type="hidden" name="require_special_chars" value="0">
                        <input type="checkbox" name="require_special_chars" value="1" <?= (!empty($securitySettings['require_special_chars']) && $securitySettings['require_special_chars'] !== '0') ? 'checked' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                        <div>
                            <span class="block text-xs font-bold text-slate-900 dark:text-white">Require Symbols</span>
                            <span class="block text-[11px] text-slate-500">Must include !@#$%^&*</span>
                        </div>
                    </label>
                    <label class="flex items-center gap-3 p-3.5 rounded-xl bg-slate-50/70 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-indigo-500 transition">
                        <input type="hidden" name="require_mixed_case" value="0">
                        <input type="checkbox" name="require_mixed_case" value="1" <?= (!empty($securitySettings['require_mixed_case']) && $securitySettings['require_mixed_case'] !== '0') ? 'checked' : '' ?> class="rounded text-indigo-600 focus:ring-indigo-500">
                        <div>
                            <span class="block text-xs font-bold text-slate-900 dark:text-white">Mixed Casing</span>
                            <span class="block text-[11px] text-slate-500">Upper & lower letters</span>
                        </div>
                    </label>
                </div>
            </div>

            <!-- Brute Force Protection & Session Governance -->
            <div class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Brute Force Protection & Session Lifetime Governance
                </h4>
                
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Max Failed Login Attempts</label>
                        <input type="number" name="max_login_attempts" min="1" max="50" value="<?= esc($securitySettings['max_login_attempts'] ?? '5') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                        <span class="text-[11px] text-slate-400">Triggers temporary account lockout</span>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Lockout Duration (Minutes)</label>
                        <input type="number" name="lockout_minutes" min="1" max="1440" value="<?= esc($securitySettings['lockout_minutes'] ?? '15') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                        <span class="text-[11px] text-slate-400">Cooldown period before next attempt</span>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Session Inactivity Timeout (Minutes)</label>
                        <input type="number" name="session_timeout_minutes" min="5" max="1440" value="<?= esc($securitySettings['session_timeout_minutes'] ?? '120') ?>" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                        <span class="text-[11px] text-slate-400">Auto logout on idle session</span>
                    </div>
                </div>

                <div class="pt-2">
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">IP Whitelist / Access Restriction (Optional CIDRs, comma-separated)</label>
                    <input type="text" name="ip_whitelist" placeholder="e.g. 192.168.1.0/24, 10.0.0.0/8 (Leave empty for unrestricted access)" value="<?= esc($securitySettings['ip_whitelist'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm font-mono text-xs">
                    <span class="text-[11px] text-slate-400">Restricts logins to specified IP ranges or single addresses. Leave empty to allow unrestricted access.</span>
                </div>
            </div>

            <!-- Two-Factor Authentication (2FA) & Session Guard -->
            <div class="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Two-Factor Authentication (2FA) & Session Guard
                </h4>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <label class="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer hover:border-indigo-500 transition">
                        <input type="hidden" name="enforce_2fa_admins" value="0">
                        <input type="checkbox" name="enforce_2fa_admins" value="1" <?= (!empty($securitySettings['enforce_2fa_admins']) && $securitySettings['enforce_2fa_admins'] !== '0') ? 'checked' : '' ?> class="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500">
                        <div>
                            <span class="block text-xs font-bold text-slate-900 dark:text-white">Enforce 2FA for Administrators</span>
                            <span class="block text-[11px] text-slate-500">Mandates OTP verification on login for Super Admin, HR Admin, & Manager roles</span>
                        </div>
                    </label>

                    <label class="flex items-start gap-3 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 cursor-pointer hover:border-indigo-500 transition">
                        <input type="hidden" name="disallow_concurrent_logins" value="0">
                        <input type="checkbox" name="disallow_concurrent_logins" value="1" <?= (!empty($securitySettings['disallow_concurrent_logins']) && $securitySettings['disallow_concurrent_logins'] !== '0') ? 'checked' : '' ?> class="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500">
                        <div>
                            <span class="block text-xs font-bold text-slate-900 dark:text-white">Disallow Concurrent Sessions</span>
                            <span class="block text-[11px] text-slate-500">Terminates previous active browser session when a user signs in from a new device</span>
                        </div>
                    </label>
                </div>
            </div>

            <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700">
                <p class="text-xs text-slate-400">
                    <i data-lucide="lock" class="w-3.5 h-3.5 inline mr-1 text-purple-500"></i>
                    All security policy changes are cryptographically committed to the audit trail.
                </p>
                <button type="submit" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
                    <i data-lucide="shield" class="w-4 h-4"></i>
                    Save Security Policies
                </button>
            </div>
        </form>
    </div>
</div>
