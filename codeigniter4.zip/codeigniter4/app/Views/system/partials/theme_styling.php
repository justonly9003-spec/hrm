<div class="space-y-6">
    <!-- Live Preview Simulator Card -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
        <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
            <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <i data-lucide="sparkles" class="w-4 h-4 text-indigo-600"></i>
                    Interactive Live Preview Simulator
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Preview components with real-time accent color and dark mode tokens</p>
            </div>
            <span id="active-theme-pill" class="text-xs font-bold px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-mono">
                <?= strtoupper(esc($currentTheme ?? 'INDIGO')) ?> THEME
            </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            <!-- Mini simulated card 1 -->
            <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-900/60 space-y-2">
                <div class="flex items-center justify-between">
                    <span class="text-[11px] font-semibold text-slate-500">Buttons & Actions</span>
                    <i data-lucide="play" class="w-3.5 h-3.5 text-slate-400"></i>
                </div>
                <div class="flex flex-wrap gap-2 pt-1">
                    <button type="button" class="px-3 py-1.5 rounded-lg text-xs font-semibold theme-btn-primary shadow-xs transition cursor-pointer">
                        Primary CTA
                    </button>
                    <button type="button" class="px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800">
                        Secondary
                    </button>
                </div>
            </div>

            <!-- Mini simulated card 2 -->
            <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-900/60 space-y-2">
                <div class="flex items-center justify-between">
                    <span class="text-[11px] font-semibold text-slate-500">Badges & Tags</span>
                    <i data-lucide="tag" class="w-3.5 h-3.5 text-slate-400"></i>
                </div>
                <div class="flex flex-wrap gap-2 pt-1">
                    <span class="px-2.5 py-1 rounded-md text-xs font-bold theme-badge-primary border">
                        Active State
                    </span>
                    <span class="px-2.5 py-1 rounded-md text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                        Approved
                    </span>
                </div>
            </div>

            <!-- Mini simulated card 3 -->
            <div class="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-900/60 space-y-2">
                <div class="flex items-center justify-between">
                    <span class="text-[11px] font-semibold text-slate-500">Input Focus Accent</span>
                    <i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-500"></i>
                </div>
                <input type="text" value="Theme accent interactive preview..." class="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs focus:ring-2 focus:outline-none">
            </div>
        </div>
    </div>

    <!-- Theme Form -->
    <form id="theme-settings-form" action="<?= base_url('system/theme/save') ?>" method="POST" class="space-y-6">
        <?= csrf_field() ?>
        <input type="hidden" name="theme" id="form-theme-input" value="<?= esc($currentTheme ?? 'indigo') ?>">
        <input type="hidden" name="theme_mode" id="form-theme-mode-input" value="<?= esc($currentThemeMode ?? 'system') ?>">
        <input type="hidden" name="dark_mode" id="form-dark-input" value="<?= !empty($isDarkMode) ? '1' : '0' ?>">

        <!-- Dark / Light / System Mode Switcher Card -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider text-slate-500 dark:text-slate-400">
                        Interface Canvas & Color Mode
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Controls contrast, backdrop brightness, and operating system sync</p>
                </div>
                <span id="active-mode-badge" class="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                    Mode: <?= ucfirst(esc($currentThemeMode ?? 'system')) ?>
                </span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <!-- Light Mode Card -->
                <div onclick="selectThemeMode('light')" id="mode-card-light" class="theme-mode-card cursor-pointer p-4 rounded-xl border-2 transition flex flex-col justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/40 hover:bg-slate-100 dark:hover:bg-slate-800/80 border-slate-200 dark:border-slate-700">
                    <div class="flex items-center justify-between">
                        <div class="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                            <i data-lucide="sun" class="w-5 h-5"></i>
                        </div>
                        <span class="mode-check-icon hidden text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1 text-[11px]">
                            <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        </span>
                    </div>
                    <div>
                        <h4 class="text-sm font-bold text-slate-900 dark:text-white">Light Canvas</h4>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Crisp, high-contrast canvas optimized for daylight work.</p>
                    </div>
                </div>

                <!-- System Mode Card -->
                <div onclick="selectThemeMode('system')" id="mode-card-system" class="theme-mode-card cursor-pointer p-4 rounded-xl border-2 transition flex flex-col justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/40 hover:bg-slate-100 dark:hover:bg-slate-800/80 border-slate-200 dark:border-slate-700">
                    <div class="flex items-center justify-between">
                        <div class="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                            <i data-lucide="monitor" class="w-5 h-5"></i>
                        </div>
                        <span class="mode-check-icon hidden text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1 text-[11px]">
                            <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        </span>
                    </div>
                    <div>
                        <h4 class="text-sm font-bold text-slate-900 dark:text-white">System Sync</h4>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Matches your device OS preference automatically.</p>
                    </div>
                </div>

                <!-- Dark Mode Card -->
                <div onclick="selectThemeMode('dark')" id="mode-card-dark" class="theme-mode-card cursor-pointer p-4 rounded-xl border-2 transition flex flex-col justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/40 hover:bg-slate-100 dark:hover:bg-slate-800/80 border-slate-200 dark:border-slate-700">
                    <div class="flex items-center justify-between">
                        <div class="w-9 h-9 rounded-xl bg-slate-800 dark:bg-slate-700 text-indigo-400 flex items-center justify-center shrink-0">
                            <i data-lucide="moon" class="w-5 h-5"></i>
                        </div>
                        <span class="mode-check-icon hidden text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1 text-[11px]">
                            <i data-lucide="check" class="w-3.5 h-3.5"></i>
                        </span>
                    </div>
                    <div>
                        <h4 class="text-sm font-bold text-slate-900 dark:text-white">Dark Midnight</h4>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Deep slate backdrop reducing eye strain in low-light.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pre-built Theme Presets Grid -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 p-6 shadow-xs space-y-4">
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
                <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <i data-lucide="palette" class="w-4 h-4 text-indigo-600"></i>
                        Enterprise Brand Themes & Palettes
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">Choose an accent palette tailored to your organization's brand identity</p>
                </div>
                <button type="button" onclick="resetToDefaults()" class="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 transition flex items-center gap-1.5 cursor-pointer">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i> Reset Default
                </button>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                <?php foreach ($themes as $t): ?>
                    <div onclick="selectThemePreset('<?= esc($t['id']) ?>', '<?= esc($t['name']) ?>')" 
                         id="theme-card-<?= esc($t['id']) ?>" 
                         class="theme-preset-card cursor-pointer p-4 rounded-xl border-2 bg-slate-50/50 dark:bg-slate-900/60 hover:shadow-md transition-all duration-200 space-y-2.5 relative border-slate-200 dark:border-slate-700">
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-2.5">
                                <span class="w-4 h-4 rounded-full border border-black/10 shadow-xs" style="background-color: <?= esc($t['primary']) ?>"></span>
                                <span class="w-4 h-4 rounded-full border border-black/10 shadow-xs" style="background-color: <?= esc($t['sidebar']) ?>"></span>
                                <h4 class="text-xs font-bold text-slate-900 dark:text-white"><?= esc($t['name']) ?></h4>
                            </div>
                            <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                                <?= esc($t['badge']) ?>
                            </span>
                        </div>

                        <p class="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                            <?= esc($t['desc']) ?>
                        </p>

                        <div class="pt-2 flex items-center justify-between border-t border-slate-200/60 dark:border-slate-700/60 text-[11px]">
                            <span class="text-slate-400 font-mono text-[10px]">Hex: <?= esc($t['primary']) ?></span>
                            <span class="theme-check-icon hidden text-indigo-600 dark:text-indigo-400 font-bold flex items-center gap-1 text-[11px]">
                                <i data-lucide="check" class="w-3.5 h-3.5"></i> Selected
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Sticky Save Action Bar -->
        <div class="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs flex items-center justify-between">
            <div class="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <i data-lucide="info" class="w-4 h-4 text-indigo-500"></i>
                <span>Theme changes take effect immediately in the live browser preview and persist across sessions.</span>
            </div>
            <button type="submit" class="px-6 py-2.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all flex items-center gap-2">
                <i data-lucide="save" class="w-4 h-4"></i> Save Theme Settings
            </button>
        </div>
    </form>
</div>

<script>
    function updateThemeCardsUI(activeThemeId) {
        document.querySelectorAll('.theme-preset-card').forEach(card => {
            card.classList.remove('border-indigo-600', 'ring-2', 'ring-indigo-100', 'dark:ring-indigo-900', 'shadow-md');
            card.classList.add('border-slate-200', 'dark:border-slate-700');
            const check = card.querySelector('.theme-check-icon');
            if (check) check.classList.add('hidden');
        });

        const activeCard = document.getElementById('theme-card-' + activeThemeId);
        if (activeCard) {
            activeCard.classList.remove('border-slate-200', 'dark:border-slate-700');
            activeCard.classList.add('border-indigo-600', 'ring-2', 'ring-indigo-100', 'dark:ring-indigo-900', 'shadow-md');
            const check = activeCard.querySelector('.theme-check-icon');
            if (check) check.classList.remove('hidden');
        }

        const pill = document.getElementById('active-theme-pill');
        if (pill) {
            pill.textContent = activeThemeId.toUpperCase() + ' THEME';
        }
    }

    function selectThemePreset(themeId, themeName) {
        document.getElementById('form-theme-input').value = themeId;
        const currentMode = document.getElementById('form-theme-mode-input').value || 'system';
        if (window.applyTheme) {
            window.applyTheme(themeId, currentMode, true);
        }
        updateThemeCardsUI(themeId);
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    function updateThemeModeCardsUI(mode) {
        document.querySelectorAll('.theme-mode-card').forEach(card => {
            card.classList.remove('border-indigo-600', 'ring-2', 'ring-indigo-100', 'dark:ring-indigo-900', 'shadow-md');
            card.classList.add('border-slate-200', 'dark:border-slate-700');
            const check = card.querySelector('.mode-check-icon');
            if (check) check.classList.add('hidden');
        });

        const activeCard = document.getElementById('mode-card-' + mode);
        if (activeCard) {
            activeCard.classList.remove('border-slate-200', 'dark:border-slate-700');
            activeCard.classList.add('border-indigo-600', 'ring-2', 'ring-indigo-100', 'dark:ring-indigo-900', 'shadow-md');
            const check = activeCard.querySelector('.mode-check-icon');
            if (check) check.classList.remove('hidden');
        }

        const badge = document.getElementById('active-mode-badge');
        if (badge) {
            badge.textContent = 'Mode: ' + (mode.charAt(0).toUpperCase() + mode.slice(1));
        }
    }

    function selectThemeMode(mode) {
        if (!['light', 'dark', 'system'].includes(mode)) {
            mode = 'system';
        }
        document.getElementById('form-theme-mode-input').value = mode;

        let isDark = false;
        if (mode === 'dark') {
            isDark = true;
        } else if (mode === 'system') {
            isDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
        document.getElementById('form-dark-input').value = isDark ? '1' : '0';

        const currentTheme = document.getElementById('form-theme-input').value || 'indigo';
        if (window.applyTheme) {
            window.applyTheme(currentTheme, mode);
        }

        updateThemeModeCardsUI(mode);

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    // Retain legacy method for backward compatibility
    function selectCanvasMode(isDark) {
        selectThemeMode(isDark ? 'dark' : 'light');
    }

    function resetToDefaults() {
        selectThemePreset('indigo', 'Default Indigo');
        selectThemeMode('system');
    }

    // Initialize Theme UI on load
    (function() {
        const curTheme = localStorage.getItem('ci4_theme') || (document.getElementById('form-theme-input') ? document.getElementById('form-theme-input').value : 'indigo');
        const curMode = localStorage.getItem('ci4_theme_mode') || (document.getElementById('form-theme-mode-input') ? document.getElementById('form-theme-mode-input').value : 'system');
        
        if (document.getElementById('form-theme-input')) {
            document.getElementById('form-theme-input').value = curTheme;
        }
        if (document.getElementById('form-theme-mode-input')) {
            document.getElementById('form-theme-mode-input').value = curMode;
        }

        updateThemeCardsUI(curTheme);
        updateThemeModeCardsUI(curMode);
        
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    })();
</script>
