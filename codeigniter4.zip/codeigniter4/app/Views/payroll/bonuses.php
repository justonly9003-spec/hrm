<script>
window.bonusManagerData = function() {
    return {
        activeTab: 'monthly',
        searchQuery: '',
        statusFilter: 'all',
        selectedMonthlyIds: [],
        selectAllMonthly: false,
        weeklySearchQuery: '',
        weeklyStatusFilter: 'all',
        selectedWeeklyIds: [],
        selectAllWeekly: false,
        showBatchModal: false,
        batchTarget: 'all',
        showAdjustModal: false,
        adjustRecord: { id: '', employee_name: '', bonus_title: '', amount: 0, currency: '<?= !empty($currencyCode) ? esc($currencyCode) : "" ?>' },
        showRejectModal: false,
        rejectRecord: { id: '', employee_name: '', bonus_title: '', reason: '' },
        showRejectWeeklyModal: false,
        rejectWeeklyRecord: { id: '', employee_name: '', week_dates: '', amount: 0, reason: '' },
        showStuckModal: false,
        stuckResolveSubModal: false,
        stuckResolveRecord: { id: '', type: 'regular', action: 'release_hold', employee_name: '', bonus_title: '', amount: 0, reason: '', target_month: '<?= date('Y-m') ?>', payroll_id: '' },
        selectedSchemeId: '<?= !empty($bonusTypes) ? esc($bonusTypes[0]['code'] ?? $bonusTypes[0]['id'] ?? '') : '' ?>',
        bonusTypes: <?= json_encode($bonusTypes ?? []) ?>,
        bonuses: <?= json_encode(array_values($bonuses ?? [])) ?>,
        
        get filteredCount() {
            return (this.bonuses || []).length;
        },

        toggleSelectAllMonthly(checked, allPendingIds) {
            this.selectAllMonthly = checked;
            this.selectedMonthlyIds = checked ? [...allPendingIds] : [];
        },

        toggleSelectAllWeekly(checked, allPendingIds) {
            this.selectAllWeekly = checked;
            this.selectedWeeklyIds = checked ? [...allPendingIds] : [];
        },

        openAdjustModal(rec) {
            this.adjustRecord = { ...rec };
            this.showAdjustModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        openRejectModal(rec) {
            this.rejectRecord = { ...rec, reason: '' };
            this.showRejectModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        openRejectWeeklyModal(rec) {
            this.rejectWeeklyRecord = { ...rec, reason: '' };
            this.showRejectWeeklyModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        openStuckModal() {
            this.showStuckModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        openResolveAction(item, type, action) {
            const empName = item.employee_full_name || item.employee_name || item.employee_code || item.employee_id || 'Unknown';
            const bTitle = item.bonus_title || (type === 'weekly' ? 'Weekly Bonus (' + (item.week_start_date || '') + ')' : 'Bonus');
            this.stuckResolveRecord = {
                id: item.id,
                type: type,
                action: action,
                employee_full_name: empName,
                employee_name: empName,
                employee_code: item.employee_code || '',
                bonus_title: bTitle,
                week_start_date: item.week_start_date || '',
                amount: parseFloat(item.amount || item.bonus_amount || 0),
                reason: '',
                target_month: '<?= date('Y-m') ?>',
                payroll_id: item.payroll_id || ''
            };
            this.stuckResolveSubModal = true;
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        },

        init() {
            this.$nextTick(() => {
                if (window.lucide) window.lucide.createIcons();
            });
        }
    };
};
</script>

<?php
// Compute summary metrics for monthly bonuses
$mPendingCount = 0;
$mApprovedCount = 0;
$mPaidCount = 0;
$mRejectedCount = 0;
$mTotalAmount = 0.0;
$mPendingAmount = 0.0;
$mPendingIds = [];

foreach (($bonuses ?? []) as $mb) {
    $mbStatus = $mb['status'] ?? 'Pending';
    $mbAmt = (float)($mb['amount'] ?? 0);
    $mTotalAmount += $mbAmt;
    if ($mbStatus === 'Pending' && empty($mb['is_settled_in_payroll'])) {
        $mPendingCount++;
        $mPendingAmount += $mbAmt;
        $mPendingIds[] = (string)$mb['id'];
    } elseif ($mbStatus === 'Approved') {
        $mApprovedCount++;
    } elseif ($mbStatus === 'Paid' || !empty($mb['is_settled_in_payroll'])) {
        $mPaidCount++;
    } elseif ($mbStatus === 'Rejected') {
        $mRejectedCount++;
    }
}

// Compute summary metrics for weekly attendance bonuses
$wPendingCount = 0;
$wApprovedCount = 0;
$wPaidCount = 0;
$wRejectedCount = 0;
$wIneligibleCount = 0;
$wTotalAmount = 0.0;
$wPendingIds = [];

foreach (($weeklyBonuses ?? []) as $wb) {
    $wbStatus = $wb['status'] ?? 'Pending';
    $wbAmt = (float)($wb['bonus_amount'] ?? 0);
    $isEligible = !empty($wb['is_eligible']);

    if ($isEligible) {
        $wTotalAmount += $wbAmt;
    } else {
        $wIneligibleCount++;
    }

    if ($wbStatus === 'Pending') {
        $wPendingCount++;
        if ($isEligible) {
            $wPendingIds[] = (string)$wb['id'];
        }
    } elseif ($wbStatus === 'Approved') {
        $wApprovedCount++;
    } elseif ($wbStatus === 'Paid') {
        $wPaidCount++;
    } elseif ($wbStatus === 'Rejected') {
        $wRejectedCount++;
    }
}
?>

<div x-data="bonusManagerData()" class="space-y-6">

    <!-- Rule Configuration Alerts -->
    <?php if (!empty($bonusRuleError)): ?>
        <div class="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200">
            <div class="flex items-center gap-2.5">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0"></i>
                <div>
                    <span><?= esc($bonusRuleError) ?></span>
                </div>
            </div>
            <a href="<?= base_url('rules?domain=BONUS') ?>" class="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-[11px] transition shrink-0 inline-flex items-center gap-1.5 shadow-xs">
                <i data-lucide="settings" class="w-3.5 h-3.5"></i>
                <span>Set up in Rules &gt; BONUS</span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (!empty($payrollBasicsError)): ?>
        <div class="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-rose-900 dark:text-rose-200">
            <div class="flex items-center gap-2.5">
                <i data-lucide="alert-circle" class="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0"></i>
                <div>
                    <span class="font-bold">Payroll currency not configured.</span>
                    <span> <?= esc($payrollBasicsError) ?></span>
                </div>
            </div>
            <a href="<?= base_url('rules?domain=PAYROLL_BASICS') ?>" class="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-[11px] transition shrink-0 inline-flex items-center gap-1.5 shadow-xs">
                <i data-lucide="coins" class="w-3.5 h-3.5"></i>
                <span>Configure Currency</span>
            </a>
        </div>
    <?php endif; ?>

    <?php if (!empty($stuckBonuses['total_count'])): ?>
        <div class="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900 dark:text-amber-200 shadow-xs">
            <div class="flex items-center gap-2.5">
                <i data-lucide="alert-triangle" class="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0"></i>
                <div>
                    <span class="font-bold">Attention: Stuck or Held Bonus Records (<?= esc($stuckBonuses['total_count']) ?>)</span>
                    <div class="text-[11px] text-amber-800 dark:text-amber-300 mt-0.5 space-y-0.5">
                        <?php if (!empty($stuckBonuses['held_deleted_count'])): ?>
                            <span class="block text-rose-700 dark:text-rose-300 font-medium">• <strong><?= esc($stuckBonuses['held_deleted_count']) ?></strong> record(s) totaling <strong><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($stuckBonuses['held_deleted_amount'] ?? 0), 2) ?></strong> are linked to deleted payroll batches and require release or cancellation.</span>
                        <?php endif; ?>
                        <?php if (!empty($stuckBonuses['held_count'])): ?>
                            <span class="block">• <strong><?= esc($stuckBonuses['held_count']) ?></strong> total record(s) totaling <strong><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($stuckBonuses['held_amount'] ?? 0), 2) ?></strong> are held by unfinalized or deleted draft payrolls.</span>
                        <?php endif; ?>
                        <?php if (!empty($stuckBonuses['expired_count'])): ?>
                            <span class="block">• <strong><?= esc($stuckBonuses['expired_count']) ?></strong> record(s) totaling <strong><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($stuckBonuses['expired_amount'] ?? 0), 2) ?></strong> are older than the 12-month carry-forward window (prior to <?= esc($stuckBonuses['cutoff_date'] ?? '') ?>).</span>
                        <?php endif; ?>
                        <?php if (!empty($stuckBonuses['scheduled_unpaid_count'])): ?>
                            <span class="block text-amber-700 dark:text-amber-300 font-medium">• <strong><?= esc($stuckBonuses['scheduled_unpaid_count']) ?></strong> record(s) totaling <strong><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($stuckBonuses['scheduled_unpaid_amount'] ?? 0), 2) ?></strong> were scheduled for locked payroll months but remain unpaid.</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="flex items-center gap-2 shrink-0">
                <a href="<?= base_url('payroll') ?>" class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold text-[11px] transition inline-flex items-center gap-1.5 shadow-xs cursor-pointer" title="Go to Payroll Processing to lock or discard draft batches">
                    <i data-lucide="calculator" class="w-3.5 h-3.5"></i>
                    <span>Payroll Processing</span>
                </a>
                <button type="button" @click="openStuckModal()" class="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-[11px] transition inline-flex items-center gap-1.5 shadow-xs cursor-pointer">
                    <i data-lucide="wrench" class="w-3.5 h-3.5"></i>
                    <span>Review & Resolve</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Header Section -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
        <div>
            <div class="flex items-center gap-2 mb-1.5">
                <span class="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60 flex items-center gap-1.5">
                    <i data-lucide="gift" class="w-3.5 h-3.5 text-indigo-600"></i>
                    Compensation & Incentives
                </span>
            </div>
            <h2 class="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Bonus & Incentive Management</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Manage corporate festival bonuses, performance incentives, weekly punctuality rewards, and dual-control approval workflows.</p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
            <a 
                href="<?= base_url('rules?domain=BONUS') ?>"
                class="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            >
                <i data-lucide="sliders" class="w-4 h-4"></i>
                <span>Configure Schemes (Rule Engine)</span>
            </a>
            <button 
                @click="showBatchModal = true"
                class="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm shadow-indigo-600/20 cursor-pointer"
            >
                <i data-lucide="sparkles" class="w-4 h-4"></i>
                <span>Run Monthly Batch</span>
            </button>
        </div>
    </div>

    <!-- Tab Navigation -->
    <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800">
        <button 
            type="button" 
            @click="activeTab = 'monthly'; $nextTick(() => { if (window.lucide) window.lucide.createIcons(); })"
            :class="activeTab === 'monthly' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold bg-white dark:bg-slate-900 shadow-xs' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'"
            class="px-4 py-3 text-xs border-b-2 rounded-t-xl flex items-center gap-2 transition cursor-pointer"
        >
            <i data-lucide="gift" class="w-4 h-4"></i>
            <span>Corporate & Festival Bonuses</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono"><?= count($bonuses ?? []) ?></span>
        </button>
        <button 
            type="button" 
            @click="activeTab = 'weekly'; $nextTick(() => { if (window.lucide) window.lucide.createIcons(); })"
            :class="activeTab === 'weekly' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold bg-white dark:bg-slate-900 shadow-xs' : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'"
            class="px-4 py-3 text-xs border-b-2 rounded-t-xl flex items-center gap-2 transition cursor-pointer"
        >
            <i data-lucide="calendar-check" class="w-4 h-4"></i>
            <span>Weekly Attendance & Punctuality</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-mono font-bold"><?= count($weeklyBonuses ?? []) ?></span>
            <?php if ($wPendingCount > 0): ?>
                <span class="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="<?= $wPendingCount ?> pending approval"></span>
            <?php endif; ?>
        </button>
    </div>

    <!-- ========================================== -->
    <!-- TAB 1: MONTHLY & FESTIVAL BONUS SCHEMES    -->
    <!-- ========================================== -->
    <div x-show="activeTab === 'monthly'" class="space-y-6">

        <!-- Bonus Schemes Grid -->
        <div>
            <div class="flex items-center justify-between mb-3 px-1">
                <h3 class="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Configured Bonus Schemes (Rule Store)</h3>
                <span class="text-xs text-slate-400 font-mono"><?= count($activeSchemes ?? []) ?> Active / <?= count($schemes ?? $bonusTypes ?? []) ?> Total</span>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <?php if (!empty($bonusTypes)): ?>
                    <?php foreach ($bonusTypes as $type): ?>
                        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm relative overflow-hidden group">
                            <div class="absolute right-0 top-0 w-16 h-16 bg-indigo-50/60 dark:bg-indigo-950/40 rounded-bl-full flex items-center justify-end pr-3 pt-3">
                                <i data-lucide="gift" class="w-5 h-5 text-indigo-500/60"></i>
                            </div>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-2">
                                    <p class="text-xs font-semibold text-slate-400">Code: <?= esc($type['code'] ?? $type['id'] ?? 'SCHEME') ?></p>
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= ($type['status'] ?? 'Active') === 'Inactive' ? 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-400' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' ?>">
                                        <?= esc($type['status'] ?? 'Active') ?>
                                    </span>
                                </div>
                                <a href="<?= base_url('rules?domain=BONUS') ?>" class="text-slate-400 hover:text-indigo-600 transition-colors p-1" title="Configure in Rule Engine">
                                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                                </a>
                            </div>
                            <h4 class="text-sm font-extrabold text-slate-800 dark:text-white mt-1"><?= esc($type['name'] ?? 'Bonus Scheme') ?></h4>
                            <div class="mt-4 flex items-center justify-between">
                                <span class="text-xs text-slate-500 dark:text-slate-400">
                                    <?php
                                        $calcType = $type['calculation_type'] ?? 'Percentage_Basic';
                                        if ($calcType === 'Percentage_Basic') {
                                            echo '% of Basic Salary';
                                        } elseif ($calcType === 'Percentage_Gross') {
                                            echo '% of Gross Salary';
                                        } else {
                                            echo 'Flat Amount';
                                        }
                                    ?>
                                </span>
                                <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                                    <?php
                                        if ($calcType === 'Percentage_Basic' || $calcType === 'Percentage_Gross') {
                                            echo esc($type['value']) . '%';
                                        } elseif (!empty($currencyCode)) {
                                            echo esc($currencyCode) . ' ' . number_format((float)($type['value'] ?? 0), 2);
                                        } else {
                                            echo '<span class="text-rose-500 font-semibold" title="Currency not configured in Rules > PAYROLL_BASICS">Currency missing</span>';
                                        }
                                    ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-span-3 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-center text-slate-400 text-xs">
                        No bonus schemes configured in Rule Store. Configure them in <a href="<?= base_url('rules?domain=BONUS') ?>" class="text-indigo-600 font-bold hover:underline">Rules &gt; BONUS</a>.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Monthly Records Table Container -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
            
            <!-- Search & Filter Bar -->
            <div class="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div class="relative w-full max-w-md">
                    <i data-lucide="search" class="w-4 h-4 absolute left-3 top-3 text-slate-400"></i>
                    <input 
                        type="text" 
                        x-model="searchQuery"
                        placeholder="Search bonus description, employee code or name..." 
                        class="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-white"
                    />
                </div>
                <div class="flex items-center gap-2 text-xs text-slate-500 font-mono">
                    <span>Total Disbursals: <strong><?= count($bonuses ?? []) ?></strong></span>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/75 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800">
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Bonus ID</th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Employee</th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Bonus Description</th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-center">Period / Term</th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Amount <?= !empty($currencyCode) ? '(' . esc($currencyCode) . ')' : '(Currency missing)' ?></th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-center">Status</th>
                            <th class="px-6 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60">
                        <?php if (empty($bonuses)): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-12 text-center text-slate-400 text-xs">
                                    <i data-lucide="alert-circle" class="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600"></i>
                                    No bonus allocations recorded. Run a bonus batch above.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($bonuses as $rec): ?>
                                <tr 
                                    x-show="!searchQuery || '<?= strtolower(esc($rec['employee_name'] . ' ' . ($rec['employee_code'] ?? '') . ' ' . $rec['bonus_title'])) ?>'.includes(searchQuery.toLowerCase())"
                                    class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors"
                                >
                                    <td class="px-6 py-4">
                                        <div class="text-xs font-bold text-indigo-600 dark:text-indigo-400 font-mono">#<?= esc(substr($rec['id'], 0, 10)) ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-xs font-bold text-slate-800 dark:text-white"><?= esc($rec['employee_name']) ?></div>
                                        <div class="text-[10px] text-slate-400"><?= esc($rec['employee_code'] ?? 'ID: ' . substr($rec['employee_id'], 0, 8)) ?> &bull; <?= esc($rec['department_name'] ?? 'General') ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-xs font-medium text-slate-700 dark:text-slate-200"><?= esc($rec['bonus_title']) ?></div>
                                        <span class="inline-block mt-0.5 px-2 py-0.2 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-500 font-mono">
                                            <?= esc($rec['category'] ?? $rec['bonus_type'] ?? 'Festival') ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center font-mono text-xs text-slate-600 dark:text-slate-400">
                                        <?= esc($rec['bonus_month']) ?> <?= esc($rec['year'] ?? '') ?>
                                    </td>
                                    <td class="px-6 py-4 text-right font-mono text-xs font-extrabold text-slate-900 dark:text-white">
                                        <?= !empty($currencyCode) ? (esc($currencyCode) . ' ' . number_format((float)($rec['amount'] ?? 0), 2)) : '<span class="text-rose-500 font-semibold" title="Currency not configured in Rules > PAYROLL_BASICS">Currency missing</span>' ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <?php 
                                            $statusVal = $rec['status'] ?? 'Pending';
                                            $badgeClasses = 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400 border border-amber-200/60 dark:border-amber-800/60';
                                            if ($statusVal === 'Approved') {
                                                $badgeClasses = 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60';
                                            } elseif ($statusVal === 'Rejected') {
                                                $badgeClasses = 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 border border-rose-200/60 dark:border-rose-800/60';
                                            } elseif ($statusVal === 'Settled' || $statusVal === 'Paid' || !empty($rec['is_settled_in_payroll'])) {
                                                $badgeClasses = 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60';
                                            }
                                        ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold <?= $badgeClasses ?>">
                                            <?= esc($statusVal) ?>
                                        </span>
                                        <?php if (!empty($rec['is_settled_in_payroll'])): ?>
                                            <div class="text-[9px] text-slate-400 font-mono mt-0.5" title="Settled in payroll batch">Settled in Payroll</div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <?php if (($rec['status'] ?? 'Pending') === 'Pending' && empty($rec['is_settled_in_payroll'])): ?>
                                                <form method="post" action="<?= base_url('payroll/bonuses/approve/' . $rec['id']) ?>" class="inline">
                                                    <?= csrf_field() ?>
                                                    <button 
                                                        type="submit" 
                                                        class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-lg text-[10px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer"
                                                    >
                                                        <i data-lucide="check" class="w-3 h-3"></i> Approve
                                                    </button>
                                                </form>
                                                <button 
                                                    type="button" 
                                                    @click="openRejectModal({
                                                        id: '<?= esc($rec['id']) ?>',
                                                        employee_name: '<?= esc(addslashes($rec['employee_name'] ?? '')) ?>',
                                                        bonus_title: '<?= esc(addslashes($rec['bonus_title'] ?? '')) ?>'
                                                    })"
                                                    class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-lg text-[10px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer"
                                                >
                                                    <i data-lucide="x" class="w-3 h-3"></i> Reject
                                                </button>
                                            <?php endif; ?>

                                            <?php if (empty($rec['is_settled_in_payroll']) && ($rec['status'] ?? '') !== 'Paid'): ?>
                                                <button 
                                                    type="button" 
                                                    @click="openAdjustModal({
                                                        id: '<?= esc($rec['id']) ?>',
                                                        employee_name: '<?= esc(addslashes($rec['employee_name'] ?? '')) ?>',
                                                        bonus_title: '<?= esc(addslashes($rec['bonus_title'] ?? '')) ?>',
                                                        amount: <?= (float)($rec['amount'] ?? 0) ?>,
                                                        currency: '<?= !empty($currencyCode) ? esc($currencyCode) : "" ?>'
                                                    })"
                                                    class="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition-colors cursor-pointer"
                                                    title="Adjust / Edit Amount"
                                                >
                                                    <i data-lucide="pencil" class="w-3.5 h-3.5"></i>
                                                </button>
                                                <?php if (($rec['status'] ?? 'Pending') !== 'Approved'): ?>
                                                    <form method="post" action="<?= base_url('payroll/bonuses/delete/' . $rec['id']) ?>" onsubmit="return confirm('Delete this bonus record?')" class="inline">
                                                        <?= csrf_field() ?>
                                                        <button 
                                                            type="submit" 
                                                            class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                                                            title="Delete"
                                                        >
                                                            <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1 text-[11px] text-slate-400 font-mono px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md" title="Record locked: settled in payroll">
                                                    <i data-lucide="lock" class="w-3 h-3 text-slate-400"></i> Locked
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- ============================================== -->
    <!-- TAB 2: WEEKLY ATTENDANCE & PUNCTUALITY BONUSES -->
    <!-- ============================================== -->
    <div x-show="activeTab === 'weekly'" x-cloak class="space-y-6">

        <!-- Weekly Summary KPI Cards -->
        <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
            <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                <span class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Total Weekly Records</span>
                <span class="text-xl font-black text-slate-900 dark:text-white font-mono mt-1 block"><?= count($weeklyBonuses ?? []) ?></span>
                <span class="text-[10px] text-slate-400 mt-1 block"><?= $wIneligibleCount ?> Ineligible entries</span>
            </div>
            <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-amber-200/60 dark:border-amber-900/40 shadow-xs bg-amber-50/20 dark:bg-amber-950/20">
                <span class="text-[11px] font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">Pending Approval</span>
                <span class="text-xl font-black text-amber-700 dark:text-amber-300 font-mono mt-1 block"><?= $wPendingCount ?></span>
                <span class="text-[10px] text-amber-600/80 mt-1 block">Maker-checker gate</span>
            </div>
            <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-emerald-200/60 dark:border-emerald-900/40 shadow-xs bg-emerald-50/20 dark:bg-emerald-950/20">
                <span class="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">Approved Records</span>
                <span class="text-xl font-black text-emerald-700 dark:text-emerald-300 font-mono mt-1 block"><?= $wApprovedCount ?></span>
                <span class="text-[10px] text-emerald-600/80 mt-1 block">Ready for payroll batch</span>
            </div>
            <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-indigo-200/60 dark:border-indigo-900/40 shadow-xs bg-indigo-50/20 dark:bg-indigo-950/20">
                <span class="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block">Paid / Settled</span>
                <span class="text-xl font-black text-indigo-700 dark:text-indigo-300 font-mono mt-1 block"><?= $wPaidCount ?></span>
                <span class="text-[10px] text-indigo-600/80 mt-1 block">Consumed in payroll</span>
            </div>
            <div class="col-span-2 sm:col-span-1 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
                <span class="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Eligible Value</span>
                <span class="text-xl font-black text-slate-900 dark:text-white font-mono mt-1 block">
                    <?= !empty($currencyCode) ? (esc($currencyCode) . ' ' . number_format($wTotalAmount, 2)) : number_format($wTotalAmount, 2) ?>
                </span>
                <span class="text-[10px] text-slate-400 mt-1 block"><?= $wRejectedCount ?> Rejected records</span>
            </div>
        </div>

        <!-- Weekly Records Container -->
        <div class="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
            
            <!-- Toolbar: Search, Filters, and Batch Actions -->
            <div class="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div class="flex flex-wrap items-center gap-2.5 flex-1 max-w-xl">
                    <div class="relative flex-1 min-w-[200px]">
                        <i data-lucide="search" class="w-4 h-4 absolute left-3 top-3 text-slate-400"></i>
                        <input 
                            type="text" 
                            x-model="weeklySearchQuery"
                            placeholder="Filter by employee name, code, department, or date..." 
                            class="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-white"
                        />
                    </div>
                    <select 
                        x-model="weeklyStatusFilter" 
                        class="px-3 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                        <option value="all">All Statuses</option>
                        <option value="Pending">Pending (<?= $wPendingCount ?>)</option>
                        <option value="Approved">Approved (<?= $wApprovedCount ?>)</option>
                        <option value="Paid">Paid / Settled (<?= $wPaidCount ?>)</option>
                        <option value="Rejected">Rejected (<?= $wRejectedCount ?>)</option>
                        <option value="Ineligible">Ineligible (<?= $wIneligibleCount ?>)</option>
                    </select>
                </div>

                <div class="flex items-center gap-2">
                    <!-- Batch Approve Weekly Form -->
                    <form method="POST" action="<?= base_url('payroll/bonuses/batch-approve-weekly') ?>" class="inline" onsubmit="return confirm('Approve the selected weekly bonus allocations?')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="selected_ids" :value="selectedWeeklyIds.join(',')">
                        <button 
                            type="submit" 
                            :disabled="selectedWeeklyIds.length === 0 && <?= $wPendingCount === 0 ? 'true' : 'false' ?>"
                            class="px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs disabled:opacity-50 disabled:cursor-not-allowed bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer"
                        >
                            <i data-lucide="check-check" class="w-4 h-4"></i>
                            <span x-text="selectedWeeklyIds.length > 0 ? ('Approve Selected (' + selectedWeeklyIds.length + ')') : 'Batch Approve All Pending'"></span>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Weekly Bonuses Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/75 dark:bg-slate-800/60 border-b border-slate-200/80 dark:border-slate-800">
                            <th class="px-4 py-3.5 text-center w-10">
                                <input 
                                    type="checkbox" 
                                    @change="toggleSelectAllWeekly($event.target.checked, <?= htmlspecialchars(json_encode($wPendingIds)) ?>)"
                                    class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                    title="Select all pending weekly records"
                                />
                            </th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Week Period</th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Employee</th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Attendance & Eligibility</th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Amount <?= !empty($currencyCode) ? '(' . esc($currencyCode) . ')' : '' ?></th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-center">Status</th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Audit / Approver</th>
                            <th class="px-5 py-3.5 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800/60">
                        <?php if (empty($weeklyBonuses)): ?>
                            <tr>
                                <td colspan="8" class="px-6 py-12 text-center text-slate-400 text-xs">
                                    <i data-lucide="calendar-x" class="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600"></i>
                                    No weekly attendance bonus records generated yet. Weekly jobs run automatically on weekly close or via Scheduler.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($weeklyBonuses as $wb): ?>
                                <?php
                                    $wStatus = $wb['status'] ?? 'Pending';
                                    $wEligible = !empty($wb['is_eligible']);
                                    $empName = trim($wb['employee_full_name'] ?? '') ?: ('Employee ' . substr($wb['employee_id'], 0, 8));
                                    $empCode = $wb['employee_code'] ?? 'ID: ' . substr($wb['employee_id'], 0, 8);
                                    $deptTitle = $wb['dept_title'] ?? 'General';
                                    $wFilterSearch = strtolower($empName . ' ' . $empCode . ' ' . $deptTitle . ' ' . ($wb['week_start_date'] ?? '') . ' ' . ($wb['week_end_date'] ?? ''));
                                ?>
                                <tr 
                                    x-show="(!weeklySearchQuery || '<?= esc(addslashes($wFilterSearch)) ?>'.includes(weeklySearchQuery.toLowerCase())) && (weeklyStatusFilter === 'all' || (weeklyStatusFilter === 'Ineligible' ? <?= $wEligible ? 'false' : 'true' ?> : weeklyStatusFilter === '<?= esc($wStatus) ?>'))"
                                    class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition-colors"
                                >
                                    <td class="px-4 py-4 text-center">
                                        <?php if ($wStatus === 'Pending' && $wEligible): ?>
                                            <input 
                                                type="checkbox" 
                                                value="<?= esc($wb['id']) ?>" 
                                                x-model="selectedWeeklyIds"
                                                class="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                                            />
                                        <?php else: ?>
                                            <span class="text-slate-300 dark:text-slate-700">&bull;</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-4">
                                        <div class="text-xs font-bold text-slate-900 dark:text-white font-mono">
                                            <?= esc(date('M d', strtotime($wb['week_start_date']))) ?> &ndash; <?= esc(date('M d, Y', strtotime($wb['week_end_date']))) ?>
                                        </div>
                                        <div class="text-[10px] text-slate-400 font-mono">ID: #<?= esc(substr($wb['id'], 0, 10)) ?></div>
                                    </td>
                                    <td class="px-5 py-4">
                                        <div class="text-xs font-bold text-slate-800 dark:text-white"><?= esc($empName) ?></div>
                                        <div class="text-[10px] text-slate-400"><?= esc($empCode) ?> &bull; <?= esc($deptTitle) ?></div>
                                    </td>
                                    <td class="px-5 py-4">
                                        <div class="flex items-center gap-1.5">
                                            <?php if ($wEligible): ?>
                                                <span class="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                                                    <i data-lucide="check-circle" class="w-3.5 h-3.5 text-emerald-600"></i>
                                                    <span>100% Eligible</span>
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-600 dark:text-rose-400" title="<?= esc($wb['ineligibility_reason'] ?? 'Not eligible') ?>">
                                                    <i data-lucide="alert-circle" class="w-3.5 h-3.5 text-rose-500"></i>
                                                    <span><?= esc(substr($wb['ineligibility_reason'] ?? 'Ineligible', 0, 32)) ?></span>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <span class="text-[10px] text-slate-400 block mt-0.5 font-mono">
                                            <?= esc($wb['calculation_method'] ?? 'Weekly Attendance') ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-4 text-right font-mono text-xs font-extrabold text-slate-900 dark:text-white">
                                        <?= !empty($currencyCode) ? (esc($currencyCode) . ' ' . number_format((float)($wb['bonus_amount'] ?? 0), 2)) : number_format((float)($wb['bonus_amount'] ?? 0), 2) ?>
                                    </td>
                                    <td class="px-5 py-4 text-center">
                                        <?php
                                            $wBadgeClass = 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400 border border-amber-200/60 dark:border-amber-800/60';
                                            if ($wStatus === 'Approved') {
                                                $wBadgeClass = 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border border-emerald-200/60 dark:border-emerald-800/60';
                                            } elseif ($wStatus === 'Paid') {
                                                $wBadgeClass = 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60';
                                            } elseif ($wStatus === 'Rejected') {
                                                $wBadgeClass = 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 border border-rose-200/60 dark:border-rose-800/60';
                                            }
                                        ?>
                                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold <?= $wBadgeClass ?>">
                                            <?= esc($wStatus) ?>
                                        </span>
                                        <?php if (!empty($wb['payroll_id'])): ?>
                                            <div class="text-[9px] text-slate-400 font-mono mt-0.5" title="Linked to payroll batch <?= esc($wb['payroll_id']) ?>">
                                                <?= $wStatus === 'Paid' ? 'Settled in Batch' : 'Linked to Draft' ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-4 text-xs text-slate-500 dark:text-slate-400">
                                        <?php if (!empty($wb['approved_by'])): ?>
                                            <div class="text-[11px] font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1">
                                                <i data-lucide="user-check" class="w-3 h-3 text-emerald-600 shrink-0"></i>
                                                <span class="truncate max-w-[140px]" title="<?= esc($wb['approved_by']) ?>"><?= esc($wb['approved_by']) ?></span>
                                            </div>
                                            <?php if (!empty($wb['approved_at'])): ?>
                                                <div class="text-[10px] text-slate-400 font-mono"><?= esc(date('M d, H:i', strtotime($wb['approved_at']))) ?></div>
                                            <?php endif; ?>
                                        <?php elseif (!empty($wb['rejection_reason'])): ?>
                                            <div class="text-[10px] text-rose-600 dark:text-rose-400 italic" title="<?= esc($wb['rejection_reason']) ?>">
                                                <?= esc(substr($wb['rejection_reason'], 0, 35)) ?><?= strlen($wb['rejection_reason']) > 35 ? '...' : '' ?>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-[10px] text-slate-400 font-mono">Awaiting Review</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-5 py-4 text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <?php if ($wStatus === 'Pending' && $wEligible): ?>
                                                <form method="post" action="<?= base_url('payroll/bonuses/approve-weekly/' . $wb['id']) ?>" class="inline">
                                                    <?= csrf_field() ?>
                                                    <button 
                                                        type="submit" 
                                                        class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 rounded-lg text-[10px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer"
                                                        title="Approve weekly bonus allocation"
                                                    >
                                                        <i data-lucide="check" class="w-3 h-3"></i> Approve
                                                    </button>
                                                </form>
                                                <button 
                                                    type="button" 
                                                    @click="openRejectWeeklyModal({
                                                        id: '<?= esc($wb['id']) ?>',
                                                        employee_name: '<?= esc(addslashes($empName)) ?>',
                                                        week_dates: '<?= esc(date('M d', strtotime($wb['week_start_date']))) ?> - <?= esc(date('M d, Y', strtotime($wb['week_end_date']))) ?>',
                                                        amount: <?= (float)($wb['bonus_amount'] ?? 0) ?>
                                                    })"
                                                    class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-lg text-[10px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer"
                                                    title="Reject weekly bonus allocation"
                                                >
                                                    <i data-lucide="x" class="w-3 h-3"></i> Reject
                                                </button>
                                            <?php elseif ($wStatus === 'Approved'): ?>
                                                <button 
                                                    type="button" 
                                                    @click="openRejectWeeklyModal({
                                                        id: '<?= esc($wb['id']) ?>',
                                                        employee_name: '<?= esc(addslashes($empName)) ?>',
                                                        week_dates: '<?= esc(date('M d', strtotime($wb['week_start_date']))) ?> - <?= esc(date('M d, Y', strtotime($wb['week_end_date']))) ?>',
                                                        amount: <?= (float)($wb['bonus_amount'] ?? 0) ?>
                                                    })"
                                                    class="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 rounded-lg text-[10px] font-bold transition-all inline-flex items-center gap-1 cursor-pointer"
                                                    title="Reject and revoke approval before payroll finalization"
                                                >
                                                    <i data-lucide="x" class="w-3 h-3"></i> Revoke / Reject
                                                </button>
                                            <?php elseif ($wStatus === 'Paid'): ?>
                                                <span class="inline-flex items-center gap-1 text-[10px] text-slate-400 font-mono px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md">
                                                    <i data-lucide="lock" class="w-3 h-3"></i> Settled
                                                </span>
                                            <?php else: ?>
                                                <span class="text-[10px] text-slate-400 italic">No action</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- MODAL: Run Bonus Batch (Monthly) -->
    <div x-show="showBatchModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" @click.self="showBatchModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="sparkles" class="w-5 h-5 text-indigo-600"></i>
                    Run Bonus Batch Disbursal
                </h3>
                <button type="button" @click="showBatchModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form method="POST" action="<?= base_url('payroll/bonuses/create') ?>" class="space-y-4">
                <?= csrf_field() ?>
                
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Select Bonus Scheme <span class="text-rose-500">*</span></label>
                    <select name="scheme_id" required <?= empty($activeSchemes) ? 'disabled' : '' ?> class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-100 disabled:dark:bg-slate-800/60 disabled:text-slate-400 disabled:cursor-not-allowed [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                        <?php if (!empty($activeSchemes)): ?>
                            <option value="">-- Choose active scheme --</option>
                            <?php foreach ($activeSchemes as $t): ?>
                                <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="<?= esc($t['code'] ?? '') ?>">
                                    <?= esc($t['name'] ?? 'Bonus Scheme') ?> (<?= esc($t['code'] ?? '') ?> &bull; <?php
                                        $cType = $t['calculation_type'] ?? 'Percentage_Basic';
                                        if ($cType === 'Percentage_Basic') {
                                             echo esc($t['value']) . '% of Basic';
                                        } elseif ($cType === 'Percentage_Gross') {
                                            echo esc($t['value']) . '% of Gross';
                                        } elseif ($cType === 'Flat') {
                                            echo !empty($currencyCode) ? (esc($currencyCode) . ' ' . number_format((float)($t['value'] ?? 0), 2)) : 'Flat Amount (Currency missing)';
                                        } else {
                                            echo 'Formula';
                                        }
                                    ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No active bonus schemes available (activate or configure in Rules &gt; BONUS)</option>
                        <?php endif; ?>
                    </select>
                    <?php if (empty($activeSchemes)): ?>
                        <p class="text-[11px] text-amber-600 dark:text-amber-400 mt-1.5 flex items-center gap-1 font-medium">
                            <i data-lucide="alert-triangle" class="w-3.5 h-3.5 shrink-0"></i>
                            <span>No active bonus schemes available. <a href="<?= base_url('rules?domain=BONUS') ?>" class="underline font-bold">Configure / activate in Rules &gt; BONUS</a>.</span>
                        </p>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Bonus Title / Reason</label>
                    <input type="text" name="title" required placeholder="e.g. Eid-ul-Adha Corporate Bonus" value="Corporate Festival Bonus" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Payroll Month</label>
                    <input type="month" name="month" required value="<?= date('Y-m') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5 flex items-center gap-1.5">
                        <i data-lucide="shield-alert" class="w-3.5 h-3.5 text-indigo-500 shrink-0"></i>
                        <span>All records are generated in <strong>Pending</strong> status for audited dual-control approval.</span>
                    </p>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Eligible Workforce Cohort</label>
                    <select name="target" x-model="batchTarget" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                        <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="all">All Active Staff (Enterprise-wide)</option>
                        <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="department">Specific Department</option>
                        <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="individual">Single Individual Employee</option>
                    </select>
                </div>

                <div x-show="batchTarget === 'department'" x-cloak class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Select Department <span class="text-rose-500">*</span></label>
                    <select name="department_id" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                        <option value="">-- Choose department --</option>
                        <?php foreach (($departments ?? []) as $d): ?>
                            <option value="<?= esc($d['id']) ?>"><?= esc($d['name'] ?? 'Department') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div x-show="batchTarget === 'individual'" x-cloak class="space-y-1">
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Select Employee <span class="text-rose-500">*</span></label>
                    <select name="employee_id" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                        <option value="">-- Choose employee --</option>
                        <?php foreach (($employees ?? []) as $e): ?>
                            <?php $eDisplayName = trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')) ?: ($e['name'] ?? $e['employee_code'] ?? $e['id']); ?>
                            <option value="<?= esc($e['id']) ?>"><?= esc($eDisplayName) ?> (<?= esc($e['employee_code'] ?? $e['employee_id'] ?? $e['id']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex justify-end gap-2 pt-3">
                    <button type="button" @click="showBatchModal = false" class="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Cancel</button>
                    <button type="submit" <?= empty($bonusTypes) ? 'disabled class="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-slate-400 dark:bg-slate-700 cursor-not-allowed shadow-none"' : 'class="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm cursor-pointer"' ?>>Execute Batch Disbursal</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Adjust / Edit Bonus Record (Monthly) -->
    <div x-show="showAdjustModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" @click.self="showAdjustModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="edit-3" class="w-5 h-5 text-indigo-600"></i>
                    <span>Adjust Bonus Record</span>
                </h3>
                <button type="button" @click="showAdjustModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form method="POST" :action="'<?= base_url('payroll/bonuses/adjust/') ?>/' + adjustRecord.id" class="space-y-4">
                <?= csrf_field() ?>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Employee & Bonus</label>
                    <p class="text-xs font-semibold text-slate-900 dark:text-white px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200/60 dark:border-slate-700/60" x-text="adjustRecord.employee_name + ' — ' + adjustRecord.bonus_title"></p>
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Adjusted Amount (<span x-text="adjustRecord.currency"></span>)</label>
                    <input type="number" step="0.01" min="0" name="amount" required x-model.number="adjustRecord.amount" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Reason for Adjustment <span class="text-rose-500">*</span></label>
                    <textarea name="reason" rows="2" required placeholder="State audited justification for this adjustment..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                </div>
                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <button type="button" @click="showAdjustModal = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm cursor-pointer">Save Adjustment</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Reject Bonus Record (Monthly) -->
    <div x-show="showRejectModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" @click.self="showRejectModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="x-circle" class="w-5 h-5 text-rose-600"></i>
                    <span>Reject Bonus Record</span>
                </h3>
                <button type="button" @click="showRejectModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form method="POST" :action="'<?= base_url('payroll/bonuses/reject/') ?>/' + rejectRecord.id" class="space-y-4">
                <?= csrf_field() ?>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Employee & Bonus</label>
                    <p class="text-xs font-semibold text-slate-900 dark:text-white px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200/60 dark:border-slate-700/60" x-text="rejectRecord.employee_name + ' — ' + rejectRecord.bonus_title"></p>
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Rejection Reason <span class="text-rose-500">*</span></label>
                    <textarea name="reason" rows="3" required x-model="rejectRecord.reason" placeholder="State mandatory business/audited reason for rejecting this bonus allocation..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"></textarea>
                </div>
                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <button type="button" @click="showRejectModal = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-sm cursor-pointer">Confirm Rejection</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Reject Weekly Bonus Record -->
    <div x-show="showRejectWeeklyModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" @click.self="showRejectWeeklyModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <i data-lucide="x-circle" class="w-5 h-5 text-rose-600"></i>
                    <span>Reject Weekly Bonus Allocation</span>
                </h3>
                <button type="button" @click="showRejectWeeklyModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <form method="POST" :action="'<?= base_url('payroll/bonuses/reject-weekly') ?>/' + rejectWeeklyRecord.id" class="space-y-4">
                <?= csrf_field() ?>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Employee & Week</label>
                    <p class="text-xs font-semibold text-slate-900 dark:text-white px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200/60 dark:border-slate-700/60" x-text="rejectWeeklyRecord.employee_name + ' (' + rejectWeeklyRecord.week_dates + ')'"></p>
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Mandatory Rejection Reason <span class="text-rose-500">*</span></label>
                    <textarea name="reason" rows="3" required x-model="rejectWeeklyRecord.reason" placeholder="State business/audited reason for rejecting this weekly bonus allocation..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"></textarea>
                </div>
                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <button type="button" @click="showRejectWeeklyModal = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Cancel</button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 shadow-sm cursor-pointer">Confirm Rejection</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: Review & Resolve Stuck / Held Bonuses -->
    <div x-show="showStuckModal" x-cloak class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" @click.self="showStuckModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-4xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 max-h-[90vh] flex flex-col" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 shrink-0">
                <div class="flex items-center gap-2.5">
                    <div class="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center border border-amber-200 dark:border-amber-800">
                        <i data-lucide="alert-triangle" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-slate-900 dark:text-white text-base">Stuck & Draft-Held Bonuses Resolution</h3>
                        <p class="text-xs text-slate-500 dark:text-slate-400">Release draft linkage holds, sweep expired bonuses into upcoming payroll, or cancel allocations.</p>
                    </div>
                </div>
                <button type="button" @click="showStuckModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer p-1">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <div class="overflow-y-auto space-y-6 pr-1 grow">
                <!-- Group 1: Draft-Held Bonuses -->
                <?php 
                $slimStuckRecord = function(array $r, string $type): array {
                    $fullName = (string)($r['employee_full_name'] ?? $r['employee_name'] ?? '');
                    $empCode = (string)($r['employee_code'] ?? '');
                    $empName = $fullName !== '' ? $fullName : ($empCode !== '' ? $empCode : (string)($r['employee_id'] ?? 'Unknown'));
                    $weekStart = (string)($r['week_start_date'] ?? '');
                    $bonusTitle = (string)($r['bonus_title'] ?? ($type === 'weekly' ? ($weekStart !== '' ? 'Weekly Bonus (' . $weekStart . ')' : 'Weekly Bonus') : ($r['bonus_name'] ?? 'Bonus')));
                    return [
                        'id'                 => (string)($r['id'] ?? ''),
                        '_type'              => (string)$type,
                        'employee_full_name' => $fullName !== '' ? $fullName : $empName,
                        'employee_name'      => $empName,
                        'employee_code'      => $empCode,
                        'bonus_title'        => $bonusTitle,
                        'week_start_date'    => $weekStart,
                        'amount'             => (float)($r['amount'] ?? $r['bonus_amount'] ?? 0),
                        'status'             => (string)($r['status'] ?? ''),
                        'payout_month'       => (string)($r['payout_month'] ?? ''),
                        'payroll_id'         => (string)($r['payroll_id'] ?? ''),
                    ];
                };
                $deletedHeldItems = array_merge(
                    array_map(fn($r) => array_merge($r, ['_type' => 'regular']), $stuckBonuses['held_deleted_regular'] ?? []),
                    array_map(fn($r) => array_merge($r, ['_type' => 'weekly']), $stuckBonuses['held_deleted_weekly'] ?? [])
                );
                $heldItems = array_merge(
                    array_map(fn($r) => array_merge($r, ['_type' => 'regular']), $stuckBonuses['held_regular'] ?? []),
                    array_map(fn($r) => array_merge($r, ['_type' => 'weekly']), $stuckBonuses['held_weekly'] ?? [])
                );
                $scheduledUnpaidItems = array_merge(
                    array_map(fn($r) => array_merge($r, ['_type' => 'regular']), $stuckBonuses['scheduled_unpaid_regular'] ?? []),
                    array_map(fn($r) => array_merge($r, ['_type' => 'weekly']), $stuckBonuses['scheduled_unpaid_weekly'] ?? [])
                );
                ?>

                <?php if (!empty($deletedHeldItems)): ?>
                <!-- Subgroup 1A: Bonuses Linked to Deleted Payroll -->
                <div class="space-y-3 p-4 bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 rounded-2xl">
                    <div class="flex items-center justify-between">
                        <h4 class="text-xs font-bold uppercase tracking-wider text-rose-800 dark:text-rose-300 flex items-center gap-1.5">
                            <i data-lucide="trash-2" class="w-4 h-4 text-rose-600 dark:text-rose-400"></i>
                            <span>Bonuses Linked to Deleted Payroll (<?= count($deletedHeldItems) ?>)</span>
                        </h4>
                        <span class="text-[11px] font-medium text-rose-700 dark:text-rose-400">Payroll drafts were discarded or deleted</span>
                    </div>
                    <p class="text-[11px] text-rose-700 dark:text-rose-400">
                        These bonus records are held by payroll drafts that no longer exist in the system. You can release their hold to return them to the active eligible pool, or cancel them.
                    </p>
                    <div class="border border-rose-200 dark:border-rose-800/60 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-rose-50/50 dark:bg-rose-950/40 border-b border-rose-100 dark:border-rose-900/60 text-slate-600 dark:text-slate-400 font-bold text-[11px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Scheme / Type</th>
                                    <th class="py-2.5 px-3 text-right">Amount</th>
                                    <th class="py-2.5 px-3">Deleted Payroll ID</th>
                                    <th class="py-2.5 px-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                <?php foreach ($deletedHeldItems as $dhi): ?>
                                    <tr class="hover:bg-rose-50/30 dark:hover:bg-rose-950/20">
                                        <td class="py-2.5 px-3">
                                            <div class="font-bold text-slate-900 dark:text-white"><?= esc($dhi['employee_full_name'] ?? $dhi['employee_code'] ?? $dhi['employee_id']) ?></div>
                                            <div class="text-[10px] text-slate-400 font-mono"><?= esc($dhi['employee_code'] ?? '') ?></div>
                                        </td>
                                        <td class="py-2.5 px-3">
                                            <span><?= esc($dhi['bonus_title'] ?? ($dhi['_type'] === 'weekly' ? 'Weekly Punctuality (' . ($dhi['week_start_date'] ?? '') . ')' : 'Bonus')) ?></span>
                                            <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"><?= esc(ucfirst($dhi['_type'])) ?></span>
                                        </td>
                                        <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                                            <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($dhi['amount'] ?? $dhi['bonus_amount'] ?? 0), 2) ?>
                                        </td>
                                        <td class="py-2.5 px-3 font-mono text-[11px]">
                                            <span class="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400 font-bold bg-rose-50 dark:bg-rose-950/50 px-1.5 py-0.5 rounded border border-rose-200 dark:border-rose-900/60">
                                                Deleted: <?= esc(substr((string)($dhi['payroll_id'] ?? ''), 0, 8)) ?>...
                                            </span>
                                        </td>
                                        <td class="py-2.5 px-3 text-right space-x-1">
                                            <button 
                                                type="button" 
                                                @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($dhi, $dhi['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($dhi['_type']) ?>', 'release_hold')" 
                                                class="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400 font-bold text-[11px] transition cursor-pointer"
                                                title="Release hold and return bonus to eligible pool"
                                            >
                                                Release Hold
                                            </button>
                                            <button 
                                                type="button" 
                                                @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($dhi, $dhi['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($dhi['_type']) ?>', 'cancel')" 
                                                class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 font-bold text-[11px] transition cursor-pointer"
                                                title="Cancel and reject this bonus record"
                                            >
                                                Cancel
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Subgroup 1B: Active Draft-Held Bonuses -->
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <h4 class="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                            <i data-lucide="lock" class="w-4 h-4 text-amber-500"></i>
                            <span>Active Draft-Held Bonuses (<?= count($heldItems) ?>)</span>
                        </h4>
                        <a href="<?= base_url('payroll') ?>" class="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 flex items-center gap-1">
                            <span>Manage in Payroll Processing &rarr;</span>
                        </a>
                    </div>
                    <div class="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold text-[11px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Scheme / Type</th>
                                    <th class="py-2.5 px-3 text-right">Amount</th>
                                    <th class="py-2.5 px-3">Held by Batch</th>
                                    <th class="py-2.5 px-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                <?php if (empty($heldItems)): ?>
                                    <tr>
                                        <td colspan="5" class="py-4 px-3 text-center text-slate-400 italic">No bonus records currently held by active draft payrolls.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($heldItems as $hi): ?>
                                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                                            <td class="py-2.5 px-3">
                                                <div class="font-bold text-slate-900 dark:text-white"><?= esc($hi['employee_full_name'] ?? $hi['employee_code'] ?? $hi['employee_id']) ?></div>
                                                <div class="text-[10px] text-slate-400 font-mono"><?= esc($hi['employee_code'] ?? '') ?></div>
                                            </td>
                                            <td class="py-2.5 px-3">
                                                <span><?= esc($hi['bonus_title'] ?? ($hi['_type'] === 'weekly' ? 'Weekly Punctuality (' . ($hi['week_start_date'] ?? '') . ')' : 'Bonus')) ?></span>
                                                <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"><?= esc(ucfirst($hi['_type'])) ?></span>
                                            </td>
                                            <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                                                <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($hi['amount'] ?? $hi['bonus_amount'] ?? 0), 2) ?>
                                            </td>
                                            <td class="py-2.5 px-3 font-mono text-[11px] text-amber-700 dark:text-amber-400">
                                                <?= esc($hi['holding_batch_month'] ?? 'Draft') ?> (<?= esc(substr((string)($hi['payroll_id'] ?? ''), 0, 8)) ?>...)
                                             </td>
                                            <td class="py-2.5 px-3 text-right space-x-1">
                                                <button 
                                                    type="button" 
                                                    @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($hi, $hi['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($hi['_type']) ?>', 'release_hold')" 
                                                    class="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400 font-bold text-[11px] transition cursor-pointer"
                                                    title="Release draft hold and update draft payslip"
                                                >
                                                    Release Hold
                                                </button>
                                                <button 
                                                    type="button" 
                                                    @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($hi, $hi['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($hi['_type']) ?>', 'cancel')" 
                                                    class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 font-bold text-[11px] transition cursor-pointer"
                                                    title="Cancel and reject this bonus record"
                                                >
                                                    Cancel
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Group 2: Expired / Stale Bonuses (> 12 Months) -->
                <div class="space-y-3">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <i data-lucide="clock" class="w-4 h-4 text-rose-500"></i>
                        <span>Expired Beyond 12-Month Window (<?= esc($stuckBonuses['expired_count'] ?? 0) ?>)</span>
                    </h4>
                    <div class="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold text-[11px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Scheme / Original Period</th>
                                    <th class="py-2.5 px-3 text-right">Amount</th>
                                    <th class="py-2.5 px-3">Cutoff</th>
                                    <th class="py-2.5 px-3 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                <?php 
                                $expiredItems = array_merge(
                                    array_map(fn($r) => array_merge($r, ['_type' => 'regular']), $stuckBonuses['regular'] ?? []),
                                    array_map(fn($r) => array_merge($r, ['_type' => 'weekly']), $stuckBonuses['weekly'] ?? [])
                                );
                                ?>
                                <?php if (empty($expiredItems)): ?>
                                    <tr>
                                        <td colspan="5" class="py-4 px-3 text-center text-slate-400 italic">No approved bonus records older than the 12-month carry-forward window.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($expiredItems as $ei): ?>
                                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                                            <td class="py-2.5 px-3">
                                                <div class="font-bold text-slate-900 dark:text-white"><?= esc($ei['employee_full_name'] ?? $ei['employee_code'] ?? $ei['employee_id']) ?></div>
                                                <div class="text-[10px] text-slate-400 font-mono"><?= esc($ei['employee_code'] ?? '') ?></div>
                                            </td>
                                            <td class="py-2.5 px-3">
                                                <span><?= esc($ei['bonus_title'] ?? ($ei['_type'] === 'weekly' ? 'Weekly Punctuality' : 'Bonus')) ?></span>
                                                <span class="text-[11px] text-slate-400 block"><?= esc($ei['_type'] === 'weekly' ? ($ei['week_start_date'] ?? '') : (($ei['bonus_month'] ?? '') . ' ' . ($ei['year'] ?? ''))) ?></span>
                                            </td>
                                            <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                                                <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($ei['amount'] ?? $ei['bonus_amount'] ?? 0), 2) ?>
                                            </td>
                                            <td class="py-2.5 px-3 text-[11px] text-slate-500 font-mono">
                                                Prior to <?= esc($stuckBonuses['cutoff_date'] ?? '') ?>
                                            </td>
                                            <td class="py-2.5 px-3 text-right space-x-1">
                                                <?php if (empty($ei['payout_month'])): ?>
                                                    <button 
                                                        type="button" 
                                                        @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($ei, $ei['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($ei['_type']) ?>', 'sweep')" 
                                                        class="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 font-bold text-[11px] transition cursor-pointer"
                                                        title="Schedule for payout in upcoming payroll (dual-control maker-checker)"
                                                    >
                                                        Sweep to Period
                                                    </button>
                                                    <button 
                                                        type="button" 
                                                        @click="openResolveAction(<?= htmlspecialchars(json_encode($slimStuckRecord($ei, $ei['_type'])), ENT_QUOTES, 'UTF-8') ?>, '<?= esc($ei['_type']) ?>', 'cancel')" 
                                                        class="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 font-bold text-[11px] transition cursor-pointer"
                                                        title="Cancel and reject this expired record"
                                                    >
                                                        Cancel
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium font-mono">Scheduled: <?= esc($ei['payout_month']) ?> (Auto-paid in next payroll)</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php if (!empty($scheduledUnpaidItems)): ?>
                <!-- Group 3: Scheduled but Unpaid in Locked Payrolls (Read-only Table) -->
                <div class="space-y-3 p-4 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/60 rounded-2xl">
                    <div class="flex items-center justify-between">
                        <h4 class="text-xs font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                            <i data-lucide="calendar-x" class="w-4 h-4 text-amber-600 dark:text-amber-400"></i>
                            <span>Scheduled Unpaid in Locked Payrolls (<?= count($scheduledUnpaidItems) ?>)</span>
                        </h4>
                        <span class="text-[11px] font-medium text-amber-700 dark:text-amber-400 font-mono">
                            Latest Locked: <?= esc($stuckBonuses['latest_locked_month'] ?? 'None') ?>
                        </span>
                    </div>
                    <p class="text-[11px] text-amber-700 dark:text-amber-400">
                        These approved bonus records were scheduled for payout in a month whose payroll batch has already been locked, but they remain unsettled or unpaid.
                    </p>
                    <div class="border border-amber-200 dark:border-amber-800/60 rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-amber-50/50 dark:bg-amber-950/40 border-b border-amber-100 dark:border-amber-900/60 text-slate-600 dark:text-slate-400 font-bold text-[11px]">
                                <tr>
                                    <th class="py-2.5 px-3">Employee</th>
                                    <th class="py-2.5 px-3">Scheme / Type</th>
                                    <th class="py-2.5 px-3 text-right">Amount</th>
                                    <th class="py-2.5 px-3">Scheduled Month</th>
                                    <th class="py-2.5 px-3 text-right">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                <?php foreach ($scheduledUnpaidItems as $sui): ?>
                                    <tr class="hover:bg-amber-50/30 dark:hover:bg-amber-950/20">
                                        <td class="py-2.5 px-3">
                                            <div class="font-bold text-slate-900 dark:text-white"><?= esc($sui['employee_full_name'] ?? $sui['employee_code'] ?? $sui['employee_id']) ?></div>
                                            <div class="text-[10px] text-slate-400 font-mono"><?= esc($sui['employee_code'] ?? '') ?></div>
                                        </td>
                                        <td class="py-2.5 px-3">
                                            <span><?= esc($sui['bonus_title'] ?? ($sui['_type'] === 'weekly' ? 'Weekly Bonus' : 'Bonus')) ?></span>
                                            <span class="ml-1 text-[10px] px-1.5 py-0.5 rounded-full font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"><?= esc(ucfirst($sui['_type'])) ?></span>
                                        </td>
                                        <td class="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                                            <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format((float)($sui['amount'] ?? $sui['bonus_amount'] ?? 0), 2) ?>
                                        </td>
                                        <td class="py-2.5 px-3 font-mono text-[11px] text-amber-700 dark:text-amber-400 font-bold">
                                            <?= esc($sui['payout_month'] ?? '') ?>
                                        </td>
                                        <td class="py-2.5 px-3 text-right">
                                            <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300">
                                                <?= esc($sui['status'] ?? 'Approved') ?> (Unpaid)
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-800 shrink-0">
                <span class="text-xs text-slate-400">Total Stuck/Held Records: <strong><?= esc($stuckBonuses['total_count'] ?? 0) ?></strong></span>
                <button type="button" @click="showStuckModal = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Close</button>
            </div>
        </div>
    </div>

    <!-- SUB-MODAL: Action Confirmation (Release Hold / Sweep / Cancel) -->
    <div x-show="stuckResolveSubModal" x-cloak class="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-60 flex items-center justify-center p-4" @click.self="stuckResolveSubModal = false">
        <div class="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4" @click.stop>
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                    <template x-if="stuckResolveRecord.action === 'release_hold'">
                        <span class="flex items-center gap-1.5 text-indigo-600">
                            <i data-lucide="unlock" class="w-5 h-5"></i>
                            <span>Release Draft Linkage Hold</span>
                        </span>
                    </template>
                    <template x-if="stuckResolveRecord.action === 'sweep'">
                        <span class="flex items-center gap-1.5 text-emerald-600">
                            <i data-lucide="calendar" class="w-5 h-5"></i>
                            <span>Schedule Sweep to Upcoming Period</span>
                        </span>
                    </template>
                    <template x-if="stuckResolveRecord.action === 'cancel'">
                        <span class="flex items-center gap-1.5 text-rose-600">
                            <i data-lucide="x-circle" class="w-5 h-5"></i>
                            <span>Cancel Bonus Allocation</span>
                        </span>
                    </template>
                </h3>
                <button type="button" @click="stuckResolveSubModal = false" class="text-slate-400 hover:text-slate-600 cursor-pointer">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>

            <form method="POST" action="<?= base_url('payroll/bonuses/resolve-stuck') ?>" class="space-y-4">
                <?= csrf_field() ?>
                <input type="hidden" name="id" :value="stuckResolveRecord.id">
                <input type="hidden" name="type" :value="stuckResolveRecord.type">
                <input type="hidden" name="action" :value="stuckResolveRecord.action">

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Target Record</label>
                    <div class="text-xs font-semibold text-slate-900 dark:text-white px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex justify-between items-center">
                        <span x-text="stuckResolveRecord.employee_name + ' — ' + stuckResolveRecord.bonus_title"></span>
                        <span class="font-mono font-bold" x-text="'<?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?>' + stuckResolveRecord.amount.toFixed(2)"></span>
                    </div>
                </div>

                <template x-if="stuckResolveRecord.action === 'sweep'">
                    <div class="space-y-2">
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300">Target Payout Month (YYYY-MM) <span class="text-rose-500">*</span></label>
                        <input type="text" name="target_month" required pattern="^\d{4}-(0[1-9]|1[0-2])$" x-model="stuckResolveRecord.target_month" placeholder="YYYY-MM (e.g. <?= date('Y-m') ?>)" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <p class="text-[11px] text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded-xl border border-amber-200/60">
                            <strong>Dual-Control Maker-Checker:</strong> Scheduling a sweep resets this record to Pending status for the target payout month. A second authorized officer must review and approve it before payroll generation will pick it up.
                        </p>
                    </div>
                </template>

                <template x-if="stuckResolveRecord.action === 'release_hold'">
                    <p class="text-[11px] text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 p-2.5 rounded-xl border border-indigo-200/60">
                        <strong>Draft Synchronization:</strong> Releasing the hold will immediately synchronize the linked draft payslip (deducting this amount and recalculating tax/net) and restore this bonus to the pool.
                    </p>
                </template>

                <div>
                    <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Mandatory Audited Reason <span class="text-rose-500">*</span></label>
                    <textarea name="reason" rows="3" required x-model="stuckResolveRecord.reason" placeholder="State specific business justification for this audit log..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                </div>

                <div class="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                    <button type="button" @click="stuckResolveSubModal = false" class="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">Back</button>
                    <button type="submit" class="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 shadow-sm cursor-pointer" x-text="stuckResolveRecord.action === 'release_hold' ? 'Confirm Release' : (stuckResolveRecord.action === 'sweep' ? 'Schedule Sweep' : 'Confirm Cancel')"></button>
                </div>
            </form>
        </div>
    </div>

</div>
