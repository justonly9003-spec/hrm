<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <script>
        (function() {
            const origWarn = console.warn;
            console.warn = function(...args) {
                if (typeof args[0] === 'string' && args[0].includes('cdn.tailwindcss.com should not be used in production')) {
                    return;
                }
                origWarn.apply(console, args);
            };
        })();
    </script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @media print {
            @page {
                size: A4 portrait;
                margin: 0 !important;
            }
            html, body {
                background: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            .no-print { display: none !important; }
            .payslip-sheet {
                box-shadow: none !important;
                border: none !important;
                padding: 10mm 12mm !important;
                max-width: 210mm !important;
                width: 100% !important;
                margin: 0 auto !important;
            }
            .payslip-sheet,
            .payslip-sheet > *,
            .report-header-component,
            .report-footer-component {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
            }
        }
    </style>
</head>
<body class="bg-slate-900 min-h-screen p-6 flex flex-col items-center justify-center text-slate-800">
    <!-- Action Bar -->
    <div class="no-print max-w-3xl w-full flex items-center justify-between mb-4">
        <a href="javascript:history.back()" class="text-sm font-medium text-slate-300 hover:text-white flex items-center gap-1">
            &larr; Back to Payroll Run
        </a>
        <div class="flex items-center gap-2">
            <button onclick="downloadPayslipPdf()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                <span>Download PDF</span>
            </button>
            <button onclick="printPayslipPdf()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                <span>Print Payslip</span>
            </button>
        </div>
    </div>

    <!-- Official Payslip Sheet -->
    <div class="payslip-sheet max-w-3xl w-full bg-white p-10 rounded-2xl shadow-2xl border border-slate-200">
        <!-- Official Dynamic Report Header Partial -->
        <?= view('reports/partials/report_header', [
            'company'            => $company,
            'reportTitle'        => 'EMPLOYEE MONTHLY SALARY PAYSLIP',
            'reportPeriod'       => 'Salary Month: ' . esc($item['payroll_month'] ?? date('F Y')),
            'reportHeaderImage'  => $company['report_header_image'] ?? null,
            'reportHeaderLayout' => $company['report_header_layout'] ?? 'center',
            'reportHeaderText'   => $company['report_header_text'] ?? null,
        ]) ?>

        <!-- Employee Info Bar -->
        <div class="grid grid-cols-2 gap-6 bg-slate-50 p-4 rounded-xl my-6 border border-slate-200/80 text-xs">
            <div class="space-y-1.5">
                <div class="flex justify-between">
                    <span class="text-slate-500">Employee Name:</span>
                    <strong class="text-slate-900 font-semibold"><?= esc($item['first_name'] . ' ' . $item['last_name']) ?></strong>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-500">Employee Code:</span>
                    <strong class="text-slate-900 font-mono"><?= esc($item['employee_code']) ?></strong>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-500">Department:</span>
                    <strong class="text-slate-900"><?= esc($item['department_name'] ?? 'Engineering') ?></strong>
                </div>
            </div>
            <div class="space-y-1.5">
                <div class="flex justify-between">
                    <span class="text-slate-500">Designation:</span>
                    <strong class="text-slate-900"><?= esc($item['designation_name'] ?? 'Senior Specialist') ?></strong>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-500">Bank Account:</span>
                    <strong class="text-slate-900 font-mono"><?= esc($item['bank_account_no'] ?? '••••••••4819') ?></strong>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-500">Disbursal Date:</span>
                    <strong class="text-slate-900"><?= date('F d, Y') ?></strong>
                </div>
            </div>
        </div>

        <?php
            $dynamicBreakdown = null;
            if (!empty($item['components_breakdown_json'])) {
                $dynamicBreakdown = is_array($item['components_breakdown_json']) 
                    ? $item['components_breakdown_json'] 
                    : json_decode($item['components_breakdown_json'], true);
            }
            $dynEarnings = $dynamicBreakdown['earnings'] ?? null;
            $dynDeductions = $dynamicBreakdown['deductions'] ?? null;
        ?>

        <!-- Earnings & Deductions Breakdown -->
        <div class="grid grid-cols-2 gap-8 mb-8">
            <!-- Earnings -->
            <div>
                <h3 class="text-xs uppercase font-bold tracking-wider text-emerald-700 pb-2 border-b border-emerald-200 flex items-center justify-between">
                    <span>Earnings & Allowances</span>
                    <span>Amount ($)</span>
                </h3>
                <div class="divide-y divide-slate-100 text-xs py-2">
                    <?php if (!empty($dynEarnings) && is_array($dynEarnings)): ?>
                        <?php foreach ($dynEarnings as $e): ?>
                            <?php if ((float)($e['amount'] ?? 0) > 0): ?>
                                <div class="py-2 flex justify-between">
                                    <span class="text-slate-600"><?= esc($e['name'] ?? $e['code'] ?? 'Earning') ?></span>
                                    <span class="font-semibold text-slate-900">$<?= number_format((float)$e['amount'], 2) ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if ((float)($item['overtime_amount'] ?? 0) > 0 && !array_filter($dynEarnings, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['OT', 'OVERTIME', 'OVER_TIME'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Overtime Premium Pay</span><span class="font-semibold text-slate-900">$<?= number_format((float)$item['overtime_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($item['bonus_amount'] ?? 0) > 0 && !array_filter($dynEarnings, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['BONUS', 'BONUS_PAY'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Performance Bonus</span><span class="font-semibold text-slate-900">$<?= number_format((float)$item['bonus_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($item['arrear_amount'] ?? 0) > 0 && !array_filter($dynEarnings, fn($e) => in_array(strtoupper($e['code'] ?? ''), ['ARREAR', 'ARREARS'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Arrears & Adjustments</span><span class="font-semibold text-slate-900">$<?= number_format((float)$item['arrear_amount'], 2) ?></span></div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if ((float)($item['basic_salary'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Basic Base Salary</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['basic_salary'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($item['house_rent']) || !empty($item['medical']) || !empty($item['conveyance']) || !empty($item['other_allowances'])): ?>
                            <?php if ((float)($item['house_rent'] ?? 0) > 0): ?>
                            <div class="py-2 flex justify-between">
                                <span class="text-slate-600">Housing Allowance (HRA)</span>
                                <span class="font-semibold text-slate-900">$<?= number_format((float)$item['house_rent'], 2) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ((float)($item['medical'] ?? 0) > 0): ?>
                            <div class="py-2 flex justify-between">
                                <span class="text-slate-600">Medical Allowance</span>
                                <span class="font-semibold text-slate-900">$<?= number_format((float)$item['medical'], 2) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ((float)($item['conveyance'] ?? 0) > 0): ?>
                            <div class="py-2 flex justify-between">
                                <span class="text-slate-600">Conveyance / Transport</span>
                                <span class="font-semibold text-slate-900">$<?= number_format((float)$item['conveyance'], 2) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ((float)($item['other_allowances'] ?? 0) > 0): ?>
                            <div class="py-2 flex justify-between">
                                <span class="text-slate-600">Other Allowances & Special Pay</span>
                                <span class="font-semibold text-slate-900">$<?= number_format((float)$item['other_allowances'], 2) ?></span>
                            </div>
                            <?php endif; ?>
                        <?php elseif ((float)($item['allowances'] ?? 0) > 0): ?>
                            <div class="py-2 flex justify-between">
                                <span class="text-slate-600">Allowances & Assigned Components</span>
                                <span class="font-semibold text-slate-900">$<?= number_format((float)($item['allowances'] ?? 0), 2) ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ((float)($item['overtime_amount'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Overtime Premium Pay</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['overtime_amount'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['bonus_amount'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Performance Bonus</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['bonus_amount'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['arrear_amount'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Arrears & Adjustments</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['arrear_amount'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="pt-2 border-t border-slate-200 flex justify-between text-xs font-bold text-slate-900">
                    <span>Total Gross Earnings</span>
                    <span class="text-emerald-700">$<?= number_format((float)($item['gross_salary'] ?? 0), 2) ?></span>
                </div>
            </div>

            <!-- Deductions -->
            <div>
                <h3 class="text-xs uppercase font-bold tracking-wider text-rose-700 pb-2 border-b border-rose-200 flex items-center justify-between">
                    <span>Statutory & Structure Deductions</span>
                    <span>Amount ($)</span>
                </h3>
                <div class="divide-y divide-slate-100 text-xs py-2">
                    <?php if (!empty($dynDeductions) && is_array($dynDeductions)): ?>
                        <?php foreach ($dynDeductions as $d): ?>
                            <?php if ((float)($d['amount'] ?? 0) > 0): ?>
                                <div class="py-2 flex justify-between">
                                    <span class="text-slate-600"><?= esc($d['name'] ?? $d['code'] ?? 'Deduction') ?></span>
                                    <span class="font-semibold text-slate-900">$<?= number_format((float)$d['amount'], 2) ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if (((float)($item['loan_emi'] ?? 0) + (float)($item['loan_deduction'] ?? 0)) > 0 && !array_filter($dynDeductions, fn($d) => in_array(strtoupper($d['code'] ?? ''), ['LOAN', 'LOAN_EMI'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Loan EMI Repayment</span><span class="font-semibold text-slate-900">$<?= number_format((float)(($item['loan_emi'] ?? 0) ?: ($item['loan_deduction'] ?? 0)), 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($item['advance_recovery'] ?? 0) > 0 && !array_filter($dynDeductions, fn($d) => in_array(strtoupper($d['code'] ?? ''), ['ADV', 'ADVANCE', 'ADVANCE_RECOVERY'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Advance Salary Recovery</span><span class="font-semibold text-slate-900">$<?= number_format((float)($item['advance_recovery'] ?? 0), 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($item['asset_recovery'] ?? 0) > 0 && !array_filter($dynDeductions, fn($d) => in_array(strtoupper($d['code'] ?? ''), ['ASSET', 'ASSET_RECOVERY'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Asset recovery</span><span class="font-semibold text-slate-900">$<?= number_format((float)($item['asset_recovery'] ?? 0), 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($item['unpaid_leave_deduction'] ?? 0) > 0 && !array_filter($dynDeductions, fn($d) => in_array(strtoupper($d['code'] ?? ''), ['LOP', 'UNPAID_LEAVE'], true))): ?>
                            <div class="py-2 flex justify-between"><span class="text-slate-600">Unpaid Leave (LOP)</span><span class="font-semibold text-slate-900">$<?= number_format((float)($item['unpaid_leave_deduction'] ?? 0), 2) ?></span></div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if ((float)($item['tax_deduction'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Income Tax (PAYE / TDS)</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['tax_deduction'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['pf_deduction'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Provident Fund / Pension (PF)</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['pf_deduction'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (((float)($item['loan_emi'] ?? 0) + (float)($item['loan_deduction'] ?? 0)) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Loan EMI Repayment</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)(($item['loan_emi'] ?? 0) ?: ($item['loan_deduction'] ?? 0)), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['advance_recovery'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Advance Salary Recovery</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['advance_recovery'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['asset_recovery'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Asset recovery</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['asset_recovery'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['unpaid_leave_deduction'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Unpaid Leave (LOP)</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['unpaid_leave_deduction'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['other_deductions'] ?? 0) > 0): ?>
                        <div class="py-2 flex justify-between">
                            <span class="text-slate-600">Other Deductions</span>
                            <span class="font-semibold text-slate-900">$<?= number_format((float)($item['other_deductions'] ?? 0), 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ((float)($item['total_deductions'] ?? $item['deductions'] ?? 0) == 0): ?>
                        <div class="py-2 flex justify-between text-slate-400 italic">
                            <span>No Deductions Applicable</span>
                            <span>$0.00</span>
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="pt-2 border-t border-slate-200 flex justify-between text-xs font-bold text-slate-900">
                    <span>Total Deductions</span>
                    <span class="text-rose-700">$<?= number_format((float)($item['total_deductions'] ?? $item['deductions'] ?? 0), 2) ?></span>
                </div>
            </div>
        </div>

        <?php
            $uTax = (float)($item['unapplied_tax'] ?? 0.0);
            $uPf  = (float)($item['unapplied_pf'] ?? 0.0);
            $uLop = (float)($item['unapplied_lop'] ?? 0.0);
            $hasUnapplied = ($uTax > 0 || $uPf > 0 || $uLop > 0);
            $unappliedParts = [];
            if ($uTax > 0) {
                $unappliedParts[] = number_format($uTax, 2) . ' Tax';
            }
            if ($uPf > 0) {
                $unappliedParts[] = number_format($uPf, 2) . ' PF';
            }
            if ($uLop > 0) {
                $unappliedParts[] = number_format($uLop, 2) . ' LOP';
            }
            $unappliedMsg = implode(', ', $unappliedParts);
        ?>
        <?php if ($hasUnapplied): ?>
        <div class="my-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2.5">
            <span class="text-sm">⚠️</span>
            <div>
                <strong class="text-amber-800">Statutory Deduction Ceiling Notice:</strong>
                <span>Deductions capped at 50% statutory threshold. Unapplied amount this month: <?= esc($unappliedMsg) ?></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Net Payable Amount & QR Verification -->
        <div class="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-5 rounded-xl flex items-center justify-between mb-8 shadow-inner">
            <div>
                <span class="text-xs uppercase tracking-widest text-indigo-300 font-bold">Net Take-Home Salary</span>
                <p class="text-xs text-indigo-200 mt-0.5">Disbursed directly via Corporate Direct Deposit / ACH</p>
                <div class="text-3xl font-black font-mono text-emerald-400 mt-1">
                    $<?= number_format((float)($item['net_salary'] ?? 0), 2) ?>
                </div>
            </div>

            <!-- QR Verification Box -->
            <div class="flex items-center gap-3 bg-white/10 p-2.5 rounded-xl backdrop-blur-xs border border-white/10">
                <div class="w-12 h-12 bg-white rounded-lg p-1 flex items-center justify-center shrink-0">
                    <svg class="w-10 h-10 text-slate-900" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect width="5" height="5" x="3" y="3" rx="1"/>
                        <rect width="5" height="5" x="16" y="3" rx="1"/>
                        <rect width="5" height="5" x="3" y="16" rx="1"/>
                        <path d="M21 16h-3a2 2 0 0 0-2 2v3"/>
                        <path d="M21 21v.01"/>
                        <path d="M12 7v3a2 2 0 0 1-2 2H7"/>
                        <path d="M3 12h.01"/>
                        <path d="M12 3h.01"/>
                        <path d="M12 16v.01"/>
                        <path d="M16 12h1"/>
                        <path d="M21 12v.01"/>
                        <path d="M12 21v-1"/>
                    </svg>
                </div>
                <div class="text-[10px] font-mono text-slate-300">
                    <div class="font-bold text-white">QR Verification</div>
                    <div><?= esc($item['id'] ?? 'PAY-2026-07') ?></div>
                    <div class="text-slate-400">Authentic Payroll Voucher</div>
                </div>
            </div>
        </div>

        <!-- Signatures -->
        <div class="grid grid-cols-3 gap-6 pt-6 border-t border-slate-200 text-center text-xs text-slate-500">
            <div class="space-y-1">
                <div class="h-10 border-b border-dashed border-slate-300"></div>
                <div class="text-[10px] font-bold text-slate-700 uppercase">Employee Signature</div>
                <div class="text-[9px] text-slate-400">Acknowledged & Received</div>
            </div>
            <div class="space-y-1">
                <div class="h-10 border-b border-dashed border-slate-300"></div>
                <div class="text-[10px] font-bold text-slate-700 uppercase">Head of HR</div>
                <div class="text-[9px] text-slate-400">Verified & Approved</div>
            </div>
            <div class="space-y-1">
                <div class="h-10 border-b border-dashed border-slate-300"></div>
                <div class="text-[10px] font-bold text-slate-700 uppercase">Finance Controller</div>
                <div class="text-[9px] text-slate-400">Disbursed & Reconciled</div>
            </div>
        </div>

        <!-- Complete Official Company Footer Partial -->
        <?= view('reports/partials/report_footer', [
            'company'            => $company,
            'reportFooterImage'  => $company['report_footer_image'] ?? null,
            'reportFooterText'   => $company['report_footer_text'] ?? 'This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.',
            'reportFooterLayout' => $company['report_footer_layout'] ?? 'center',
            'generatedDate'      => date('Y-m-d H:i:s'),
            'pageNumberText'     => 'Page 1 of 1'
        ]) ?>
    </div>

    <!-- Client-side PDF Generation Engine -->
    <script src="https://cdn.jsdelivr.net/npm/html2canvas-pro@1.5.8/dist/html2canvas-pro.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        async function printPayslipPdf() {
            const element = document.querySelector('.payslip-sheet');
            if (!element) {
                window.print();
                return;
            }

            try {
                if (window.html2canvas && (window.jspdf || window.jsPDF)) {
                    const canvas = await window.html2canvas(element, {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        backgroundColor: '#ffffff',
                        windowWidth: 794,
                        onclone: (clonedDoc) => {
                            const clonedElement = clonedDoc.querySelector('.payslip-sheet');
                            if (clonedElement) {
                                const hiddenEls = clonedElement.querySelectorAll('[style*="display: none"], [style*="display:none"]');
                                hiddenEls.forEach(el => el.remove());

                                clonedElement.style.padding = '24px 28px';
                                clonedElement.style.maxWidth = '794px';
                                clonedElement.style.width = '794px';
                                clonedElement.style.boxSizing = 'border-box';
                                clonedElement.style.backgroundColor = '#ffffff';
                                clonedElement.style.height = 'auto';
                                clonedElement.style.minHeight = 'auto';
                                clonedElement.style.position = 'static';
                                clonedElement.style.margin = '0 auto';
                            }
                        }
                    });
                    const imgData = canvas.toDataURL('image/jpeg', 0.98);
                    const { jsPDF } = window.jspdf || window;
                    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    const pdfWidth = 210;
                    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);

                    const pdfBlob = pdf.output('blob');
                    const blobUrl = URL.createObjectURL(pdfBlob);
                    const printTab = window.open(blobUrl, '_blank');
                    if (printTab) {
                        printTab.focus();
                    } else {
                        const printIframe = document.createElement('iframe');
                        printIframe.style.position = 'fixed';
                        printIframe.style.right = '0';
                        printIframe.style.bottom = '0';
                        printIframe.style.width = '0';
                        printIframe.style.height = '0';
                        printIframe.style.border = '0';
                        printIframe.src = blobUrl;
                        document.body.appendChild(printIframe);
                        printIframe.onload = () => {
                            setTimeout(() => {
                                printIframe.contentWindow.focus();
                                printIframe.contentWindow.print();
                            }, 500);
                        };
                    }
                } else {
                    window.print();
                }
            } catch (err) {
                console.error('Print Generation error:', err);
                window.print();
            }
        }

        async function downloadPayslipPdf() {
            const element = document.querySelector('.payslip-sheet');
            if (!element) return;
            const code = '<?= esc($item['employee_code'] ?? 'EMP') ?>';
            const month = '<?= esc($item['payroll_month'] ?? date('F-Y')) ?>';
            const filename = `Payslip-${code}-${month}.pdf`;

            try {
                if (window.html2canvas && (window.jspdf || window.jsPDF)) {
                    const canvas = await window.html2canvas(element, {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        backgroundColor: '#ffffff',
                        windowWidth: 794,
                        onclone: (clonedDoc) => {
                            const clonedElement = clonedDoc.querySelector('.payslip-sheet');
                            if (clonedElement) {
                                const hiddenEls = clonedElement.querySelectorAll('[style*="display: none"], [style*="display:none"]');
                                hiddenEls.forEach(el => el.remove());

                                clonedElement.style.padding = '24px 28px';
                                clonedElement.style.maxWidth = '794px';
                                clonedElement.style.width = '794px';
                                clonedElement.style.boxSizing = 'border-box';
                                clonedElement.style.backgroundColor = '#ffffff';
                                clonedElement.style.height = 'auto';
                                clonedElement.style.minHeight = 'auto';
                                clonedElement.style.position = 'static';
                                clonedElement.style.margin = '0 auto';
                            }
                        }
                    });
                    const imgData = canvas.toDataURL('image/jpeg', 0.98);
                    const { jsPDF } = window.jspdf || window;
                    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    const pdfWidth = 210;
                    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                    pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
                    pdf.save(filename);
                } else {
                    window.print();
                }
            } catch (err) {
                console.error('PDF Generation error:', err);
                window.print();
            }
        }
    </script>
</body>
</html>
