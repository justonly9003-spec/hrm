<!-- ============================================== -->
<!-- MODAL: INTERACTIVE LOAN AMORTIZATION SCHEDULE  -->
<!-- ============================================== -->
<div 
    x-show="loanScheduleModalOpen" 
    x-cloak
    class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4"
    style="display: none;"
>
    <div 
        @click.outside="loanScheduleModalOpen = false"
        class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-150 relative"
    >
        <!-- Header -->
        <div class="p-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white flex justify-between items-start">
            <div class="space-y-1">
                <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold tracking-wider uppercase">
                        Loan Amortization Engine
                    </span>
                    <span 
                        class="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase"
                        :class="currentLoanScheduleData?.loan?.status === 'Settled' ? 'bg-emerald-400 text-emerald-950' : 'bg-amber-300 text-amber-950'"
                        x-text="currentLoanScheduleData?.loan?.status || 'Active'"
                    ></span>
                </div>
                <h2 class="text-xl font-bold tracking-tight" x-text="(currentLoanScheduleData?.loan?.employee_name ? (currentLoanScheduleData?.loan?.employee_name + '\'s Loan Account') : 'Loan ID: ' + (currentLoanScheduleData?.loan?.id || ''))"></h2>
                <p class="text-emerald-100 text-xs">
                    Automated reducing-balance EMI schedule with continuous monthly payroll deduction synchronization
                </p>
            </div>
            <button 
                type="button" 
                @click="loanScheduleModalOpen = false"
                class="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            >
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>

        <!-- Subtab Switcher -->
        <div class="px-6 pt-4 border-b border-slate-200 dark:border-slate-800 flex gap-4 bg-slate-50 dark:bg-slate-900/50">
            <button
                type="button"
                @click="loanModalSubTab = 'schedule'"
                class="pb-3 text-xs font-bold border-b-2 flex items-center gap-2 transition cursor-pointer"
                :class="loanModalSubTab === 'schedule' ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400' : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'"
            >
                <i data-lucide="calendar" class="w-4 h-4"></i>
                <span>Amortization Schedule (<span x-text="(currentLoanScheduleData?.paidCount || 0) + '/' + (currentLoanScheduleData?.schedule?.length || 0)"></span> Paid)</span>
            </button>
            <button
                type="button"
                @click="loanModalSubTab = 'calculator'"
                class="pb-3 text-xs font-bold border-b-2 flex items-center gap-2 transition cursor-pointer"
                :class="loanModalSubTab === 'calculator' ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400' : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'"
            >
                <i data-lucide="calculator" class="w-4 h-4"></i>
                <span>Interactive EMI Calculator</span>
            </button>
        </div>

        <!-- Modal Content Scrollable -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1">
            
            <!-- SUBTAB 1: AMORTIZATION SCHEDULE -->
            <div x-show="loanModalSubTab === 'schedule'" class="space-y-5">
                
                <!-- Stat Cards -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div class="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Loan Value</span>
                        <span class="text-lg font-bold text-slate-900 dark:text-white font-mono" x-text="'$' + Number(currentLoanScheduleData?.totalAmount || 0).toLocaleString()"></span>
                        <span class="text-[10px] text-slate-500 block mt-0.5 font-mono" x-text="'Principal: $' + Number(currentLoanScheduleData?.principal || 0).toLocaleString()"></span>
                    </div>

                    <div class="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Monthly Payroll EMI</span>
                        <span class="text-lg font-bold text-emerald-600 dark:text-emerald-400 font-mono" x-text="'$' + Number(currentLoanScheduleData?.emi || 0).toLocaleString()"></span>
                        <span class="text-[10px] text-slate-500 block mt-0.5">Deducted auto in batch</span>
                    </div>

                    <div class="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Repaid</span>
                        <span class="text-lg font-bold text-teal-600 dark:text-teal-400 font-mono" x-text="'$' + Number(currentLoanScheduleData?.totalPaid || 0).toLocaleString()"></span>
                        <span class="text-[10px] text-slate-500 block mt-0.5 font-mono" x-text="(currentLoanScheduleData?.paidCount || 0) + ' of ' + (currentLoanScheduleData?.schedule?.length || 0) + ' Paid'"></span>
                    </div>

                    <div class="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Outstanding Balance</span>
                        <span class="text-lg font-bold text-amber-600 dark:text-amber-400 font-mono" x-text="'$' + Number(currentLoanScheduleData?.remaining || 0).toLocaleString()"></span>
                        <span class="text-[10px] text-slate-500 block mt-0.5" x-text="((currentLoanScheduleData?.schedule?.length || 0) - (currentLoanScheduleData?.paidCount || 0)) + ' Installments left'"></span>
                    </div>
                </div>

                <!-- Repayment Progress Bar -->
                <div class="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
                    <div class="flex justify-between items-center text-xs">
                        <span class="font-bold text-slate-700 dark:text-slate-300">Loan Amortization Progress</span>
                        <span class="font-mono font-bold text-emerald-600 dark:text-emerald-400" x-text="(currentLoanScheduleData?.progressPct || 0) + '% Completed'"></span>
                    </div>
                    <div class="w-full bg-slate-200 dark:bg-slate-700 h-2.5 rounded-full overflow-hidden">
                        <div class="bg-gradient-to-r from-emerald-500 to-teal-500 h-2.5 rounded-full transition-all duration-500" :style="'width: ' + (currentLoanScheduleData?.progressPct || 0) + '%'"></div>
                    </div>
                </div>

                <!-- Schedule Table -->
                <div class="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-2xs">
                    <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                        <thead class="bg-slate-50 dark:bg-slate-800 font-bold text-[10px] uppercase text-slate-400 border-b border-slate-100 dark:border-slate-700">
                            <tr>
                                <th class="p-3">#</th>
                                <th class="p-3">Due Month</th>
                                <th class="p-3 text-right">EMI Amount</th>
                                <th class="p-3 text-right">Principal</th>
                                <th class="p-3 text-right">Interest</th>
                                <th class="p-3 text-right">Balance</th>
                                <th class="p-3 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                            <template x-for="item in (currentLoanScheduleData?.schedule || [])" :key="item.installmentNumber">
                                <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                                    <td class="p-3 font-bold text-slate-800 dark:text-slate-200" x-text="item.installmentNumber"></td>
                                    <td class="p-3 text-slate-700 dark:text-slate-300 font-sans" x-text="item.dueMonth"></td>
                                    <td class="p-3 text-right font-black text-slate-900 dark:text-white" x-text="'$' + Number(item.emi || 0).toLocaleString()"></td>
                                    <td class="p-3 text-right text-emerald-600" x-text="'$' + Number(item.principal || 0).toLocaleString()"></td>
                                    <td class="p-3 text-right text-slate-400" x-text="'$' + Number(item.interest || 0).toLocaleString()"></td>
                                    <td class="p-3 text-right font-bold text-amber-600" x-text="'$' + Number(item.balance || 0).toLocaleString()"></td>
                                    <td class="p-3 text-center font-sans">
                                        <span 
                                            class="px-2 py-0.5 rounded-full text-[10px] font-bold border inline-block"
                                            :class="item.status === 'Paid' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-200'"
                                            x-text="item.status"
                                        ></span>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>

            </div>

            <!-- SUBTAB 2: INTERACTIVE LOAN EMI CALCULATOR -->
            <div x-show="loanModalSubTab === 'calculator'" class="space-y-5">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <!-- Left: Inputs -->
                    <div class="space-y-4 text-xs">
                        <div>
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Principal Amount ($)</label>
                            <input type="number" x-model.number="loanSimPrincipal" @input="recalcLoanSimulation()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-sm">
                        </div>

                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Annual Interest Rate (%)</label>
                                <input type="number" step="0.5" x-model.number="loanSimRate" @input="recalcLoanSimulation()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold">
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tenure (Months)</label>
                                <input type="number" x-model.number="loanSimTenure" @input="recalcLoanSimulation()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold">
                            </div>
                        </div>

                        <div>
                            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Amortization Method</label>
                            <select x-model="loanSimMethod" @change="recalcLoanSimulation()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                                <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="reducing">Reducing Balance EMI (Standard Banking)</option>
                                <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="flat">Flat Rate Simple Interest</option>
                            </select>
                        </div>
                    </div>

                    <!-- Right: Simulation Output Card -->
                    <div class="bg-slate-50 dark:bg-slate-800/60 p-5 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4 flex flex-col justify-between">
                        <div class="space-y-3">
                            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block border-b border-slate-200 dark:border-slate-700 pb-2">Simulated Repayment Terms</span>
                            
                            <div class="flex justify-between text-xs">
                                <span>Estimated Monthly EMI:</span>
                                <strong class="font-mono text-emerald-600 text-lg" x-text="'$' + Number(loanSimResult?.emi || 0).toLocaleString()"></strong>
                            </div>

                            <div class="flex justify-between text-xs">
                                <span>Total Interest Payable:</span>
                                <span class="font-mono text-slate-700 dark:text-slate-300" x-text="'$' + Number(loanSimResult?.totalInterest || 0).toLocaleString()"></span>
                            </div>

                            <div class="flex justify-between text-xs">
                                <span>Total Repayment Commitment:</span>
                                <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="'$' + Number(loanSimResult?.totalPayable || 0).toLocaleString()"></span>
                            </div>
                        </div>

                        <div class="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-[11px] text-emerald-800 dark:text-emerald-300">
                            Auto-deducted directly from monthly payroll register until balance hits zero.
                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>
</div>
