<!-- ============================================== -->
<!-- TAB: FINAL SETTLEMENT & GRATUITY (EXIT ENGINE) -->
<!-- ============================================== -->
<div x-show="activeTab === 'settlement'" class="space-y-6">
    
    <!-- Top Banner -->
    <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-800 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div class="space-y-2">
            <div class="flex items-center gap-2">
                <span class="px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-extrabold tracking-wider uppercase backdrop-blur-md border border-indigo-400/30">
                    Separation & Exit Engine
                </span>
                <span class="px-2.5 py-0.5 rounded-full bg-amber-400 text-amber-950 text-[10px] font-black uppercase">
                    Labour Law Statutory Compliant
                </span>
            </div>
            <h2 class="text-2xl font-black tracking-tight">
                Final Settlement & Gratuity Engine (Exit SSOT)
            </h2>
            <p class="text-slate-300 text-xs max-w-2xl leading-relaxed">
                Automated terminal benefits calculation including prorated exit salary, statutory gratuity (continuous service eligibility per statutory policy), leave encashment, notice period shortfall, and active loan offsets.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2 shrink-0">
            <a 
                href="<?= base_url('rules?domain=GRATUITY') ?>"
                class="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/15 transition flex items-center gap-1.5"
            >
                <i data-lucide="award" class="w-4 h-4 text-amber-300"></i>
                <span>Gratuity Policy Rules</span>
            </a>
            <button 
                type="button"
                @click="openNewSettlementModal()"
                class="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer"
            >
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Calculate Final Settlement</span>
            </button>
        </div>
    </div>

    <!-- Metric Stat Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total Settlements</span>
            <div class="text-2xl font-black font-mono text-slate-900 dark:text-white" x-text="finalSettlements.length"></div>
            <span class="text-[10px] text-slate-500">Processed separation records</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Pending Approvals</span>
            <div class="text-2xl font-black font-mono text-amber-600" x-text="finalSettlements.filter(s => s.payment_status === 'Pending' || s.payment_status === 'Draft').length"></div>
            <span class="text-[10px] text-slate-500">Awaiting Finance clearance</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total Disbursed Net</span>
            <div class="text-2xl font-black font-mono text-emerald-600" x-text="formatMoney(finalSettlements.filter(s => s.payment_status === 'Disbursed').reduce((sum, s) => sum + parseFloat(s.net_settlement_amount || 0), 0))"></div>
            <span class="text-[10px] text-slate-500">Settled terminal dues</span>
        </div>

        <div class="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-1">
            <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Statutory Gratuity Paid</span>
            <div class="text-2xl font-black font-mono text-indigo-600" x-text="formatMoney(finalSettlements.reduce((sum, s) => sum + parseFloat(s.gratuity_amount || 0), 0))"></div>
            <span class="text-[10px] text-slate-500">Cumulative gratuity funds</span>
        </div>
    </div>

    <!-- Settlement Records Table Card -->
    <div class="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-widest text-indigo-600 font-mono">Exit Registers</span>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Separation & Final Settlement Register</h3>
            </div>
            
            <div class="flex items-center gap-2">
                <input 
                    type="text" 
                    x-model="settlementSearchTerm" 
                    placeholder="Search employee or settlement ID..."
                    class="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-800 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 w-60"
                >
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead class="bg-slate-50 dark:bg-slate-800 font-bold text-[10px] uppercase text-slate-400 border-b border-slate-100 dark:border-slate-700">
                    <tr>
                        <th class="p-3">Settlement ID</th>
                        <th class="p-3">Employee</th>
                        <th class="p-3">Separation Type</th>
                        <th class="p-3">Service Tenure</th>
                        <th class="p-3">Last Working Day</th>
                        <th class="p-3 text-right">Exit Salary</th>
                        <th class="p-3 text-right">Gratuity</th>
                        <th class="p-3 text-right">Leave Encash</th>
                        <th class="p-3 text-right">Deductions</th>
                        <th class="p-3 text-right">Net Settlement</th>
                        <th class="p-3">Status</th>
                        <th class="p-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                    <template x-for="s in filteredFinalSettlements" :key="s.id">
                        <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/40 transition">
                            <td class="p-3 font-bold text-slate-900 dark:text-white" x-text="s.id"></td>
                            <td class="p-3 font-sans">
                                <div class="font-bold text-slate-900 dark:text-white" x-text="(s.first_name || '') + ' ' + (s.last_name || '')"></div>
                                <div class="text-[10px] text-slate-400 font-mono" x-text="(s.emp_code || s.employee_id) + ' • ' + (s.designation_name || 'Staff')"></div>
                            </td>
                            <td class="p-3 font-sans">
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700" x-text="s.separation_type"></span>
                            </td>
                            <td class="p-3 font-sans text-slate-700 dark:text-slate-300">
                                <span class="font-bold" x-text="s.total_service_years + ' yrs'"></span>
                                <span class="text-[10px] text-slate-400 block" x-text="(s.total_service_months || 0) + ' mos'"></span>
                            </td>
                            <td class="p-3 text-slate-700 dark:text-slate-300" x-text="s.last_working_day"></td>
                            <td class="p-3 text-right text-slate-700 dark:text-slate-300" x-text="formatMoney(s.exit_month_salary || 0, s.currency_code)"></td>
                            <td class="p-3 text-right font-bold text-indigo-600" x-text="formatMoney(s.gratuity_amount || 0, s.currency_code)"></td>
                            <td class="p-3 text-right text-teal-600" x-text="formatMoney(s.leave_encashment_amount || 0, s.currency_code)"></td>
                            <td class="p-3 text-right text-rose-600 font-semibold" x-text="'-' + formatMoney(s.total_deductions || 0, s.currency_code)"></td>
                            <td class="p-3 text-right font-black text-emerald-600 text-sm font-sans" x-text="formatMoney(s.net_settlement_amount || 0, s.currency_code)"></td>
                            <td class="p-3 font-sans">
                                <span 
                                    class="px-2 py-0.5 rounded-full text-[10px] font-bold border"
                                    :class="s.payment_status === 'Disbursed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : (s.payment_status === 'Approved' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : 'bg-amber-50 text-amber-700 border-amber-200')"
                                    x-text="s.payment_status"
                                ></span>
                            </td>
                            <td class="p-3 text-right font-sans">
                                <div class="flex items-center justify-end gap-1.5">
                                    <button 
                                        type="button" 
                                        @click="openSettlementStatement(s)"
                                        class="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-[11px] transition cursor-pointer"
                                        title="View Official Certificate"
                                    >
                                        Statement
                                    </button>
                                    <button 
                                        type="button" 
                                        @click="openSettlementExplainer(s)"
                                        class="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-900/40 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-[11px] transition cursor-pointer flex items-center gap-1"
                                        title="Explain rules and snapshot used for this settlement"
                                    >
                                        <span>Explain</span>
                                    </button>
                                    <template x-if="s.payment_status === 'Draft' || s.payment_status === 'Pending'">
                                        <button 
                                            type="button" 
                                            @click="approveSettlement(s.id)"
                                            class="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] transition cursor-pointer"
                                        >
                                            Approve
                                        </button>
                                    </template>
                                    <template x-if="s.payment_status === 'Approved'">
                                        <button 
                                            type="button" 
                                            @click="disburseSettlement(s.id)"
                                            class="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition shadow-xs cursor-pointer"
                                        >
                                            Disburse
                                        </button>
                                    </template>
                                </div>
                            </td>
                        </tr>
                    </template>
                    <template x-if="filteredFinalSettlements.length === 0">
                        <tr>
                            <td colspan="12" class="p-6 text-center text-slate-400 font-sans">No final settlement records found.</td>
                        </tr>
                    </template>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ========================================================== -->
    <!-- MODAL: CALCULATE FINAL SETTLEMENT (LIVE INTERACTIVE ENGINE)-->
    <!-- ========================================================== -->
    <div 
        x-show="settlementModalOpen" 
        x-cloak
        class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4"
        style="display: none;"
    >
        <div 
            @click.outside="settlementModalOpen = false"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-4xl w-full shadow-2xl space-y-6 animate-in zoom-in-95 duration-150 relative max-h-[92vh] overflow-y-auto"
        >
            <button type="button" @click="settlementModalOpen = false" class="absolute top-6 right-6 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>

            <div>
                <span class="text-[10px] font-bold uppercase tracking-widest text-indigo-600 font-mono">Separation Terminal Dues</span>
                <h3 class="text-xl font-black text-slate-900 dark:text-white">Calculate Final Settlement & Gratuity</h3>
                <p class="text-xs text-slate-500 mt-1">Automatic statutory computation based on Bangladesh Labour Act guidelines (Section 27).</p>
            </div>

            <form @submit.prevent="submitFinalSettlement()" class="space-y-6 text-xs">
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    
                    <!-- Left Column: Inputs & Clearances -->
                    <div class="space-y-4">
                        
                        <!-- Employee Selection -->
                        <div>
                            <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Select Resigning/Exiting Employee</label>
                            <select 
                                x-model="settleEmployeeId" 
                                @change="onSettlementEmployeeChange()"
                                class="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold text-slate-900 dark:text-white [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100"
                                required
                            >
                                <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" value="">-- Choose Employee --</option>
                                <template x-for="emp in employees" :key="emp.id">
                                    <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" :value="emp.id" x-text="emp.first_name + ' ' + emp.last_name + ' (' + (emp.employee_id || emp.id) + ') - Joined: ' + (emp.joining_date || '2021-01-01')"></option>
                                </template>
                            </select>
                        </div>

                        <!-- Separation Type & Dates -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Separation Type</label>
                                <select x-model="settleType" @change="recalculateSettlementLive()" class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-slate-900 dark:text-white [&>option]:bg-white [&>option]:dark:bg-slate-800 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                                    <template x-for="st in separationTypes" :key="st">
                                        <option class="bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" :value="st" x-text="st"></option>
                                    </template>
                                </select>
                            </div>

                            <div>
                                <label class="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1">Last Working Day</label>
                                <input 
                                    type="date" 
                                    x-model="settleLastDay" 
                                    @change="recalculateSettlementLive()"
                                    class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-slate-800 dark:text-white"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Notice Period Rules -->
                        <div class="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Notice Required (Days)</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleNoticeReq" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 font-mono font-bold"
                                >
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Notice Served (Days)</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleNoticeServed" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 font-mono font-bold"
                                >
                            </div>
                        </div>

                        <!-- Days & Leave Encashment -->
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Worked Days in Exit Mo</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleWorkedDays" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold"
                                >
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Encashable Leaves (Days)</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleEncashLeaves" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold"
                                >
                            </div>
                        </div>

                        <!-- Asset Recovery & Other Adjustments -->
                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Asset Recovery Ded (<span x-text="currencyCode"></span>)</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleAssetDeduction" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-rose-600"
                                >
                                <template x-if="settleLiveResult?.unreturned_assets_count > 0">
                                    <span class="text-[10px] text-amber-600 dark:text-amber-400 font-semibold block mt-1" x-text="'Hold: ' + settleLiveResult.unreturned_assets_count + ' unreturned asset(s) auto-calculated'"></span>
                                </template>
                            </div>
                            <div>
                                <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tax Withholding (<span x-text="currencyCode"></span>)</label>
                                <input 
                                    type="number" 
                                    x-model.number="settleTaxDeduction" 
                                    @input="recalculateSettlementLive()"
                                    class="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-amber-600"
                                >
                            </div>
                        </div>

                        <div>
                            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Clearance Remarks</label>
                            <input 
                                type="text" 
                                x-model="settleRemarks" 
                                placeholder="Clearance approved across IT, Admin, and Operations"
                                class="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
                            >
                        </div>
                    </div>

                    <!-- Right Column: Live Settlement Waterfall Breakdown -->
                    <div class="bg-slate-50 dark:bg-slate-800/80 p-5 rounded-3xl border border-slate-200 dark:border-slate-700 space-y-4 flex flex-col justify-between">
                        
                        <div>
                            <div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
                                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider font-mono">Service Profile</span>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase" :class="settleLiveResult?.gratuity_eligible ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'" x-text="settleLiveResult?.gratuity_eligible ? ('Gratuity Eligible (' + (settleLiveResult?.gratuity_years || settleLiveResult?.total_service_years || 0) + ' Yrs >= ' + (settleLiveResult?.gratuity_min_years || 5) + ' Yrs policy)') : ('Not Gratuity Eligible (< ' + (settleLiveResult?.gratuity_min_years || 5) + ' Yrs policy)')"></span>
                            </div>

                            <!-- Tenure -->
                            <div class="py-3 space-y-1">
                                <div class="flex justify-between text-slate-700 dark:text-slate-300">
                                    <span>Continuous Service Duration:</span>
                                    <strong class="font-mono text-slate-900 dark:text-white" x-text="(settleLiveResult?.total_service_years || 0) + ' Years, ' + (settleLiveResult?.total_service_months || 0) + ' Months'"></strong>
                                </div>
                                <div class="flex justify-between text-slate-500 text-[11px]">
                                    <span>Last Drawn Basic:</span>
                                    <span class="font-mono" x-text="formatMoney(settleLiveResult?.last_drawn_basic || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                            </div>

                            <!-- Waterfall Earnings -->
                            <div class="space-y-1.5 pt-2 border-t border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                                <div class="flex justify-between text-[11px]">
                                    <span>Exit Month Prorated Salary:</span>
                                    <span class="font-mono font-bold text-slate-900 dark:text-white" x-text="'+' + formatMoney(settleLiveResult?.exit_month_salary || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between text-[11px]">
                                    <div>
                                        <span>Statutory Gratuity Benefit:</span>
                                        <span class="block text-[9px] text-slate-400 font-mono" x-show="settleLiveResult?.gratuity_eligible" x-text="settleLiveResult?.earnings?.gratuity_details?.formula_description || settleLiveResult?.gratuity_details?.formula_description || ('Policy: ' + (settleLiveResult?.gratuity_rate_days || 15) + ' days/yr (' + (settleLiveResult?.gratuity_years || 0) + ' yrs @ ' + (settleLiveResult?.gratuity_divisor_days || 26) + ' day divisor)')"></span>
                                    </div>
                                    <span class="font-mono font-black text-indigo-600" x-text="'+' + formatMoney(settleLiveResult?.gratuity_amount || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between text-[11px]">
                                    <span>Leave Encashment Payment:</span>
                                    <span class="font-mono font-bold text-teal-600" x-text="'+' + formatMoney(settleLiveResult?.leave_encashment_amount || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between font-bold text-slate-900 dark:text-white pt-1 border-t border-slate-200/80 dark:border-slate-700">
                                    <span>Gross Payable Terminal Benefits:</span>
                                    <span class="font-mono" x-text="formatMoney(settleLiveResult?.total_payable || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                            </div>

                            <!-- Waterfall Deductions -->
                            <div class="space-y-1.5 pt-3 border-t border-slate-200 dark:border-slate-700 text-rose-600">
                                <div class="flex justify-between text-[11px]">
                                    <span>Notice Shortfall Deduction:</span>
                                    <span class="font-mono font-bold" x-text="'-' + formatMoney(settleLiveResult?.notice_shortfall_deduction || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between text-[11px]">
                                    <span>Active Loan Outstanding Offset:</span>
                                    <span class="font-mono font-bold" x-text="'-' + formatMoney(settleLiveResult?.outstanding_loan_deduction || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between text-[11px]">
                                    <span>Asset & IT Clearance Deductions:</span>
                                    <span class="font-mono font-bold" x-text="'-' + formatMoney(settleLiveResult?.asset_recovery_deduction || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between items-start text-[11px] text-amber-600">
                                    <div>
                                        <span>Income Tax Withholding:</span>
                                        <div class="text-[9px] text-slate-400 font-mono" x-show="settleLiveResult?.tax_note" x-text="settleLiveResult?.tax_note"></div>
                                    </div>
                                    <span class="font-mono font-bold" x-text="'-' + formatMoney(settleLiveResult?.tax_deduction || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                                <div class="flex justify-between font-bold text-rose-700 pt-1 border-t border-slate-200/80 dark:border-slate-700">
                                    <span>Total Terminal Deductions:</span>
                                    <span class="font-mono" x-text="'-' + formatMoney(settleLiveResult?.total_deductions || 0, settleLiveResult?.currency_code)"></span>
                                </div>
                            </div>
                        </div>

                        <!-- Grand Total Net Settlement -->
                        <div class="bg-white dark:bg-slate-900 p-4 rounded-2xl border-2 border-emerald-500/50 shadow-sm flex items-center justify-between">
                            <div>
                                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Final Net Settlement Payable</span>
                                <span class="text-xs text-slate-500">Transferred via Bank Wire / Cheque</span>
                            </div>
                            <div class="text-2xl font-black font-mono text-emerald-600" x-text="formatMoney(settleLiveResult?.net_settlement_amount || 0, settleLiveResult?.currency_code)"></div>
                        </div>

                    </div>
                </div>

                <!-- Modal Action Buttons -->
                <div class="flex items-center justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button 
                        type="button" 
                        @click="settlementModalOpen = false" 
                        class="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold transition cursor-pointer"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit" 
                        class="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold shadow-md transition flex items-center gap-2 cursor-pointer"
                    >
                        <i data-lucide="check-circle" class="w-4 h-4"></i>
                        <span>Save & Approve Final Settlement</span>
                    </button>
                </div>

            </form>
        </div>
    </div>

    <!-- ========================================================== -->
    <!-- MODAL: FORMAL PRINTABLE CLEARANCE & SETTLEMENT STATEMENT   -->
    <!-- ========================================================== -->
    <div 
        x-show="viewStatementModalOpen" 
        x-cloak
        class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4"
        style="display: none;"
    >
        <div 
            @click.outside="viewStatementModalOpen = false"
            class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-10 max-w-3xl w-full shadow-2xl space-y-6 animate-in zoom-in-95 duration-150 relative max-h-[94vh] overflow-y-auto"
        >
            <div class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                        <i data-lucide="file-text" class="w-5 h-5"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-black text-slate-900 dark:text-white">Official Certificate of Final Settlement</h3>
                        <p class="text-xs text-slate-500">Separation clearance and terminal gratuity disbursement certificate</p>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <button 
                        type="button" 
                        @click="openSettlementExplainer(currentStatement)"
                        class="px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer no-print"
                        title="Explain rules and snapshot parameters for this settlement"
                    >
                        <i data-lucide="help-circle" class="w-4 h-4"></i>
                        <span>Explain Rules</span>
                    </button>
                    <button 
                        type="button" 
                        onclick="window.print()" 
                        class="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                    >
                        <i data-lucide="printer" class="w-4 h-4"></i>
                        <span>Print</span>
                    </button>
                    <button type="button" @click="viewStatementModalOpen = false" class="text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer p-1">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
            </div>

            <!-- Certificate Printable Body -->
            <div id="printableSettlementArea" class="border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 bg-slate-50/40 dark:bg-slate-950/40 text-slate-800 dark:text-slate-200 text-xs">
                
                <!-- Company Header -->
                <div class="text-center border-b border-slate-200 dark:border-slate-800 pb-4 space-y-1">
                    <h2 class="text-xl font-black uppercase tracking-wider text-slate-900 dark:text-white" x-text="activeCompany?.name || 'Enterprise Global HRMS'"></h2>
                    <p class="text-[11px] text-slate-500" x-text="activeCompany?.address || 'Corporate Headquarters, Business District, Dhaka 1212'"></p>
                    <div class="inline-block px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] uppercase tracking-widest border border-indigo-200 mt-2">
                        FINAL SETTLEMENT & STATUTORY GRATUITY CERTIFICATE
                    </div>
                </div>

                <!-- SSOT Rule Snapshot Audit Badge -->
                <div class="flex items-center justify-between bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100/80 dark:border-indigo-800/60 rounded-xl px-4 py-2.5 text-xs text-indigo-950 dark:text-indigo-200 no-print">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-emerald-200"></span>
                        <span class="font-bold">Rules Engine Snapshot:</span>
                        <span class="text-indigo-800 dark:text-indigo-300 font-mono text-[11px]" x-text="currentStatement?.rules_snapshot_json ? 'Verified Immutable Audit Snapshot' : 'Authoritative SSOT Resolution'"></span>
                    </div>
                    <button 
                        type="button" 
                        @click="openSettlementExplainer(currentStatement)" 
                        class="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200 font-bold underline text-[11px] cursor-pointer flex items-center gap-1"
                    >
                        <span>Explain Parameter Origins</span>
                        <span>→</span>
                    </button>
                </div>

                <!-- Employee Details Grid -->
                <div class="grid grid-cols-2 sm:grid-cols-3 gap-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Employee Name</span>
                        <strong class="text-sm font-black text-slate-900 dark:text-white" x-text="(currentStatement?.first_name || '') + ' ' + (currentStatement?.last_name || '')"></strong>
                    </div>
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Staff Code</span>
                        <span class="font-mono font-bold" x-text="currentStatement?.emp_code || currentStatement?.employee_id"></span>
                    </div>
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Department</span>
                        <span x-text="currentStatement?.department_name || 'Operations'"></span>
                    </div>
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Joining Date</span>
                        <span class="font-mono" x-text="currentStatement?.joining_date || '2020-03-01'"></span>
                    </div>
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Last Working Date</span>
                        <span class="font-mono font-bold" x-text="currentStatement?.last_working_day"></span>
                    </div>
                    <div>
                        <span class="text-[10px] text-slate-400 uppercase font-bold block">Total Service Tenure</span>
                        <strong class="font-bold text-indigo-600" x-text="(currentStatement?.total_service_years || 0) + ' Years, ' + (currentStatement?.total_service_months || 0) + ' Mos'"></strong>
                    </div>
                </div>

                <!-- Waterfall Breakdown Tables -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    <!-- Earnings -->
                    <div class="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                        <span class="text-[11px] font-bold text-emerald-700 uppercase tracking-wider font-mono block border-b pb-1">Gross Terminal Entitlements</span>
                        <div class="flex justify-between">
                            <span>Exit Month Salary:</span>
                            <span class="font-mono font-bold" x-text="formatMoney(currentStatement?.exit_month_salary || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between">
                            <span>Statutory Gratuity:</span>
                            <span class="font-mono font-bold text-indigo-600" x-text="formatMoney(currentStatement?.gratuity_amount || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <template x-if="currentStatement?.formula_description || currentStatement?.gratuity_details?.formula_description">
                            <div class="text-[10px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-lg font-mono border border-slate-200 dark:border-slate-700/80 space-y-1">
                                <span class="font-bold text-slate-700 dark:text-slate-300 block">Gratuity Calculation Formula:</span>
                                <div class="break-words leading-relaxed" x-text="currentStatement?.formula_description || currentStatement?.gratuity_details?.formula_description"></div>
                            </div>
                        </template>
                        <div class="flex justify-between">
                            <span>Leave Encashment:</span>
                            <span class="font-mono font-bold text-teal-600" x-text="formatMoney(currentStatement?.leave_encashment_amount || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between pt-2 border-t font-bold text-slate-900 dark:text-white">
                            <span>Total Gross Payable:</span>
                            <span class="font-mono" x-text="formatMoney(currentStatement?.total_payable || 0, currentStatement?.currency_code)"></span>
                        </div>
                    </div>

                    <!-- Deductions -->
                    <div class="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                        <span class="text-[11px] font-bold text-rose-700 uppercase tracking-wider font-mono block border-b pb-1">Terminal Deductions & Recoveries</span>
                        <div class="flex justify-between text-rose-600">
                            <span>Notice Shortfall:</span>
                            <span class="font-mono" x-text="'-' + formatMoney(currentStatement?.notice_shortfall_deduction || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between text-rose-600">
                            <span>Loan Settlement Offset:</span>
                            <span class="font-mono" x-text="'-' + formatMoney(currentStatement?.outstanding_loan_deduction || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between text-rose-600">
                            <span>Asset / IT Clearance:</span>
                            <span class="font-mono" x-text="'-' + formatMoney(currentStatement?.asset_recovery_deduction || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between items-start text-amber-600">
                            <div>
                                <span>Tax Deduction (TDS):</span>
                                <div class="text-[9px] text-slate-400 font-mono" x-show="currentStatement?.tax_note" x-text="currentStatement?.tax_note"></div>
                            </div>
                            <span class="font-mono" x-text="'-' + formatMoney(currentStatement?.tax_deduction || 0, currentStatement?.currency_code)"></span>
                        </div>
                        <div class="flex justify-between pt-2 border-t font-bold text-rose-700">
                            <span>Total Recoveries:</span>
                            <span class="font-mono" x-text="'-' + formatMoney(currentStatement?.total_deductions || 0, currentStatement?.currency_code)"></span>
                        </div>
                    </div>

                </div>

                <!-- Grand Net Banner -->
                <div class="bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 p-4 rounded-xl flex items-center justify-between">
                    <div>
                        <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 block">Net Terminal Settlement Disbursed</span>
                        <span class="text-[11px] text-emerald-700 dark:text-emerald-400" x-text="'Payment Mode: ' + (currentStatement?.payment_method || 'Bank Wire') + ' • Status: ' + currentStatement?.payment_status"></span>
                    </div>
                    <div class="text-2xl font-black font-mono text-emerald-700 dark:text-emerald-400" x-text="formatMoney(currentStatement?.net_settlement_amount || 0, currentStatement?.currency_code)"></div>
                </div>

                <!-- Formal Signatures Strip -->
                <div class="pt-8 grid grid-cols-3 gap-6 text-center text-[10px] text-slate-500 font-sans">
                    <div class="space-y-1">
                        <div class="border-b border-slate-300 dark:border-slate-700 h-10"></div>
                        <span class="font-bold block text-slate-700 dark:text-slate-300">Employee Signature</span>
                        <span>Date & Full Name</span>
                    </div>
                    <div class="space-y-1">
                        <div class="border-b border-slate-300 dark:border-slate-700 h-10"></div>
                        <span class="font-bold block text-slate-700 dark:text-slate-300">Head of Human Resources</span>
                        <span>Clearance Verified</span>
                    </div>
                    <div class="space-y-1">
                        <div class="border-b border-slate-300 dark:border-slate-700 h-10"></div>
                        <span class="font-bold block text-slate-700 dark:text-slate-300">Chief Financial Officer</span>
                        <span>Payment Authorized</span>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <!-- Explain Rules Snapshot Modal for Settlements -->
    <div 
        x-show="settlementExplainerModalOpen" 
        x-cloak
        class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 no-print"
        style="display: none;"
    >
        <div 
            class="bg-white dark:bg-slate-900 rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5"
            @click.away="settlementExplainerModalOpen = false"
            @keydown.escape.window="settlementExplainerModalOpen = false"
        >
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
                        ⚙️
                    </div>
                    <div>
                        <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Settlement Rule Parameters & Origin Explanation</h3>
                        <p class="text-xs text-slate-500">Single source of truth resolution breakdown for settlement calculations</p>
                    </div>
                </div>
                <button 
                    type="button" 
                    @click="settlementExplainerModalOpen = false" 
                    class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold text-lg p-1 cursor-pointer"
                >
                    &times;
                </button>
            </div>

            <!-- Loading State -->
            <template x-if="settlementExplainerLoading">
                <div class="py-12 text-center space-y-3">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-2 border-indigo-600 border-t-transparent"></div>
                    <p class="text-xs text-slate-500 font-medium">Resolving rule parameter hierarchy and snapshot layers...</p>
                </div>
            </template>

            <!-- Error State -->
            <template x-if="settlementExplainerError && !settlementExplainerLoading">
                <div class="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl text-rose-700 dark:text-rose-300 text-xs space-y-1">
                    <div class="font-bold">Unable to resolve rule explanation</div>
                    <div x-text="settlementExplainerError"></div>
                </div>
            </template>

            <!-- Content State -->
            <template x-if="!settlementExplainerLoading && !settlementExplainerError">
                <div class="space-y-4">
                    <!-- Domain Tabs -->
                    <div class="flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800 pb-2 overflow-x-auto">
                        <template x-for="d in settlementExplainerDomains" :key="d">
                            <button 
                                type="button" 
                                @click="settlementExplainerActiveDomain = d" 
                                class="px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer"
                                :class="settlementExplainerActiveDomain === d ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'"
                                x-text="d"
                            ></button>
                        </template>
                    </div>

                    <!-- Selected Domain Content -->
                    <template x-if="settlementExplainerActiveDomainData">
                        <div class="space-y-3">
                            <!-- Snapshot Hash Badge if available -->
                            <template x-if="settlementExplainerActiveDomainSnapshot && settlementExplainerActiveDomainSnapshot.hash">
                                <div class="flex items-center justify-between bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px]">
                                    <span class="text-slate-500 dark:text-slate-400">Cryptographic Layer Hash:</span>
                                    <span class="font-mono font-bold text-indigo-600 dark:text-indigo-400" x-text="settlementExplainerActiveDomainSnapshot.hash"></span>
                                </div>
                            </template>

                            <!-- Parameters Table -->
                            <div class="max-h-80 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                                <table class="w-full text-left text-xs">
                                    <thead class="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-[10px] uppercase font-bold text-slate-400">
                                        <tr>
                                            <th class="p-2.5">Parameter Key</th>
                                            <th class="p-2.5">Resolved Value</th>
                                            <th class="p-2.5">Origin Scope</th>
                                            <th class="p-2.5">Version</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
                                        <template x-for="(exp, key) in (settlementExplainerActiveDomainData.explanation || {})" :key="key">
                                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                                                <td class="p-2.5 font-sans font-semibold text-slate-800 dark:text-slate-200" x-text="key"></td>
                                                <td class="p-2.5 font-bold text-indigo-700 dark:text-indigo-300" x-text="formatSettlementExplainerValue(exp.value)"></td>
                                                <td class="p-2.5">
                                                    <span 
                                                        class="px-2 py-0.5 rounded-md text-[10px] font-sans font-bold uppercase"
                                                        :class="settlementScopeBadgeClass(exp.scope_level)"
                                                        x-text="exp.scope_level || 'Company'"
                                                    ></span>
                                                </td>
                                                <td class="p-2.5 text-slate-500" x-text="'v' + (exp.version_number || 1)"></td>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </template>
                </div>
            </template>

            <!-- Footer -->
            <div class="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
                <button 
                    type="button" 
                    @click="settlementExplainerModalOpen = false" 
                    class="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg cursor-pointer"
                >
                    Close
                </button>
            </div>
        </div>
    </div>

</div>
