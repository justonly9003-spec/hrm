<div class="space-y-6">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <div class="flex items-center gap-3">
                <a href="<?= base_url('payroll') ?>" class="text-sm text-slate-400 hover:text-slate-600">← Back</a>
                <h1 class="text-2xl font-bold text-slate-900">Payroll Batch: <?= esc($batch['payroll_month']) ?></h1>
                <span class="px-2.5 py-1 text-xs font-semibold rounded-full bg-blue-50 text-blue-700 border border-blue-200"><?= esc($batch['status']) ?></span>
                <?php if (!empty($batch['is_locked'])): ?>
                <span class="px-2.5 py-1 text-xs font-semibold rounded-full bg-amber-50 text-amber-700 border border-amber-200">🔒 Locked</span>
                <?php endif; ?>
            </div>
            <p class="text-sm text-slate-500 mt-1">Processed <?= count($items) ?> employee payslips with full earnings and statutory deduction ledger.</p>
        </div>
        <div class="flex items-center gap-2">
            <form action="<?= base_url('payroll/toggle-lock/' . $batch['id']) ?>" method="POST">
                <?= csrf_field() ?>
                <button type="submit" class="px-3.5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg">
                    <?= !empty($batch['is_locked']) ? '🔓 Unlock Batch' : '🔒 Lock Batch' ?>
                </button>
            </form>
            <div class="relative inline-block text-left">
                <button onclick="document.getElementById('statusDropdown').classList.toggle('hidden')" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm">
                    Workflow Actions ▼
                </button>
                <div id="statusDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-20">
                    <?php foreach (['HR Review', 'Finance Review', 'Management Approval', 'Approved', 'Paid'] as $st): ?>
                    <form action="<?= base_url('payroll/update-status/' . $batch['id'] . '/' . urlencode($st)) ?>" method="POST">
                        <?= csrf_field() ?>
                        <button type="submit" class="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50"><?= $st ?></button>
                    </form>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Summary Metrics -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Gross Earnings</span>
            <div class="text-2xl font-bold text-slate-900 mt-2">$<?= number_format($batch['total_earnings'], 2) ?></div>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Statutory Deductions</span>
            <div class="text-2xl font-bold text-rose-600 mt-2">-$<?= number_format($batch['total_deductions'], 2) ?></div>
        </div>
        <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Net Disbursed Amount</span>
            <div class="text-2xl font-bold text-emerald-600 mt-2">$<?= number_format($batch['net_disbursed'], 2) ?></div>
        </div>
    </div>

    <?php
        $batchUnappliedTax = 0.0;
        $batchUnappliedPf  = 0.0;
        $batchUnappliedLop = 0.0;
        $unappliedEmployeesCount = 0;
        $belowFloorCount = 0;
        $floorWarningsList = [];
        foreach ($items as $chkItem) {
            $uTax = (float)($chkItem['unapplied_tax'] ?? 0.0);
            $uPf  = (float)($chkItem['unapplied_pf'] ?? 0.0);
            $uLop = (float)($chkItem['unapplied_lop'] ?? 0.0);
            if ($uTax > 0 || $uPf > 0 || $uLop > 0) {
                $unappliedEmployeesCount++;
                $batchUnappliedTax += $uTax;
                $batchUnappliedPf  += $uPf;
                $batchUnappliedLop += $uLop;
            }
            $bd = !empty($chkItem['components_breakdown_json'])
                ? (is_array($chkItem['components_breakdown_json']) ? $chkItem['components_breakdown_json'] : json_decode($chkItem['components_breakdown_json'], true))
                : [];
            $floorWarn = $bd['floor_warning'] ?? null;
            $isBelow = !empty($bd['is_below_floor']) || ($floorWarn !== null);
            if ($isBelow && $floorWarn) {
                $belowFloorCount++;
                $floorWarningsList[] = $floorWarn;
            }
        }
    ?>
    <?php if ($belowFloorCount > 0): ?>
    <div class="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 space-y-2">
        <div class="flex items-center gap-2">
            <span class="text-xl">⚠️</span>
            <div class="font-bold text-sm text-amber-800"><?= $belowFloorCount ?> employee(s) below minimum net salary floor</div>
        </div>
        <p class="text-xs text-amber-700">
            Net salary fell below the configured minimum floor after full LOP and capped deductions. Amounts are preserved without blocking payroll.
        </p>
        <div class="overflow-x-auto mt-2">
            <table class="w-full text-left text-xs bg-white rounded-lg border border-amber-200 overflow-hidden">
                <thead class="bg-amber-100 text-[10px] uppercase font-bold text-amber-900">
                    <tr>
                        <th class="px-3 py-2">Employee</th>
                        <th class="px-3 py-2 font-mono">Gross</th>
                        <th class="px-3 py-2 font-mono">LOP Amount</th>
                        <th class="px-3 py-2 font-mono">Other Deductions</th>
                        <th class="px-3 py-2 font-mono">Net Salary</th>
                        <th class="px-3 py-2 font-mono">Floor</th>
                        <th class="px-3 py-2 font-mono text-rose-600">Shortfall</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-amber-100 font-mono text-xs">
                    <?php foreach ($floorWarningsList as $fw): ?>
                    <tr>
                        <td class="px-3 py-2 font-sans font-semibold text-slate-800"><?= esc($fw['employee'] ?? $fw['employee_name'] ?? 'Employee') ?></td>
                        <td class="px-3 py-2">$<?= number_format((float)($fw['gross'] ?? 0), 2) ?></td>
                        <td class="px-3 py-2 text-amber-700">$<?= number_format((float)($fw['lop_amount'] ?? 0), 2) ?></td>
                        <td class="px-3 py-2">$<?= number_format((float)($fw['other_deductions'] ?? 0), 2) ?></td>
                        <td class="px-3 py-2 font-bold text-slate-900">$<?= number_format((float)($fw['net'] ?? 0), 2) ?></td>
                        <td class="px-3 py-2">$<?= number_format((float)($fw['floor'] ?? 0), 2) ?></td>
                        <td class="px-3 py-2 font-bold text-rose-600">$<?= number_format((float)($fw['shortfall'] ?? 0), 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($unappliedEmployeesCount > 0): ?>
    <div class="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3">
        <span class="text-xl">⚠️</span>
        <div>
            <div class="font-bold text-sm text-amber-800">Statutory 50% Deduction Ceiling Alert</div>
            <p class="text-xs text-amber-700 mt-1">
                A total of <?= $unappliedEmployeesCount ?> employee(s) in this batch reached the statutory 50% deduction ceiling threshold.
                <?php
                    $summaryParts = [];
                    if ($batchUnappliedTax > 0) $summaryParts[] = 'Tax: ' . number_format($batchUnappliedTax, 2);
                    if ($batchUnappliedPf > 0) $summaryParts[] = 'PF: ' . number_format($batchUnappliedPf, 2);
                    if ($batchUnappliedLop > 0) $summaryParts[] = 'LOP: ' . number_format($batchUnappliedLop, 2);
                ?>
                Total Unapplied Statutory Liabilities: <?= implode(', ', $summaryParts) ?>.
            </p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Employee Payslip Table -->
    <div class="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50 text-xs font-semibold text-slate-700 uppercase border-b border-slate-200">
                    <tr>
                        <th class="px-6 py-4">Employee</th>
                        <th class="px-6 py-4">Basic</th>
                        <th class="px-6 py-4">Allowances</th>
                        <th class="px-6 py-4">Overtime</th>
                        <th class="px-6 py-4">Gross</th>
                        <th class="px-6 py-4">Deductions</th>
                        <th class="px-6 py-4">Net Salary</th>
                        <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-mono text-xs">
                    <?php foreach ($items as $it): ?>
                    <?php
                        $unappliedTax = (float)($it['unapplied_tax'] ?? 0.0);
                        $unappliedPf  = (float)($it['unapplied_pf'] ?? 0.0);
                        $unappliedLop = (float)($it['unapplied_lop'] ?? 0.0);
                        $hasUnapplied = ($unappliedTax > 0 || $unappliedPf > 0 || $unappliedLop > 0);
                        $unappliedParts = [];
                        if ($unappliedTax > 0) {
                            $unappliedParts[] = number_format($unappliedTax, 2) . ' Tax';
                        }
                        if ($unappliedPf > 0) {
                            $unappliedParts[] = number_format($unappliedPf, 2) . ' PF';
                        }
                        if ($unappliedLop > 0) {
                            $unappliedParts[] = number_format($unappliedLop, 2) . ' LOP';
                        }
                        $unappliedMsg = implode(', ', $unappliedParts);
                    ?>
                    <?php
                        $itBd = !empty($it['components_breakdown_json'])
                            ? (is_array($it['components_breakdown_json']) ? $it['components_breakdown_json'] : json_decode($it['components_breakdown_json'], true))
                            : [];
                        $itFloorWarn = $itBd['floor_warning'] ?? null;
                        $itBelowFloor = !empty($itBd['is_below_floor']) || ($itFloorWarn !== null);
                    ?>
                    <tr class="hover:bg-slate-50/60 <?= $hasUnapplied ? 'bg-amber-50/20' : ($itBelowFloor ? 'bg-amber-50/10' : '') ?>">
                        <td class="px-6 py-4 font-sans font-semibold text-slate-900">
                            <?= esc($it['employee_name']) ?>
                            <div class="text-slate-400 text-xs font-mono font-normal"><?= esc($it['employee_code']) ?> · <?= esc($it['designation_name'] ?? 'Staff') ?></div>
                            <?php if ($hasUnapplied): ?>
                            <div class="mt-1.5 inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-50 border border-amber-200 text-amber-800 text-[11px] font-sans font-medium" title="Ceiling shortfall">
                                <span>⚠️</span>
                                <span>Ceiling unapplied: <?= esc($unappliedMsg) ?></span>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">$<?= number_format($it['basic_salary'], 2) ?></td>
                        <td class="px-6 py-4 text-emerald-600">+$<?= number_format($it['allowances'], 2) ?></td>
                        <td class="px-6 py-4">+$<?= number_format($it['overtime_amount'], 2) ?></td>
                        <td class="px-6 py-4 font-semibold text-slate-900">$<?= number_format($it['gross_salary'], 2) ?></td>
                        <td class="px-6 py-4 text-rose-600">
                            -$<?= number_format($it['total_deductions'], 2) ?>
                            <?php if ($hasUnapplied): ?>
                            <div class="text-[10px] text-amber-700 font-sans font-medium mt-0.5">
                                (Ceiling Capped)
                            </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 font-bold text-indigo-700">
                            <div>$<?= number_format($it['net_salary'], 2) ?></div>
                            <?php if ($itBelowFloor): ?>
                            <div class="mt-1">
                                <span class="px-1.5 py-0.5 text-[10px] font-bold rounded bg-amber-100 text-amber-800 border border-amber-300" title="<?= esc($itFloorWarn['message'] ?? 'Below minimum net salary floor') ?>">
                                    Below Floor
                                </span>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-right font-sans">
                            <div class="flex items-center justify-end gap-1.5">
                                <a href="<?= base_url('payroll/payslip-view/' . $it['id']) ?>" class="px-2.5 py-1 text-xs font-medium text-indigo-600 hover:text-indigo-900 border border-indigo-200 rounded hover:bg-indigo-50">
                                    View Payslip
                                </a>
                                <a href="<?= base_url('payroll/payslip-view/' . $it['id']) ?>#explain" class="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded hover:bg-slate-50" title="Explain calculation rules and snapshots">
                                    Explain
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
