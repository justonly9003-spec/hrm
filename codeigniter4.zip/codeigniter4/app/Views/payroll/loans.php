<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <i data-lucide="wallet" class="w-7 h-7 text-indigo-600"></i>
                Employee Loan & Salary Advance Ledger
            </h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 mt-1">Manage amortization schedules, monthly EMI deductions, approval workflows, and remaining balance tracking.</p>
        </div>
        <button onclick="document.getElementById('newLoanModal').classList.remove('hidden')" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition-all">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            Apply for Loan / Advance
        </button>
    </div>

    <!-- Loans Ledger Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <h3 class="font-semibold text-slate-900 dark:text-white text-base">Corporate Loan Portfolio</h3>
            <span class="text-xs text-slate-400">Payroll Automated Deductions</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium">
                        <th class="py-3.5 px-5">Employee</th>
                        <th class="py-3.5 px-5">Principal</th>
                        <th class="py-3.5 px-5">Tenure / EMI</th>
                        <th class="py-3.5 px-5">Disbursed Date</th>
                        <th class="py-3.5 px-5">Remaining Balance</th>
                        <th class="py-3.5 px-5">Status</th>
                        <th class="py-3.5 px-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                    <?php if (empty($loans)): ?>
                        <tr>
                            <td colspan="7" class="py-8 text-center text-slate-400">No corporate loan applications logged.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($loans as $loan): ?>
                            <?php
                                $loanAmount = (float)($loan['loan_amount'] ?? $loan['principal_amount'] ?? $loan['amount'] ?? 0);
                                $tenure = (int)($loan['total_installments'] ?? $loan['repayment_months'] ?? $loan['tenure_months'] ?? 1);
                                $monthlyEmi = (float)($loan['monthly_emi'] ?? $loan['monthly_installment'] ?? ($tenure > 0 ? $loanAmount / $tenure : 0));
                                $remaining = isset($loan['total_due']) ? (float)$loan['total_due'] : (isset($loan['remaining_balance']) ? (float)$loan['remaining_balance'] : max(0, $loanAmount - (float)($loan['total_paid'] ?? 0)));
                            ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                <td class="py-3.5 px-5 font-semibold text-slate-900 dark:text-white">
                                    <?= esc($loan['employee_name'] ?? 'Employee') ?>
                                    <div class="text-xs font-normal text-slate-400"><?= esc($loan['employee_code'] ?? '') ?></div>
                                </td>
                                <td class="py-3.5 px-5 font-bold text-slate-900 dark:text-white">
                                    <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($loanAmount, 2) ?>
                                </td>
                                <td class="py-3.5 px-5 text-slate-600 dark:text-slate-300">
                                    <div class="font-medium"><?= $tenure ?> Months</div>
                                    <div class="text-xs text-indigo-600 dark:text-indigo-400 font-semibold"><?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($monthlyEmi, 2) ?> / mo</div>
                                </td>
                                <td class="py-3.5 px-5 text-slate-500 text-xs"><?= esc($loan['disbursed_date'] ?? 'Pending Disbursal') ?></td>
                                <td class="py-3.5 px-5 font-bold text-rose-600 dark:text-rose-400">
                                    <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($remaining, 2) ?>
                                </td>
                                <td class="py-3.5 px-5">
                                    <?php 
                                        $normStatus = strtolower($loan['status'] ?? '');
                                    ?>
                                    <?php if (in_array($normStatus, ['approved', 'active'], true)): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">Active / Deducting</span>
                                    <?php elseif (in_array($normStatus, ['completed', 'closed'], true)): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400 border border-sky-200">Paid Off</span>
                                    <?php elseif ($normStatus === 'rejected'): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200">Rejected</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-200">Pending Approval</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3.5 px-5 text-right space-x-1.5">
                                    <?php if (in_array($normStatus, ['pending', 'draft', 'applied'], true)): ?>
                                        <form method="POST" action="<?= base_url('payroll/loans/approve/' . $loan['id']) ?>" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="px-3 py-1 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition">Approve</button>
                                        </form>
                                        <form method="POST" action="<?= base_url('payroll/loans/reject/' . $loan['id']) ?>" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="px-3 py-1 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 transition">Reject</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Salary Advances Ledger Table -->
    <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 overflow-hidden shadow-xs">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
            <h3 class="font-semibold text-slate-900 dark:text-white text-base">Salary Advances</h3>
            <span class="text-xs text-slate-400">Direct Paycheck Recovery</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-medium">
                        <th class="py-3.5 px-5">Employee</th>
                        <th class="py-3.5 px-5">Advance Amount</th>
                        <th class="py-3.5 px-5">Repayment Period</th>
                        <th class="py-3.5 px-5">Reason</th>
                        <th class="py-3.5 px-5">Status</th>
                        <th class="py-3.5 px-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-slate-700/50">
                    <?php if (empty($advances)): ?>
                        <tr>
                            <td colspan="6" class="py-8 text-center text-slate-400">No salary advances requested.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($advances as $adv): ?>
                            <?php
                                $advAmount = (float)($adv['amount'] ?? 0);
                                $rm = (string)($adv['repayment_month'] ?? '');
                                $ry = (string)($adv['repayment_year'] ?? '');
                                if (preg_match('/^\d{4}-\d{2}$/', $rm)) {
                                    $period = date('F Y', strtotime($rm . '-01'));   // November 2026
                                } else {
                                    $period = trim($rm . ' ' . $ry);                // purono data (e.g. "October 2026")
                                }
                                if (empty($period)) {
                                    $period = $adv['advance_month'] ?? 'Next Paycheck';
                                }
                            ?>
                            <tr class="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                                <td class="py-3.5 px-5 font-semibold text-slate-900 dark:text-white">
                                    <?= esc($adv['employee_name'] ?? 'Employee') ?>
                                    <div class="text-xs font-normal text-slate-400"><?= esc($adv['employee_code'] ?? '') ?></div>
                                </td>
                                <td class="py-3.5 px-5 font-bold text-slate-900 dark:text-white">
                                    <?= !empty($currencyCode) ? esc($currencyCode) . ' ' : '' ?><?= number_format($advAmount, 2) ?>
                                </td>
                                <td class="py-3.5 px-5 text-slate-600 dark:text-slate-300 font-medium">
                                    <?= esc($period) ?>
                                </td>
                                <td class="py-3.5 px-5 text-slate-500 text-xs max-w-xs truncate">
                                    <?= esc($adv['reason'] ?? 'None specified') ?>
                                </td>
                                <td class="py-3.5 px-5">
                                    <?php if (($adv['status'] ?? '') === 'Approved'): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-200">Approved</span>
                                    <?php elseif (($adv['status'] ?? '') === 'Partially Recovered'): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-200">Partially Recovered</span>
                                    <?php elseif (($adv['status'] ?? '') === 'Recovered' || ($adv['status'] ?? '') === 'Paid' || ($adv['status'] ?? '') === 'Deducted'): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-400 border border-sky-200">Recovered</span>
                                    <?php elseif (($adv['status'] ?? '') === 'Rejected'): ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 border border-rose-200">Rejected</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border border-amber-200">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3.5 px-5 text-right space-x-1.5">
                                    <?php if (($adv['status'] ?? 'Pending') === 'Pending'): ?>
                                        <form method="POST" action="<?= base_url('payroll/loans/advance/approve/' . $adv['id']) ?>" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="px-3 py-1 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition">Approve</button>
                                        </form>
                                        <form method="POST" action="<?= base_url('payroll/loans/advance/reject/' . $adv['id']) ?>" class="inline">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="px-3 py-1 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 transition">Reject</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Apply Loan / Advance Modal -->
<div id="newLoanModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-white dark:bg-slate-800 rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200 dark:border-slate-700">
        <div class="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-700">
            <h3 class="font-bold text-slate-900 dark:text-white">Apply for Loan / Salary Advance</h3>
            <button onclick="document.getElementById('newLoanModal').classList.add('hidden')" class="text-slate-400 hover:text-slate-600">
                <i data-lucide="x" class="w-5 h-5"></i>
            </button>
        </div>
        <form method="POST" action="<?= base_url('payroll/loans/apply') ?>" class="mt-4 space-y-4">
            <?= csrf_field() ?>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Application Type</label>
                <select name="type" id="applicationTypeSelect" onchange="toggleLoanFields(this.value)" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-sm [&>option]:bg-white [&>option]:dark:bg-slate-900 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                    <option class="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100" value="Loan">Corporate Loan (Multi-Month EMI)</option>
                    <option class="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100" value="Advance">Salary Advance (Single-Month Paycheck Recovery)</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Employee</label>
                <select name="employee_id" required class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-sm [&>option]:bg-white [&>option]:dark:bg-slate-900 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                    <?php foreach ($employees as $emp): ?>
                        <option class="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100" value="<?= esc($emp['id']) ?>"><?= esc($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= esc($emp['employee_code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Amount <?= !empty($currencyCode) ? '(' . esc($currencyCode) . ')' : '' ?></label>
                    <input type="number" step="50" min="50" name="amount" required value="1000" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                </div>
                <div id="tenureContainer">
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Tenure (Months)</label>
                    <input type="number" min="1" max="48" name="tenure_months" id="tenureInput" value="10" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                </div>
                <div id="repayMonthContainer" class="hidden">
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Recovery Month</label>
                    <input type="month" name="month" value="<?= date('Y-m') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3" id="interestContainer">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Annual Interest Rate (%)</label>
                    <input type="number" step="0.5" min="0" max="100" name="interest_rate" value="5" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Calculation Method</label>
                    <select name="method" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 text-sm [&>option]:bg-white [&>option]:dark:bg-slate-900 [&>option]:text-slate-900 [&>option]:dark:text-slate-100">
                        <option value="reducing">Reducing Balance EMI</option>
                        <option value="flat">Flat Rate Simple</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Reason / Purpose</label>
                <textarea name="reason" rows="2" class="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm" placeholder="e.g. Medical emergency / home renovation"></textarea>
            </div>
            <div class="flex justify-end gap-2 pt-3">
                <button type="button" onclick="document.getElementById('newLoanModal').classList.add('hidden')" class="px-4 py-2 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-100">Cancel</button>
                <button type="submit" class="px-4 py-2 rounded-xl text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">Submit Application</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleLoanFields(type) {
    var tenureContainer = document.getElementById('tenureContainer');
    var repayMonthContainer = document.getElementById('repayMonthContainer');
    var interestContainer = document.getElementById('interestContainer');
    if (type === 'Advance') {
        tenureContainer.classList.add('hidden');
        if (interestContainer) interestContainer.classList.add('hidden');
        repayMonthContainer.classList.remove('hidden');
    } else {
        tenureContainer.classList.remove('hidden');
        if (interestContainer) interestContainer.classList.remove('hidden');
        repayMonthContainer.classList.add('hidden');
    }
}
</script>
