<?php
/**
 * Official CodeIgniter 4 Payslip View with Dynamic Report Logo & Branding Header/Footer
 */
?>
<div x-data="payslipRuleExplainer(<?= esc(json_encode($payslip['rules_snapshot_json'] ?? null)) ?>, '<?= esc($payslip['company_id'] ?? '') ?>', '<?= esc($payslip['employee_id'] ?? '') ?>', '<?= esc($payslip['payment_date'] ?? date('Y-m-d')) ?>')" class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center justify-between no-print">
        <a href="javascript:history.back()" class="text-sm text-slate-500 hover:text-slate-700">← Back to Batch</a>
        <div class="flex items-center gap-2">
            <button 
                type="button" 
                @click="openModal()" 
                class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer transition"
                title="Explain rules and snapshot used for this payslip"
            >
                <span>🔍 Explain Calculations & Rules</span>
            </button>
            <button onclick="window.print()" class="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-black shadow-sm flex items-center gap-1.5 cursor-pointer">
                <span>🖨️ Print / Download PDF</span>
            </button>
        </div>
    </div>

    <div class="bg-white border border-slate-200 rounded-xl p-8 shadow-sm space-y-6 print:shadow-none print:border-none">
        
        <!-- Official Dynamic Report Header Partial -->
        <?= view('reports/partials/report_header', [
            'company' => [
                'name' => $payslip['company_name'] ?? 'Enterprise Global HRMS',
                'address' => $payslip['company_address'] ?? 'Corporate Headquarters, Business District, Dhaka 1212',
                'phone' => '+880 9614 333 777',
                'email' => 'payroll@enterprise-hrms.com',
                'website' => 'www.enterprise-hrms.com',
                'report_header_image' => $company['report_header_image'] ?? $payslip['report_header_image'] ?? null,
                'report_header_text' => $company['report_header_text'] ?? $payslip['report_header_text'] ?? null,
                'report_header_layout' => $company['report_header_layout'] ?? 'center'
            ],
            'reportTitle' => 'EMPLOYEE MONTHLY SALARY PAYSLIP',
            'reportPeriod' => 'Salary Month: ' . esc($payslip['payroll_month'] ?? 'July 2026')
        ]) ?>

        <!-- Employee Info -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl text-xs border border-slate-100">
            <div>
                <div class="text-slate-400 font-medium">Employee Name</div>
                <div class="font-bold text-slate-800 text-sm mt-0.5"><?= esc($payslip['first_name'] . ' ' . $payslip['last_name']) ?></div>
                <div class="text-slate-500 mt-1">Code: <span class="font-mono"><?= esc($payslip['employee_code']) ?></span></div>
            </div>
            <div>
                <div class="text-slate-400 font-medium">Department & Designation</div>
                <div class="font-semibold text-slate-800 text-sm mt-0.5"><?= esc($payslip['department_name'] ?? 'Operations') ?></div>
                <div class="text-slate-500 mt-1"><?= esc($payslip['designation_name'] ?? 'Specialist') ?></div>
            </div>
            <div>
                <div class="text-slate-400 font-medium">Bank & Account</div>
                <div class="font-semibold text-slate-800 text-sm mt-0.5"><?= esc(!empty($payslip['bank_name']) ? $payslip['bank_name'] : '-') ?></div>
                <div class="text-slate-500 mt-1 font-mono"><?= esc(!empty($payslip['account_number']) ? $payslip['account_number'] : '-') ?></div>
            </div>
            <div>
                <div class="text-slate-400 font-medium">Payment Status</div>
                <div class="mt-1">
                    <span class="inline-block px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-full">
                        Disbursed / Paid
                    </span>
                </div>
            </div>
        </div>

        <!-- SSOT Rule Snapshot Audit Badge -->
        <div class="flex items-center justify-between bg-indigo-50/60 border border-indigo-100/80 rounded-xl px-4 py-2.5 text-xs text-indigo-950 no-print">
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-emerald-200"></span>
                <span class="font-bold">Rules Engine Snapshot:</span>
                <span class="text-indigo-800 font-mono text-[11px]">
                    <?= !empty($payslip['rules_snapshot_json']) ? 'Verified Immutable Audit Snapshot' : 'Authoritative SSOT Resolution' ?>
                </span>
            </div>
            <button 
                type="button" 
                @click="openModal()" 
                class="text-indigo-600 hover:text-indigo-800 font-bold underline text-[11px] cursor-pointer flex items-center gap-1"
            >
                <span>Explain Parameter Origins</span>
                <span>→</span>
            </button>
        </div>

        <?php
            $dynamicBreakdown = null;
            if (!empty($payslip['components_breakdown_json'])) {
                $dynamicBreakdown = is_array($payslip['components_breakdown_json']) 
                    ? $payslip['components_breakdown_json'] 
                    : json_decode($payslip['components_breakdown_json'], true);
            }
            $dynEarnings = $dynamicBreakdown['earnings'] ?? null;
            $dynDeductions = $dynamicBreakdown['deductions'] ?? null;
        ?>

        <!-- Breakdown Grid -->
        <div class="grid grid-cols-2 gap-8 text-xs">
            <!-- Earnings -->
            <div class="border border-slate-100 rounded-xl p-4 bg-white space-y-2">
                <h3 class="font-bold text-slate-900 border-b border-slate-200 pb-2 uppercase tracking-wider text-xs">Earnings & Allowances</h3>
                <div class="divide-y divide-slate-100">
                    <?php if (!empty($dynEarnings) && is_array($dynEarnings)): ?>
                        <?php foreach ($dynEarnings as $e): ?>
                            <?php if ((float)($e['amount'] ?? 0) > 0): ?>
                                <div class="flex justify-between py-2">
                                    <span class="text-slate-600"><?= esc($e['name'] ?? $e['code'] ?? 'Earning') ?></span>
                                    <span class="font-mono font-medium">$<?= number_format((float)$e['amount'], 2) ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if ((float)($payslip['overtime_amount'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Overtime Hours Pay</span><span class="font-mono font-medium">$<?= number_format($payslip['overtime_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['bonus_amount'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Performance Bonus</span><span class="font-mono font-medium">$<?= number_format($payslip['bonus_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['incentive_amount'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Incentives</span><span class="font-mono font-medium">$<?= number_format($payslip['incentive_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['arrear_amount'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Retroactive Arrears</span><span class="font-mono font-medium">$<?= number_format($payslip['arrear_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['leave_encashment'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Leave Encashment</span><span class="font-mono font-medium">$<?= number_format($payslip['leave_encashment'], 2) ?></span></div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Basic Salary</span><span class="font-mono font-medium">$<?= number_format($payslip['basic_salary'], 2) ?></span></div>
                        <?php if (!empty($payslip['house_rent']) || !empty($payslip['medical']) || !empty($payslip['conveyance']) || !empty($payslip['other_allowances'])): ?>
                            <?php if ((float)($payslip['house_rent'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">House Rent Allowance (HRA)</span><span class="font-mono font-medium">$<?= number_format($payslip['house_rent'], 2) ?></span></div>
                            <?php endif; ?>
                            <?php if ((float)($payslip['medical'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Medical Allowance</span><span class="font-mono font-medium">$<?= number_format($payslip['medical'], 2) ?></span></div>
                            <?php endif; ?>
                            <?php if ((float)($payslip['conveyance'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Conveyance Allowance</span><span class="font-mono font-medium">$<?= number_format($payslip['conveyance'], 2) ?></span></div>
                            <?php endif; ?>
                            <?php if ((float)($payslip['other_allowances'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Other Allowances (Food & Special)</span><span class="font-mono font-medium">$<?= number_format($payslip['other_allowances'], 2) ?></span></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if ((float)($payslip['allowances'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Total Allowances</span><span class="font-mono font-medium">$<?= number_format($payslip['allowances'], 2) ?></span></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if ((float)($payslip['overtime_amount'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Overtime Hours Pay</span><span class="font-mono font-medium">$<?= number_format($payslip['overtime_amount'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['bonus_amount'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Performance Bonus</span><span class="font-mono font-medium">$<?= number_format($payslip['bonus_amount'], 2) ?></span></div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="flex justify-between py-2.5 font-bold border-t border-slate-200 text-slate-900"><span>Gross Earnings</span><span class="font-mono">$<?= number_format($payslip['gross_salary'], 2) ?></span></div>
                </div>
            </div>

            <!-- Deductions -->
            <div class="border border-slate-100 rounded-xl p-4 bg-white space-y-2">
                <h3 class="font-bold text-slate-900 border-b border-slate-200 pb-2 uppercase tracking-wider text-xs">Deductions & Withholdings</h3>
                <div class="divide-y divide-slate-100">
                    <?php if (!empty($dynDeductions) && is_array($dynDeductions)): ?>
                        <?php foreach ($dynDeductions as $d): ?>
                            <?php if ((float)($d['amount'] ?? 0) > 0): ?>
                                <div class="flex justify-between py-2">
                                    <span class="text-slate-600"><?= esc($d['name'] ?? $d['code'] ?? 'Deduction') ?></span>
                                    <span class="font-mono font-medium text-rose-600">$<?= number_format((float)$d['amount'], 2) ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if (((float)($payslip['loan_emi'] ?? 0) + (float)($payslip['advance_recovery'] ?? 0)) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Loan Repayment / Advance</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['loan_emi'] + $payslip['advance_recovery'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['asset_recovery'] ?? 0) > 0 && !array_filter($dynDeductions, fn($d) => in_array(strtoupper($d['code'] ?? ''), ['ASSET', 'ASSET_RECOVERY'], true))): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Asset recovery</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['asset_recovery'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['unpaid_leave_deduction'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Loss of Pay (LOP)</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['unpaid_leave_deduction'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['late_penalty'] ?? 0) > 0): ?>
                            <div class="flex justify-between py-2"><span class="text-slate-600">Late Penalty & Fines</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['late_penalty'], 2) ?></span></div>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if ((float)($payslip['tax_deduction'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Income Tax (Withholding)</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['tax_deduction'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['pf_deduction'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Provident Fund (PF)</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['pf_deduction'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if (((float)($payslip['loan_emi'] ?? 0) + (float)($payslip['advance_recovery'] ?? 0)) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Loan Repayment / Advance</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['loan_emi'] + $payslip['advance_recovery'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['asset_recovery'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Asset recovery</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['asset_recovery'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['unpaid_leave_deduction'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Loss of Pay (LOP)</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['unpaid_leave_deduction'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['late_penalty'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Late Penalty & Fines</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['late_penalty'], 2) ?></span></div>
                        <?php endif; ?>
                        <?php if ((float)($payslip['other_deductions'] ?? 0) > 0): ?>
                        <div class="flex justify-between py-2"><span class="text-slate-600">Other Deductions</span><span class="font-mono font-medium text-rose-600">$<?= number_format($payslip['other_deductions'], 2) ?></span></div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="flex justify-between py-2.5 font-bold border-t border-slate-200 text-slate-900"><span>Total Deductions</span><span class="font-mono text-rose-600">$<?= number_format($payslip['total_deductions'], 2) ?></span></div>
                </div>
            </div>
        </div>

        <?php
            $uTax = (float)($payslip['unapplied_tax'] ?? 0.0);
            $uPf  = (float)($payslip['unapplied_pf'] ?? 0.0);
            $uLop = (float)($payslip['unapplied_lop'] ?? 0.0);
            $hasUnapplied = ($uTax > 0 || $uPf > 0 || $uLop > 0);
            $unappliedParts = [];
            if ($uTax > 0) {
                $unappliedParts[] = number_format($uTax, 2) . ' Tax';
            }
            if ($uPf > 0) {
                $unappliedParts[] = number_format($uPf, 2) . ' PF';
            }
            if ($uLop > 0) {
                $unappliedParts[] = number_format($uLop, 2) . ' LOP';
            }
            $unappliedMsg = implode(', ', $unappliedParts);
        ?>
        <?php if ($hasUnapplied): ?>
        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex items-start gap-3">
            <span class="text-lg">⚠️</span>
            <div class="space-y-1">
                <div class="font-bold text-amber-800">Statutory 50% Deduction Ceiling Alert</div>
                <p class="text-amber-800 font-semibold">Total statutory deductions capped at 50% of gross salary. Unapplied amount this period: <?= esc($unappliedMsg) ?></p>
                <p class="text-[11px] text-amber-600 leading-relaxed">In accordance with labor regulations, total monthly deductions cannot exceed 50% of gross earnings. This unapplied balance has been logged for tax and provident fund annual accounting adjustments.</p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Net Total -->
        <div class="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-xl p-5 flex justify-between items-center">
            <div>
                <span class="text-xs font-semibold text-indigo-300 uppercase tracking-wider">Net Disbursed Take-Home</span>
                <p class="text-xs text-slate-300 mt-0.5">Deposited via Electronic Fund Transfer to Registered Primary Bank Account</p>
            </div>
            <div class="text-3xl font-black text-emerald-400 font-mono">
                $<?= number_format($payslip['net_salary'], 2) ?>
            </div>
        </div>

        <!-- Official Dynamic Report Footer Partial -->
        <?= view('reports/partials/report_footer', [
            'company' => [
                'report_footer_image' => $company['report_footer_image'] ?? $payslip['report_footer_image'] ?? null,
                'report_footer_text' => $company['report_footer_text'] ?? "This is an official system-generated document from Enterprise HRMS Analytics Hub. Confidential.",
                'report_footer_layout' => $company['report_footer_layout'] ?? 'split'
            ],
            'showSignatures' => true,
            'signatories' => [
                ['title' => 'Employee Signature'],
                ['title' => 'Head of Human Resources'],
                ['title' => 'Finance Controller']
            ]
        ]) ?>

    </div>

    <!-- Explain Rules Snapshot Modal -->
    <div 
        x-show="modalOpen" 
        x-cloak
        class="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 no-print"
        style="display: none;"
    >
        <div 
            class="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 space-y-5"
            @click.away="modalOpen = false"
            @keydown.escape.window="modalOpen = false"
        >
            <!-- Header -->
            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-sm">
                        ⚙️
                    </div>
                    <div>
                        <h3 class="text-base font-extrabold text-slate-900">Rule Parameters & Origin Explanation</h3>
                        <p class="text-xs text-slate-500">Single source of truth resolution breakdown for this payslip</p>
                    </div>
                </div>
                <button 
                    type="button" 
                    @click="modalOpen = false" 
                    class="text-slate-400 hover:text-slate-600 font-bold text-lg p-1 cursor-pointer"
                >
                    &times;
                </button>
            </div>

            <!-- Loading State -->
            <template x-if="loading">
                <div class="py-12 text-center space-y-3">
                    <div class="inline-block animate-spin rounded-full h-8 w-8 border-2 border-indigo-600 border-t-transparent"></div>
                    <p class="text-xs text-slate-500 font-medium">Resolving rule parameter hierarchy and snapshot layers...</p>
                </div>
            </template>

            <!-- Error State -->
            <template x-if="error && !loading">
                <div class="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs space-y-1">
                    <div class="font-bold">Unable to resolve rule explanation</div>
                    <div x-text="error"></div>
                </div>
            </template>

            <!-- Content State -->
            <template x-if="!loading && !error">
                <div class="space-y-4">
                    <!-- Domain Tabs -->
                    <div class="flex items-center gap-1.5 border-b border-slate-100 pb-2 overflow-x-auto">
                        <template x-for="d in domains" :key="d">
                            <button 
                                type="button" 
                                @click="activeDomain = d" 
                                class="px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer"
                                :class="activeDomain === d ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'"
                                x-text="d"
                            ></button>
                        </template>
                    </div>

                    <!-- Selected Domain Content -->
                    <template x-if="activeDomainData">
                        <div class="space-y-3">
                            <!-- Snapshot Hash Badge if available -->
                            <template x-if="activeDomainSnapshot && activeDomainSnapshot.hash">
                                <div class="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px]">
                                    <span class="text-slate-500">Cryptographic Layer Hash:</span>
                                    <span class="font-mono font-bold text-indigo-600" x-text="activeDomainSnapshot.hash"></span>
                                </div>
                            </template>

                            <!-- Parameters Table -->
                            <div class="max-h-80 overflow-y-auto border border-slate-200 rounded-xl">
                                <table class="w-full text-left text-xs">
                                    <thead class="bg-slate-50 border-b border-slate-200 text-[10px] uppercase font-bold text-slate-400">
                                        <tr>
                                            <th class="p-2.5">Parameter Key</th>
                                            <th class="p-2.5">Resolved Value</th>
                                            <th class="p-2.5">Origin Scope</th>
                                            <th class="p-2.5">Version</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-mono text-[11px]">
                                        <template x-for="(exp, key) in (activeDomainData.explanation || {})" :key="key">
                                            <tr class="hover:bg-slate-50/50">
                                                <td class="p-2.5 font-sans font-semibold text-slate-800" x-text="key"></td>
                                                <td class="p-2.5 font-bold text-indigo-700" x-text="formatValue(exp.value)"></td>
                                                <td class="p-2.5">
                                                    <span 
                                                        class="px-2 py-0.5 rounded-md text-[10px] font-sans font-bold uppercase"
                                                        :class="scopeBadgeClass(exp.scope_level)"
                                                        x-text="exp.scope_level || 'Company'"
                                                    ></span>
                                                </td>
                                                <td class="p-2.5 text-slate-500" x-text="'v' + (exp.version_number || 1)"></td>
                                            </tr>
                                        </template>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </template>
                </div>
            </template>

            <!-- Footer -->
            <div class="flex justify-end pt-2 border-t border-slate-100">
                <button 
                    type="button" 
                    @click="modalOpen = false" 
                    class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer"
                >
                    Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function payslipRuleExplainer(snapshotRaw, companyId, employeeId, paymentDate) {
    return {
        modalOpen: false,
        loading: false,
        error: null,
        loaded: false,
        domains: [],
        activeDomain: '',
        explanationsData: {},
        rawSnapshot: snapshotRaw,

        init() {
            if (window.location.hash === '#explain') {
                this.openModal();
            }
        },

        get activeDomainData() {
            return this.explanationsData[this.activeDomain] || null;
        },

        get activeDomainSnapshot() {
            if (!this.activeDomainData) return null;
            return this.activeDomainData.snapshot_record || this.activeDomainData.snapshot || null;
        },

        async openModal() {
            this.modalOpen = true;
            if (this.loaded) return;

            this.loading = true;
            this.error = null;

            try {
                const payload = {
                    company_id: companyId,
                    employee_id: employeeId,
                    date: paymentDate,
                };
                if (this.rawSnapshot) {
                    payload.rules_snapshot_json = this.rawSnapshot;
                } else {
                    payload.domain = 'PAYROLL_BASICS';
                }

                const res = await fetch('/rules/explain', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();

                if (!json.success) {
                    throw new Error(json.message || 'Failed to fetch rule explanation');
                }

                if (json.data && json.data.explanations) {
                    this.explanationsData = json.data.explanations;
                    this.domains = Object.keys(this.explanationsData);
                } else if (json.data && json.data.explanation) {
                    const dom = json.data.domain || 'PAYROLL_BASICS';
                    this.explanationsData = {
                        [dom]: {
                            explanation: json.data.explanation,
                            params: json.data.params,
                            snapshot_record: json.data.snapshot
                        }
                    };
                    this.domains = [dom];
                }

                this.activeDomain = this.domains[0] || '';
                this.loaded = true;
            } catch (err) {
                this.error = err.message || 'Network error fetching rules';
            } finally {
                this.loading = false;
            }
        },

        formatValue(val) {
            if (val === null || val === undefined) return '-';
            if (typeof val === 'boolean') return val ? 'True' : 'False';
            if (typeof val === 'object') return JSON.stringify(val);
            return String(val);
        },

        scopeBadgeClass(scope) {
            const s = (scope || '').toLowerCase();
            if (s === 'employee') return 'bg-purple-100 text-purple-800 border border-purple-200';
            if (s === 'shift') return 'bg-amber-100 text-amber-800 border border-amber-200';
            if (s === 'designation') return 'bg-blue-100 text-blue-800 border border-blue-200';
            if (s === 'department') return 'bg-teal-100 text-teal-800 border border-teal-200';
            if (s === 'branch') return 'bg-sky-100 text-sky-800 border border-sky-200';
            return 'bg-slate-100 text-slate-800 border border-slate-200';
        }
    };
}
</script>
