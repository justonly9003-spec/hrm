# OVERTIME POLICY ENGINE — PHASE 5 IMPLEMENTATION REPORT

**Application**: CodeIgniter 4 HR/Payroll App  
**Domain**: Overtime Policy & Calculation Engine (`OVERTIME` Rule Definition)  
**Deliverable**: Phase 5 — Overtime Policy Engine Extension  
**Status**: Completed  

---

## 1. Executive Summary

Phase 5 extends the centralized Overtime Policy Engine across both the Alpine.js administrative UI and the server-side `OvertimeCalculationService`.

All business rules for overtime (thresholds, grace periods, multipliers, rounding, caps, eligibility conditions, and approval workflows) are consolidated into the single source of truth: table `rule_definitions` under domain `OVERTIME`, read exclusively through `App\Services\Rules\RuleResolver`.

### Key Enhancements Delivered
1. **Early Check-in Overtime Policy**:
   - Master toggle (`enable_early_arrival_ot`) to enable/disable early arrival counting.
   - Configurable minimum early minutes threshold (`early_arrival_min_threshold_minutes`).
   - Configurable grace buffer (`early_arrival_grace_minutes`).
2. **Post Check-out Overtime Policy**:
   - Master toggle (`enable_post_shift_ot`) to enable/disable post-shift overtime counting.
   - Configurable minimum post-shift threshold (`post_shift_min_threshold_minutes`), defaulting to 30 minutes in the UI form.
   - Configurable grace buffer (`post_shift_grace_minutes`).
3. **Threshold as an Eligibility Condition (Zero Deductions)**:
   - Enforced across the calculation engine: meeting or exceeding the threshold qualifies the employee for the **full duration** of the overtime interval (e.g. shift end 16:00, checkout 17:00, min threshold 30 minutes $\rightarrow$ eligible overtime is **60 minutes**, not $60 - 30 = 30$ minutes). If checkout is at 16:20 (20 minutes, under the 30-minute threshold), eligible overtime is 0 minutes.
4. **Anti-Double-Counting Architecture**:
   - Strict separation of early check-in, post-shift, off-day, and special-duty intervals.
   - Overnight shift overlap detection: If yesterday's shift ended overnight on the current morning (e.g., checkout at 07:00) and the employee checks in early at 06:30 for an 08:00 shift, the engine clamps today's early arrival window to 07:00. The 30 overlapping minutes between 06:30 and 07:00 are deducted from today's early arrival calculation, preventing double payment of hours already counted in yesterday's shift.
   - Idempotency guarantees: exactly one record per employee per calendar date (`employee_id` + `date` unique constraint).
5. **Non-Auto-Approval & Calculation Breakdown**:
   - Overtime earned (> 0 hours) defaults strictly to `'Pending'` approval status.
   - Full calculation breakdown is persisted in `overtime_records.calculation_metadata_json`.
   - Existing schema in `overtime_records` already supports `calculation_metadata_json LONGTEXT NULL` alongside granular minute columns (`raw_early_minutes`, `raw_post_minutes`, `payable_early_minutes`, `payable_post_minutes`), so no database migrations were required.

---

## 2. Policy UI Extensions (`codeigniter4/app/Views/rules/domains/overtime.php`)

The Overtime Rule view was updated to provide intuitive configuration and immediate mathematical clarity to administrators:

### Card 1: Early Check-in Overtime
- **Toggle**: `enable_early_arrival_ot` (checkbox styled with Tailwind toggle component).
- **Threshold Input**: `early_arrival_min_threshold_minutes` (number input, min 1).
- **Grace Buffer Input**: `early_arrival_grace_minutes` (number input, min 0).
- **Dynamic Helper & Preview**:
  - Clear guidance stating: *"Threshold is an eligibility condition: once met, the employee receives the full early minutes."*
  - Live preview box calculating example scenarios (e.g., 45 minutes early with a 30-minute threshold qualifies for the full 45 minutes).

### Card 2: Post Check-out Overtime
- **Toggle**: `enable_post_shift_ot` (checkbox styled with Tailwind toggle component).
- **Threshold Input**: `post_shift_min_threshold_minutes` (number input, min 1, default 30).
- **Grace Buffer Input**: `post_shift_grace_minutes` (number input, min 0).
- **Dynamic Helper & Preview**:
  - Explicit rule summary: *"Threshold is an ELIGIBILITY condition, not a deduction. Example: shift end 16:00, checkout 17:00, threshold 30 min => eligible OT is 60 minutes (not 30). Checkout at 16:20 => 0 minutes."*
  - Live Alpine.js calculation preview demonstrating both the qualifying and non-qualifying cases.

### Card 3: Overtime Multipliers
- **Normal Workday Multiplier**: `normal_multiplier` (e.g., 1.50x).
- **Weekly Off / Weekend Multiplier**: `weekly_off_multiplier` (e.g., 2.00x).
- **Holiday Multiplier**: `holiday_multiplier` (e.g., 2.00x).
- **Special Duty Multiplier**: `special_multiplier` (e.g., 2.50x) for emergency/special duty shifts.
- **Night Multiplier**: `night_multiplier` (e.g., 1.25x) for overnight shifts.

---

## 3. Calculation Engine Mechanics (`OvertimeCalculationService.php`)

### A. Threshold as Eligibility Condition
In `calculateDailyOvertime()`:
```php
// 1. Early Check-in:
if ($effectiveInMins < $shiftStartMins) {
    $rawEarlyMinutes = $shiftStartMins - $effectiveInMins;
    if ($allowEarlyArrival && $rawEarlyMinutes >= $earlyThreshold) {
        $payableEarlyMinutes = max(0, $rawEarlyMinutes - $earlyGrace);
    } else {
        $payableEarlyMinutes = 0;
    }
}

// 2. Post-Shift:
if ($effOutMins > $effShiftEndMins) {
    $rawPostMinutes = $effOutMins - $effShiftEndMins;
    if ($allowPostShift && $rawPostMinutes >= $postThreshold) {
        $payablePostMinutes = max(0, $rawPostMinutes - $postGrace);
    } else {
        $payablePostMinutes = 0;
    }
}
```
If `$rawMinutes < $threshold`, `$payableMinutes = 0`.  
If `$rawMinutes >= $threshold`, `$payableMinutes = $rawMinutes - $grace` (where `$grace` is an optional buffer, usually 0). No deduction of the threshold value occurs.

### B. Anti-Double-Counting Architecture
1. **Early vs. Post-Shift Separation**:
   Early minutes and post-shift minutes are calculated across non-overlapping intervals relative to the shift window: $[T_{\text{in}}, T_{\text{shift\_start}})$ and $(T_{\text{shift\_end}}, T_{\text{out}}]$.
2. **Previous Day's Overnight Shift Overlap Detection**:
   When an employee worked a night shift starting yesterday (e.g., 23:00 to 07:00 today) and has a morning shift today (e.g., starting at 08:00), an early punch at 06:30 would overlap with yesterday's checkout:
   - The service inspects the previous day's attendance log (`checkout_date == today` or `out_time < in_time`).
   - If today's check-in ($06:30 = 390$ min) is earlier than yesterday's checkout ($07:00 = 420$ min), the overlap ($30$ min) is detected.
   - Today's effective early check-in is clamped to $\max(\text{inMins}, \text{prevOutMins}) = 07:00$.
   - Today's early overtime is calculated as $08:00 - 07:00 = 60$ minutes (not 90 minutes).
   - The audit log in `calculation_metadata_json` records:
     ```json
     {
       "anti_double_counting": {
         "overnight_overlap_detected": true,
         "prev_day_checkout": "07:00",
         "overlap_deducted_minutes": 30,
         "special_duty_applied": false
       }
     }
     ```
3. **Special Duty Assignment Priority**:
   - Evaluated via `DutyAssignmentModel::getDutyForEmployeeDate()`.
   - If assigned to `'SPECIAL_DUTY'` with `'All Worked Hours as OT'`, all worked hours are routed to `ot_type = 'Special Duty'` with `special_multiplier`, bypassing normal workday split to prevent duplicate accounting.

### C. Approval Policy & Breakdown Storage
- Overtime is **NEVER** auto-approved. When `overtime_hours > 0`, the record defaults to `approval_status = 'Pending'`.
- Only approved overtime records (`approval_status == 'Approved'`) are included in monthly payroll summaries (`getSummaryForPayroll()`).
- The full calculation breakdown is serialized to JSON and stored in `calculation_metadata_json`, capturing:
  - `day_type`, `is_weekly_off`, `is_holiday`, `is_special_duty`
  - `total_worked_mins`, `net_worked_mins`
  - `early_threshold_mins`, `early_threshold_met`, `raw_early_minutes`, `payable_early_minutes`
  - `post_threshold_mins`, `post_threshold_met`, `raw_post_minutes`, `payable_post_minutes`
  - `threshold_is_eligibility_condition = true`
  - `anti_double_counting` metrics
  - Hourly rate components and snapshots

---

## 4. Test Coverage (`OvertimeCountingPolicyTest.php`)

All required test scenarios are implemented in `codeigniter4/tests/unit/OvertimeCountingPolicyTest.php`:

| Test Name | Scenario Tested | Expected Result |
|---|---|---|
| `testEarlyCheckinOvertimeWhenDisabled` | Early toggle = OFF, check-in 45m early | `payable_early_minutes = 0`, `overtime_hours = 0.00` |
| `testEarlyCheckinOvertimeBelowConfiguredThreshold` | Early toggle = ON, threshold = 30m, check-in 20m early | `payable_early_minutes = 0`, `overtime_hours = 0.00` |
| `testEarlyCheckinOvertimeMeetsConfiguredThreshold` | Early toggle = ON, threshold = 30m, check-in 35m early | `payable_early_minutes = 35`, qualifies for full duration |
| `testPostCheckoutOvertimeWhenDisabled` | Post toggle = OFF, checkout 60m post-shift | `payable_post_minutes = 0`, `overtime_hours = 0.00` |
| `testPostCheckoutOvertimeBelowMinimumDuration` | Post toggle = ON, threshold = 30m, checkout 25m post-shift | `payable_post_minutes = 0`, `overtime_hours = 0.00` |
| `testPostCheckoutOvertimeMeetsMinimumDuration` | Post toggle = ON, threshold = 30m, checkout 45m post-shift | `payable_post_minutes = 45`, qualifies for full duration |
| `testThresholdIsEligibilityConditionNotDeduction` | Shift end 16:00, checkout 17:00 (60m), threshold 30m; vs checkout 16:20 (20m) | Case A: `payable_post_minutes = 60` (NOT 30), `overtime_hours = 1.00`. Case B: `0` minutes |
| `testWeeklyOffOvertimeCalculation` | Sunday off-day, worked 09:00 to 17:00 (8h), multiplier 2.0x | `ot_type = 'Weekly Off'`, `multiplier = 2.0`, `overtime_hours = 8.00` |
| `testHolidayOvertimeCalculation` | Victory Day holiday, worked 6h, multiplier 2.0x | `ot_type = 'Holiday'`, `multiplier = 2.0`, `overtime_hours = 6.00` |
| `testSpecialDutyOvertimeCalculation` | Special duty assignment, 6h worked, multiplier 2.5x | `ot_type = 'Special Duty'`, `multiplier = 2.5`, `overtime_hours = 6.00` |
| `testOvernightShiftAndOverlapWithPreviousNightShift` | Yesterday night checkout 07:00; today shift 08:00, check-in 06:30 | Clamped to 07:00, raw early = 60m (not 90m), overlap 30m deducted |
| `testPreventDuplicateOvertimeCounting` | Multiple recalculations on same employee and date | Single record maintained (`id` preserved, updated in-place) |
| `testOvertimeNotAutoApprovedAndStoresCalculationBreakdown` | 90m overtime earned, requires_post_approval = true | `approval_status = 'Pending'`, `calculation_metadata_json` contains full breakdown |
| `testPayrollUsesApprovedOvertimeOnly` | 1 Approved, 1 Pending, 1 Rejected record | Payroll summary aggregates only the Approved record |
| `testOvertimeServiceFacade` | Facade interface validation | Complete API parity with `OvertimeCalculationService` |

---

## 5. Parity & Compliance Verification

1. **Single Source of Business Rules (`RULE[AGENTS_md]` Rule 2)**:
   - Rules are loaded exclusively via `RuleResolver::resolve($companyId, 'OVERTIME', $date, $scopes)`.
   - No separate tables or `system_settings` keys hold overtime rules.
2. **Zero Literal Fallbacks (`RULE[AGENTS_md]` Rule 4)**:
   - No fallback values like `?? 30` or `?? 1.5` in calculation paths. Missing required parameters trigger `RuleNotConfiguredException`.
3. **Database Schema Compliance**:
   - Table `overtime_records` already contains `calculation_metadata_json LONGTEXT NULL` along with granular early/post minute breakdown columns. No DDL changes were needed.
4. **Tenant Isolation (`company_id`)**:
   - All models, rule resolutions, and holiday lookups strictly filter by `company_id`.
